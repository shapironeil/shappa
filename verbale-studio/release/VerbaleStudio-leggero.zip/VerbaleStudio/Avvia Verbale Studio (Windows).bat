@echo off
setlocal
set "ROOT=%~dp0."
set "NODE="
if exist "%ROOT%\node\node.exe" set "NODE=%ROOT%\node\node.exe"
rem Node.js standalone (zip estratto) dentro questa cartella, in "node\" o nella cartella accanto (es. APPS\node-v24…)
rem "Estrai tutto" di Windows crea spesso una cartella doppia: node-v…\node-v…\node.exe
for %%B in ("%ROOT%" "%ROOT%\node" "%ROOT%\..") do (
  for /d %%A in ("%%~B\node-v*-win-x64") do (
    if not defined NODE if exist "%%~A\node.exe" set "NODE=%%~A\node.exe"
    if not defined NODE for /d %%D in ("%%~A\node-v*-win-x64") do if exist "%%~D\node.exe" set "NODE=%%~D\node.exe"
  )
)
if not defined NODE (where node >nul 2>nul && set "NODE=node")
if not defined NODE (
  echo.
  echo  Node.js non trovato.
  echo.
  echo  Non serve installarlo: scarica lo zip "standalone" da
  echo    https://nodejs.org/dist/v22.22.2/node-v22.22.2-win-x64.zip
  echo  estrailo e metti la cartella "node-v22.22.2-win-x64" dentro la cartella VerbaleStudio
  echo  oppure accanto a essa ^(nella stessa cartella che contiene VerbaleStudio^).
  echo  Poi riavvia questo file.
  echo.
  start "" "https://nodejs.org/dist/v22.22.2/node-v22.22.2-win-x64.zip"
  pause
  exit /b
)
"%NODE%" "%~dp0app\server.cjs" "%ROOT%" --open
pause
