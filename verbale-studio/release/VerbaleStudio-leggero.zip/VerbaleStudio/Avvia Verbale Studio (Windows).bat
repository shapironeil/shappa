@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js non trovato: installalo da https://nodejs.org ^(versione LTS^) e riprova. & start https://nodejs.org & pause & exit /b)
node "%~dp0app\server.cjs" "%~dp0." --open
pause
