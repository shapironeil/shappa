#!/bin/bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js non trovato: installalo da https://nodejs.org"; open https://nodejs.org; read; exit 1; }
node app/server.cjs "$(pwd)" --open
