#!/bin/bash
cd "$(dirname "$0")"
NODE=$(ls -d node*/bin/node 2>/dev/null | head -1)
[ -z "$NODE" ] && NODE=$(command -v node)
[ -z "$NODE" ] && { echo "Node.js non trovato: scarica lo zip standalone da https://nodejs.org e mettilo in questa cartella"; open https://nodejs.org/en/download; read; exit 1; }
"$NODE" app/server.cjs "$(pwd)" --open
