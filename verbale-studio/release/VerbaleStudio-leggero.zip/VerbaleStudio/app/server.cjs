var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// node_modules/@anthropic-ai/sdk/internal/tslib.js
var require_tslib = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/tslib.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.__setModuleDefault = exports2.__createBinding = void 0;
    exports2.__classPrivateFieldSet = __classPrivateFieldSet;
    exports2.__classPrivateFieldGet = __classPrivateFieldGet;
    exports2.__importStar = __importStar;
    exports2.__exportStar = __exportStar;
    function __classPrivateFieldSet(receiver, state, value, kind, f) {
      if (kind === "m")
        throw new TypeError("Private method is not writable");
      if (kind === "a" && !f)
        throw new TypeError("Private accessor was defined without a setter");
      if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
        throw new TypeError("Cannot write private member to an object whose class did not declare it");
      return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
    }
    function __classPrivateFieldGet(receiver, state, kind, f) {
      if (kind === "a" && !f)
        throw new TypeError("Private accessor was defined without a getter");
      if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
        throw new TypeError("Cannot read private member from an object whose class did not declare it");
      return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    }
    var __createBinding = Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
          enumerable: true,
          get: function() {
            return m[k];
          }
        };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    };
    exports2.__createBinding = __createBinding;
    var __setModuleDefault = Object.create ? function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    } : function(o, v) {
      o["default"] = v;
    };
    exports2.__setModuleDefault = __setModuleDefault;
    var ownKeys = function(o) {
      ownKeys = Object.getOwnPropertyNames || function(o2) {
        var ar = [];
        for (var k in o2)
          if (Object.prototype.hasOwnProperty.call(o2, k))
            ar[ar.length] = k;
        return ar;
      };
      return ownKeys(o);
    };
    function __importStar(mod) {
      if (mod && mod.__esModule)
        return mod;
      var result = {};
      if (mod != null) {
        for (var k = ownKeys(mod), i = 0; i < k.length; i++)
          if (k[i] !== "default")
            __createBinding(result, mod, k[i]);
      }
      __setModuleDefault(result, mod);
      return result;
    }
    function __exportStar(m, o) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
          __createBinding(o, m, p);
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/errors.js
var require_errors = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/errors.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.castToError = void 0;
    exports2.isAbortError = isAbortError;
    function isAbortError(err) {
      return typeof err === "object" && err !== null && // Spec-compliant fetch implementations
      ("name" in err && err.name === "AbortError" || // Expo fetch
      "message" in err && String(err.message).includes("FetchRequestCanceledException"));
    }
    var castToError = (err) => {
      if (err instanceof Error)
        return err;
      if (typeof err === "object" && err !== null) {
        try {
          const tag = Object.prototype.toString.call(err);
          if (tag === "[object Error]" || tag === "[object DOMException]") {
            const error = new Error(err.message, err.cause ? { cause: err.cause } : {});
            if (err.stack)
              error.stack = err.stack;
            if (err.cause && !error.cause)
              error.cause = err.cause;
            if (err.name)
              error.name = err.name;
            return error;
          }
        } catch {
        }
        try {
          return new Error(JSON.stringify(err));
        } catch {
        }
      }
      return new Error(err);
    };
    exports2.castToError = castToError;
  }
});

// node_modules/@anthropic-ai/sdk/core/error.js
var require_error = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/error.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.InternalServerError = exports2.RateLimitError = exports2.UnprocessableEntityError = exports2.ConflictError = exports2.NotFoundError = exports2.PermissionDeniedError = exports2.AuthenticationError = exports2.BadRequestError = exports2.RetryableError = exports2.APIConnectionTimeoutError = exports2.APIConnectionError = exports2.APIUserAbortError = exports2.APIError = exports2.AnthropicError = void 0;
    var errors_1 = require_errors();
    var AnthropicError = /* @__PURE__ */ (() => {
      class AnthropicError2 extends Error {
      }
      return AnthropicError2;
    })();
    exports2.AnthropicError = AnthropicError;
    var APIError = class _APIError extends AnthropicError {
      constructor(status, error, message, headers, type) {
        super(`${_APIError.makeMessage(status, error, message)}`);
        this.status = status;
        this.headers = headers;
        this.requestID = headers?.get("request-id");
        this.workspaceID = headers?.get("anthropic-workspace-id");
        this.error = error;
        this.type = type ?? null;
      }
      static makeMessage(status, error, message) {
        const msg = error?.message ? typeof error.message === "string" ? error.message : JSON.stringify(error.message) : error ? JSON.stringify(error) : message;
        if (status && msg) {
          return `${status} ${msg}`;
        }
        if (status) {
          return `${status} status code (no body)`;
        }
        if (msg) {
          return msg;
        }
        return "(no status code or body)";
      }
      static generate(status, errorResponse, message, headers) {
        if (!status || !headers) {
          return new APIConnectionError({ message, cause: (0, errors_1.castToError)(errorResponse) });
        }
        const error = errorResponse;
        const type = error?.["error"]?.["type"];
        if (status === 400) {
          return new BadRequestError(status, error, message, headers, type);
        }
        if (status === 401) {
          return new AuthenticationError(status, error, message, headers, type);
        }
        if (status === 403) {
          return new PermissionDeniedError(status, error, message, headers, type);
        }
        if (status === 404) {
          return new NotFoundError(status, error, message, headers, type);
        }
        if (status === 409) {
          return new ConflictError(status, error, message, headers, type);
        }
        if (status === 422) {
          return new UnprocessableEntityError(status, error, message, headers, type);
        }
        if (status === 429) {
          return new RateLimitError(status, error, message, headers, type);
        }
        if (status >= 500) {
          return new InternalServerError(status, error, message, headers, type);
        }
        return new _APIError(status, error, message, headers, type);
      }
    };
    exports2.APIError = APIError;
    var APIUserAbortError = class extends APIError {
      constructor({ message } = {}) {
        super(void 0, void 0, message || "Request was aborted.", void 0);
      }
    };
    exports2.APIUserAbortError = APIUserAbortError;
    var APIConnectionError = class extends APIError {
      constructor({ message, cause }) {
        super(void 0, void 0, message || "Connection error.", void 0);
        if (cause)
          this.cause = cause;
      }
    };
    exports2.APIConnectionError = APIConnectionError;
    var APIConnectionTimeoutError = class extends APIConnectionError {
      constructor({ message } = {}) {
        super({ message: message ?? "Request timed out." });
      }
    };
    exports2.APIConnectionTimeoutError = APIConnectionTimeoutError;
    var RetryableError = class extends AnthropicError {
      constructor(message, { cause } = {}) {
        super(message ?? "Retryable error.");
        if (cause !== void 0)
          this.cause = cause;
      }
    };
    exports2.RetryableError = RetryableError;
    var BadRequestError = class extends APIError {
    };
    exports2.BadRequestError = BadRequestError;
    var AuthenticationError = class extends APIError {
    };
    exports2.AuthenticationError = AuthenticationError;
    var PermissionDeniedError = class extends APIError {
    };
    exports2.PermissionDeniedError = PermissionDeniedError;
    var NotFoundError = class extends APIError {
    };
    exports2.NotFoundError = NotFoundError;
    var ConflictError = class extends APIError {
    };
    exports2.ConflictError = ConflictError;
    var UnprocessableEntityError = class extends APIError {
    };
    exports2.UnprocessableEntityError = UnprocessableEntityError;
    var RateLimitError = class extends APIError {
    };
    exports2.RateLimitError = RateLimitError;
    var InternalServerError = class extends APIError {
    };
    exports2.InternalServerError = InternalServerError;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/values.js
var require_values = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/values.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.pop = exports2.safeJSON = exports2.maybeCoerceBoolean = exports2.maybeCoerceFloat = exports2.maybeCoerceInteger = exports2.coerceBoolean = exports2.coerceFloat = exports2.coerceInteger = exports2.validatePositiveInteger = exports2.ensurePresent = exports2.isReadonlyArray = exports2.isArray = exports2.isAbsoluteURL = void 0;
    exports2.maybeObj = maybeObj;
    exports2.isEmptyObj = isEmptyObj;
    exports2.hasOwn = hasOwn;
    exports2.isObj = isObj;
    exports2.checkNever = checkNever;
    var error_1 = require_error();
    var startsWithSchemeRegexp = /^[a-z][a-z0-9+.-]*:/i;
    var isAbsoluteURL = (url) => {
      return startsWithSchemeRegexp.test(url);
    };
    exports2.isAbsoluteURL = isAbsoluteURL;
    var isArray = (val) => (exports2.isArray = Array.isArray, (0, exports2.isArray)(val));
    exports2.isArray = isArray;
    exports2.isReadonlyArray = exports2.isArray;
    function maybeObj(x) {
      if (typeof x !== "object") {
        return {};
      }
      return x ?? {};
    }
    function isEmptyObj(obj) {
      if (!obj)
        return true;
      for (const _k in obj)
        return false;
      return true;
    }
    function hasOwn(obj, key) {
      return Object.prototype.hasOwnProperty.call(obj, key);
    }
    function isObj(obj) {
      return obj != null && typeof obj === "object" && !Array.isArray(obj);
    }
    var ensurePresent = (value) => {
      if (value == null) {
        throw new error_1.AnthropicError(`Expected a value to be given but received ${value} instead.`);
      }
      return value;
    };
    exports2.ensurePresent = ensurePresent;
    var validatePositiveInteger = (name, n) => {
      if (typeof n !== "number" || !Number.isInteger(n)) {
        throw new error_1.AnthropicError(`${name} must be an integer`);
      }
      if (n < 0) {
        throw new error_1.AnthropicError(`${name} must be a positive integer`);
      }
      return n;
    };
    exports2.validatePositiveInteger = validatePositiveInteger;
    var coerceInteger = (value) => {
      if (typeof value === "number")
        return Math.round(value);
      if (typeof value === "string")
        return parseInt(value, 10);
      throw new error_1.AnthropicError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
    };
    exports2.coerceInteger = coerceInteger;
    var coerceFloat = (value) => {
      if (typeof value === "number")
        return value;
      if (typeof value === "string")
        return parseFloat(value);
      throw new error_1.AnthropicError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
    };
    exports2.coerceFloat = coerceFloat;
    var coerceBoolean = (value) => {
      if (typeof value === "boolean")
        return value;
      if (typeof value === "string")
        return value === "true";
      return Boolean(value);
    };
    exports2.coerceBoolean = coerceBoolean;
    var maybeCoerceInteger = (value) => {
      if (value == null) {
        return void 0;
      }
      return (0, exports2.coerceInteger)(value);
    };
    exports2.maybeCoerceInteger = maybeCoerceInteger;
    var maybeCoerceFloat = (value) => {
      if (value == null) {
        return void 0;
      }
      return (0, exports2.coerceFloat)(value);
    };
    exports2.maybeCoerceFloat = maybeCoerceFloat;
    var maybeCoerceBoolean = (value) => {
      if (value == null) {
        return void 0;
      }
      return (0, exports2.coerceBoolean)(value);
    };
    exports2.maybeCoerceBoolean = maybeCoerceBoolean;
    var safeJSON = (text) => {
      try {
        return JSON.parse(text);
      } catch (err) {
        return void 0;
      }
    };
    exports2.safeJSON = safeJSON;
    var pop = (obj, key) => {
      const value = obj[key];
      delete obj[key];
      return value;
    };
    exports2.pop = pop;
    function checkNever(_value) {
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/sleep.js
var require_sleep = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/sleep.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.sleep = void 0;
    var sleep = (ms, signal) => new Promise((resolve) => {
      if (signal?.aborted)
        return resolve();
      const onAbort = () => {
        clearTimeout(timer);
        resolve();
      };
      const timer = setTimeout(() => {
        signal?.removeEventListener("abort", onAbort);
        resolve();
      }, ms);
      signal?.addEventListener("abort", onAbort, { once: true });
    });
    exports2.sleep = sleep;
  }
});

// node_modules/@anthropic-ai/sdk/version.js
var require_version = __commonJS({
  "node_modules/@anthropic-ai/sdk/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.128.0";
  }
});

// node_modules/@anthropic-ai/sdk/internal/detect-platform.js
var require_detect_platform = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/detect-platform.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getPlatformHeaders = exports2.isRunningInBrowser = void 0;
    var version_1 = require_version();
    var isRunningInBrowser = () => {
      return (
        // @ts-ignore
        typeof window !== "undefined" && // @ts-ignore
        typeof window.document !== "undefined" && // @ts-ignore
        typeof navigator !== "undefined"
      );
    };
    exports2.isRunningInBrowser = isRunningInBrowser;
    function getDetectedPlatform() {
      if (typeof Deno !== "undefined" && Deno.build != null) {
        return "deno";
      }
      if (typeof EdgeRuntime !== "undefined") {
        return "edge";
      }
      if (Object.prototype.toString.call(typeof globalThis.process !== "undefined" ? globalThis.process : 0) === "[object process]") {
        return "node";
      }
      return "unknown";
    }
    var getPlatformProperties = () => {
      const detectedPlatform = getDetectedPlatform();
      if (detectedPlatform === "deno") {
        return {
          "X-Stainless-Lang": "js",
          "X-Stainless-Package-Version": version_1.VERSION,
          "X-Stainless-OS": normalizePlatform(Deno.build.os),
          "X-Stainless-Arch": normalizeArch(Deno.build.arch),
          "X-Stainless-Runtime": "deno",
          "X-Stainless-Runtime-Version": typeof Deno.version === "string" ? Deno.version : Deno.version?.deno ?? "unknown"
        };
      }
      if (typeof EdgeRuntime !== "undefined") {
        return {
          "X-Stainless-Lang": "js",
          "X-Stainless-Package-Version": version_1.VERSION,
          "X-Stainless-OS": "Unknown",
          "X-Stainless-Arch": `other:${EdgeRuntime}`,
          "X-Stainless-Runtime": "edge",
          "X-Stainless-Runtime-Version": globalThis.process?.version ?? "unknown"
        };
      }
      if (detectedPlatform === "node") {
        return {
          "X-Stainless-Lang": "js",
          "X-Stainless-Package-Version": version_1.VERSION,
          "X-Stainless-OS": normalizePlatform(globalThis.process.platform ?? "unknown"),
          "X-Stainless-Arch": normalizeArch(globalThis.process.arch ?? "unknown"),
          "X-Stainless-Runtime": "node",
          "X-Stainless-Runtime-Version": globalThis.process.version ?? "unknown"
        };
      }
      const browserInfo = getBrowserInfo();
      if (browserInfo) {
        return {
          "X-Stainless-Lang": "js",
          "X-Stainless-Package-Version": version_1.VERSION,
          "X-Stainless-OS": "Unknown",
          "X-Stainless-Arch": "unknown",
          "X-Stainless-Runtime": `browser:${browserInfo.browser}`,
          "X-Stainless-Runtime-Version": browserInfo.version
        };
      }
      return {
        "X-Stainless-Lang": "js",
        "X-Stainless-Package-Version": version_1.VERSION,
        "X-Stainless-OS": "Unknown",
        "X-Stainless-Arch": "unknown",
        "X-Stainless-Runtime": "unknown",
        "X-Stainless-Runtime-Version": "unknown"
      };
    };
    function getBrowserInfo() {
      if (typeof navigator === "undefined" || !navigator) {
        return null;
      }
      const browserPatterns = [
        { key: "edge", pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: "ie", pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: "ie", pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: "chrome", pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: "firefox", pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: "safari", pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ }
      ];
      for (const { key, pattern } of browserPatterns) {
        const match = pattern.exec(navigator.userAgent);
        if (match) {
          const major = match[1] || 0;
          const minor = match[2] || 0;
          const patch = match[3] || 0;
          return { browser: key, version: `${major}.${minor}.${patch}` };
        }
      }
      return null;
    }
    var normalizeArch = (arch) => {
      if (arch === "x32")
        return "x32";
      if (arch === "x86_64" || arch === "x64")
        return "x64";
      if (arch === "arm")
        return "arm";
      if (arch === "aarch64" || arch === "arm64")
        return "arm64";
      if (arch)
        return `other:${arch}`;
      return "unknown";
    };
    var normalizePlatform = (platform) => {
      platform = platform.toLowerCase();
      if (platform.includes("ios"))
        return "iOS";
      if (platform === "android")
        return "Android";
      if (platform === "darwin")
        return "MacOS";
      if (platform === "win32")
        return "Windows";
      if (platform === "freebsd")
        return "FreeBSD";
      if (platform === "openbsd")
        return "OpenBSD";
      if (platform === "linux")
        return "Linux";
      if (platform)
        return `Other:${platform}`;
      return "Unknown";
    };
    var _platformHeaders;
    var getPlatformHeaders = () => {
      return _platformHeaders ?? (_platformHeaders = getPlatformProperties());
    };
    exports2.getPlatformHeaders = getPlatformHeaders;
  }
});

// node_modules/@anthropic-ai/sdk/internal/request-signal.js
var require_request_signal = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/request-signal.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.registerRequestSignalCleanup = registerRequestSignalCleanup;
    exports2.armAbandonmentBackstop = armAbandonmentBackstop;
    exports2.releaseRequestSignal = releaseRequestSignal;
    var cleanups = /* @__PURE__ */ new WeakMap();
    var registry = typeof globalThis.FinalizationRegistry === "function" ? new globalThis.FinalizationRegistry((controller) => releaseRequestSignal(controller)) : null;
    function makeCleanup(signal, listener) {
      return () => signal.removeEventListener("abort", listener);
    }
    function registerRequestSignalCleanup(controller, signal, listener) {
      cleanups.set(controller, makeCleanup(signal, listener));
    }
    function armAbandonmentBackstop(body, controller) {
      if (cleanups.has(controller))
        registry?.register(body, controller, controller);
    }
    function releaseRequestSignal(controller) {
      const cleanup = cleanups.get(controller);
      if (cleanup) {
        cleanups.delete(controller);
        registry?.unregister(controller);
        cleanup();
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/shims.js
var require_shims = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/shims.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getDefaultFetch = getDefaultFetch;
    exports2.makeReadableStream = makeReadableStream;
    exports2.ReadableStreamFrom = ReadableStreamFrom;
    exports2.ReadableStreamToAsyncIterable = ReadableStreamToAsyncIterable;
    exports2.CancelReadableStream = CancelReadableStream;
    function getDefaultFetch() {
      if (typeof fetch !== "undefined") {
        return fetch;
      }
      throw new Error("`fetch` is not defined as a global; Either pass `fetch` to the client, `new Anthropic({ fetch })` or polyfill the global, `globalThis.fetch = fetch`");
    }
    function makeReadableStream(...args) {
      const ReadableStream2 = globalThis.ReadableStream;
      if (typeof ReadableStream2 === "undefined") {
        throw new Error("`ReadableStream` is not defined as a global; You will need to polyfill it, `globalThis.ReadableStream = ReadableStream`");
      }
      return new ReadableStream2(...args);
    }
    function ReadableStreamFrom(iterable) {
      let iter = Symbol.asyncIterator in iterable ? iterable[Symbol.asyncIterator]() : iterable[Symbol.iterator]();
      return makeReadableStream({
        start() {
        },
        async pull(controller) {
          const { done, value } = await iter.next();
          if (done) {
            controller.close();
          } else {
            controller.enqueue(value);
          }
        },
        async cancel() {
          await iter.return?.();
        }
      });
    }
    function ReadableStreamToAsyncIterable(stream) {
      if (stream[Symbol.asyncIterator])
        return stream;
      const reader = stream.getReader();
      return {
        async next() {
          try {
            const result = await reader.read();
            if (result?.done)
              reader.releaseLock();
            return result;
          } catch (e) {
            reader.releaseLock();
            throw e;
          }
        },
        async return() {
          const cancelPromise = reader.cancel();
          reader.releaseLock();
          await cancelPromise;
          return { done: true, value: void 0 };
        },
        [Symbol.asyncIterator]() {
          return this;
        }
      };
    }
    async function CancelReadableStream(stream) {
      if (stream === null || typeof stream !== "object")
        return;
      if (stream[Symbol.asyncIterator]) {
        await stream[Symbol.asyncIterator]().return?.();
        return;
      }
      const reader = stream.getReader();
      const cancelPromise = reader.cancel();
      reader.releaseLock();
      await cancelPromise;
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/request-options.js
var require_request_options = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/request-options.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.FallbackEncoder = exports2.BetaFallbackState = void 0;
    var BetaFallbackState = class {
    };
    exports2.BetaFallbackState = BetaFallbackState;
    var FallbackEncoder = ({ headers, body }) => {
      return {
        bodyHeaders: {
          "content-type": "application/json"
        },
        body: JSON.stringify(body)
      };
    };
    exports2.FallbackEncoder = FallbackEncoder;
  }
});

// node_modules/@anthropic-ai/sdk/internal/qs/formats.js
var require_formats = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/qs/formats.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RFC3986 = exports2.RFC1738 = exports2.formatters = exports2.default_formatter = exports2.default_format = void 0;
    exports2.default_format = "RFC3986";
    var default_formatter = (v) => String(v);
    exports2.default_formatter = default_formatter;
    exports2.formatters = {
      RFC1738: (v) => String(v).replace(/%20/g, "+"),
      RFC3986: exports2.default_formatter
    };
    exports2.RFC1738 = "RFC1738";
    exports2.RFC3986 = "RFC3986";
  }
});

// node_modules/@anthropic-ai/sdk/internal/qs/utils.js
var require_utils = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/qs/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.encode = exports2.has = void 0;
    exports2.merge = merge;
    exports2.assign_single_source = assign_single_source;
    exports2.decode = decode;
    exports2.compact = compact;
    exports2.is_regexp = is_regexp;
    exports2.is_buffer = is_buffer;
    exports2.combine = combine;
    exports2.maybe_map = maybe_map;
    var formats_1 = require_formats();
    var values_1 = require_values();
    var has = (obj, key) => (exports2.has = Object.hasOwn ?? Function.prototype.call.bind(Object.prototype.hasOwnProperty), (0, exports2.has)(obj, key));
    exports2.has = has;
    var hex_table = /* @__PURE__ */ (() => {
      const array = [];
      for (let i = 0; i < 256; ++i) {
        array.push("%" + ((i < 16 ? "0" : "") + i.toString(16)).toUpperCase());
      }
      return array;
    })();
    function compact_queue(queue) {
      while (queue.length > 1) {
        const item = queue.pop();
        if (!item)
          continue;
        const obj = item.obj[item.prop];
        if ((0, values_1.isArray)(obj)) {
          const compacted = [];
          for (let j = 0; j < obj.length; ++j) {
            if (typeof obj[j] !== "undefined") {
              compacted.push(obj[j]);
            }
          }
          item.obj[item.prop] = compacted;
        }
      }
    }
    function array_to_object(source, options) {
      const obj = options && options.plainObjects ? /* @__PURE__ */ Object.create(null) : {};
      for (let i = 0; i < source.length; ++i) {
        if (typeof source[i] !== "undefined") {
          obj[i] = source[i];
        }
      }
      return obj;
    }
    function merge(target, source, options = {}) {
      if (!source) {
        return target;
      }
      if (typeof source !== "object") {
        if ((0, values_1.isArray)(target)) {
          target.push(source);
        } else if (target && typeof target === "object") {
          if (options && (options.plainObjects || options.allowPrototypes) || !(0, exports2.has)(Object.prototype, source)) {
            target[source] = true;
          }
        } else {
          return [target, source];
        }
        return target;
      }
      if (!target || typeof target !== "object") {
        return [target].concat(source);
      }
      let mergeTarget = target;
      if ((0, values_1.isArray)(target) && !(0, values_1.isArray)(source)) {
        mergeTarget = array_to_object(target, options);
      }
      if ((0, values_1.isArray)(target) && (0, values_1.isArray)(source)) {
        source.forEach(function(item, i) {
          if ((0, exports2.has)(target, i)) {
            const targetItem = target[i];
            if (targetItem && typeof targetItem === "object" && item && typeof item === "object") {
              target[i] = merge(targetItem, item, options);
            } else {
              target.push(item);
            }
          } else {
            target[i] = item;
          }
        });
        return target;
      }
      return Object.keys(source).reduce(function(acc, key) {
        const value = source[key];
        if ((0, exports2.has)(acc, key)) {
          acc[key] = merge(acc[key], value, options);
        } else {
          acc[key] = value;
        }
        return acc;
      }, mergeTarget);
    }
    function assign_single_source(target, source) {
      return Object.keys(source).reduce(function(acc, key) {
        acc[key] = source[key];
        return acc;
      }, target);
    }
    function decode(str, _, charset) {
      const strWithoutPlus = str.replace(/\+/g, " ");
      if (charset === "iso-8859-1") {
        return strWithoutPlus.replace(/%[0-9a-f]{2}/gi, unescape);
      }
      try {
        return decodeURIComponent(strWithoutPlus);
      } catch (e) {
        return strWithoutPlus;
      }
    }
    var limit = 1024;
    var encode = (str, _defaultEncoder, charset, _kind, format) => {
      if (str.length === 0) {
        return str;
      }
      let string = str;
      if (typeof str === "symbol") {
        string = Symbol.prototype.toString.call(str);
      } else if (typeof str !== "string") {
        string = String(str);
      }
      if (charset === "iso-8859-1") {
        return escape(string).replace(/%u[0-9a-f]{4}/gi, function($0) {
          return "%26%23" + parseInt($0.slice(2), 16) + "%3B";
        });
      }
      let out = "";
      for (let j = 0; j < string.length; j += limit) {
        const segment = string.length >= limit ? string.slice(j, j + limit) : string;
        const arr = [];
        for (let i = 0; i < segment.length; ++i) {
          let c = segment.charCodeAt(i);
          if (c === 45 || // -
          c === 46 || // .
          c === 95 || // _
          c === 126 || // ~
          c >= 48 && c <= 57 || // 0-9
          c >= 65 && c <= 90 || // a-z
          c >= 97 && c <= 122 || // A-Z
          format === formats_1.RFC1738 && (c === 40 || c === 41)) {
            arr[arr.length] = segment.charAt(i);
            continue;
          }
          if (c < 128) {
            arr[arr.length] = hex_table[c];
            continue;
          }
          if (c < 2048) {
            arr[arr.length] = hex_table[192 | c >> 6] + hex_table[128 | c & 63];
            continue;
          }
          if (c < 55296 || c >= 57344) {
            arr[arr.length] = hex_table[224 | c >> 12] + hex_table[128 | c >> 6 & 63] + hex_table[128 | c & 63];
            continue;
          }
          i += 1;
          c = 65536 + ((c & 1023) << 10 | segment.charCodeAt(i) & 1023);
          arr[arr.length] = hex_table[240 | c >> 18] + hex_table[128 | c >> 12 & 63] + hex_table[128 | c >> 6 & 63] + hex_table[128 | c & 63];
        }
        out += arr.join("");
      }
      return out;
    };
    exports2.encode = encode;
    function compact(value) {
      const queue = [{ obj: { o: value }, prop: "o" }];
      const refs = [];
      for (let i = 0; i < queue.length; ++i) {
        const item = queue[i];
        const obj = item.obj[item.prop];
        const keys = Object.keys(obj);
        for (let j = 0; j < keys.length; ++j) {
          const key = keys[j];
          const val = obj[key];
          if (typeof val === "object" && val !== null && refs.indexOf(val) === -1) {
            queue.push({ obj, prop: key });
            refs.push(val);
          }
        }
      }
      compact_queue(queue);
      return value;
    }
    function is_regexp(obj) {
      return Object.prototype.toString.call(obj) === "[object RegExp]";
    }
    function is_buffer(obj) {
      if (!obj || typeof obj !== "object") {
        return false;
      }
      return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
    }
    function combine(a, b) {
      return [].concat(a, b);
    }
    function maybe_map(val, fn) {
      if ((0, values_1.isArray)(val)) {
        const mapped = [];
        for (let i = 0; i < val.length; i += 1) {
          mapped.push(fn(val[i]));
        }
        return mapped;
      }
      return fn(val);
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/qs/stringify.js
var require_stringify = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/qs/stringify.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.stringify = stringify;
    var utils_1 = require_utils();
    var formats_1 = require_formats();
    var values_1 = require_values();
    var array_prefix_generators = {
      brackets(prefix) {
        return String(prefix) + "[]";
      },
      comma: "comma",
      indices(prefix, key) {
        return String(prefix) + "[" + key + "]";
      },
      repeat(prefix) {
        return String(prefix);
      }
    };
    var push_to_array = function(arr, value_or_array) {
      Array.prototype.push.apply(arr, (0, values_1.isArray)(value_or_array) ? value_or_array : [value_or_array]);
    };
    var toISOString;
    var defaults = {
      addQueryPrefix: false,
      allowDots: false,
      allowEmptyArrays: false,
      arrayFormat: "indices",
      charset: "utf-8",
      charsetSentinel: false,
      delimiter: "&",
      encode: true,
      encodeDotInKeys: false,
      encoder: utils_1.encode,
      encodeValuesOnly: false,
      format: formats_1.default_format,
      formatter: formats_1.default_formatter,
      /** @deprecated */
      indices: false,
      serializeDate(date) {
        return (toISOString ?? (toISOString = Function.prototype.call.bind(Date.prototype.toISOString)))(date);
      },
      skipNulls: false,
      strictNullHandling: false
    };
    function is_non_nullish_primitive(v) {
      return typeof v === "string" || typeof v === "number" || typeof v === "boolean" || typeof v === "symbol" || typeof v === "bigint";
    }
    var sentinel = {};
    function inner_stringify(object, prefix, generateArrayPrefix, commaRoundTrip, allowEmptyArrays, strictNullHandling, skipNulls, encodeDotInKeys, encoder, filter, sort, allowDots, serializeDate, format, formatter, encodeValuesOnly, charset, sideChannel) {
      let obj = object;
      let tmp_sc = sideChannel;
      let step = 0;
      let find_flag = false;
      while ((tmp_sc = tmp_sc.get(sentinel)) !== void 0 && !find_flag) {
        const pos = tmp_sc.get(object);
        step += 1;
        if (typeof pos !== "undefined") {
          if (pos === step) {
            throw new RangeError("Cyclic object value");
          } else {
            find_flag = true;
          }
        }
        if (typeof tmp_sc.get(sentinel) === "undefined") {
          step = 0;
        }
      }
      if (typeof filter === "function") {
        obj = filter(prefix, obj);
      } else if (obj instanceof Date) {
        obj = serializeDate?.(obj);
      } else if (generateArrayPrefix === "comma" && (0, values_1.isArray)(obj)) {
        obj = (0, utils_1.maybe_map)(obj, function(value) {
          if (value instanceof Date) {
            return serializeDate?.(value);
          }
          return value;
        });
      }
      if (obj === null) {
        if (strictNullHandling) {
          return encoder && !encodeValuesOnly ? (
            // @ts-expect-error
            encoder(prefix, defaults.encoder, charset, "key", format)
          ) : prefix;
        }
        obj = "";
      }
      if (is_non_nullish_primitive(obj) || (0, utils_1.is_buffer)(obj)) {
        if (encoder) {
          const key_value = encodeValuesOnly ? prefix : encoder(prefix, defaults.encoder, charset, "key", format);
          return [
            formatter?.(key_value) + "=" + // @ts-expect-error
            formatter?.(encoder(obj, defaults.encoder, charset, "value", format))
          ];
        }
        return [formatter?.(prefix) + "=" + formatter?.(String(obj))];
      }
      const values = [];
      if (typeof obj === "undefined") {
        return values;
      }
      let obj_keys;
      if (generateArrayPrefix === "comma" && (0, values_1.isArray)(obj)) {
        if (encodeValuesOnly && encoder) {
          obj = (0, utils_1.maybe_map)(obj, encoder);
        }
        obj_keys = [{ value: obj.length > 0 ? obj.join(",") || null : void 0 }];
      } else if ((0, values_1.isArray)(filter)) {
        obj_keys = filter;
      } else {
        const keys = Object.keys(obj);
        obj_keys = sort ? keys.sort(sort) : keys;
      }
      const encoded_prefix = encodeDotInKeys ? String(prefix).replace(/\./g, "%2E") : String(prefix);
      const adjusted_prefix = commaRoundTrip && (0, values_1.isArray)(obj) && obj.length === 1 ? encoded_prefix + "[]" : encoded_prefix;
      if (allowEmptyArrays && (0, values_1.isArray)(obj) && obj.length === 0) {
        return adjusted_prefix + "[]";
      }
      for (let j = 0; j < obj_keys.length; ++j) {
        const key = obj_keys[j];
        const value = (
          // @ts-ignore
          typeof key === "object" && typeof key.value !== "undefined" ? key.value : obj[key]
        );
        if (skipNulls && value === null) {
          continue;
        }
        const encoded_key = allowDots && encodeDotInKeys ? key.replace(/\./g, "%2E") : key;
        const key_prefix = (0, values_1.isArray)(obj) ? typeof generateArrayPrefix === "function" ? generateArrayPrefix(adjusted_prefix, encoded_key) : adjusted_prefix : adjusted_prefix + (allowDots ? "." + encoded_key : "[" + encoded_key + "]");
        sideChannel.set(object, step);
        const valueSideChannel = /* @__PURE__ */ new WeakMap();
        valueSideChannel.set(sentinel, sideChannel);
        push_to_array(values, inner_stringify(
          value,
          key_prefix,
          generateArrayPrefix,
          commaRoundTrip,
          allowEmptyArrays,
          strictNullHandling,
          skipNulls,
          encodeDotInKeys,
          // @ts-ignore
          generateArrayPrefix === "comma" && encodeValuesOnly && (0, values_1.isArray)(obj) ? null : encoder,
          filter,
          sort,
          allowDots,
          serializeDate,
          format,
          formatter,
          encodeValuesOnly,
          charset,
          valueSideChannel
        ));
      }
      return values;
    }
    function normalize_stringify_options(opts = defaults) {
      if (typeof opts.allowEmptyArrays !== "undefined" && typeof opts.allowEmptyArrays !== "boolean") {
        throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
      }
      if (typeof opts.encodeDotInKeys !== "undefined" && typeof opts.encodeDotInKeys !== "boolean") {
        throw new TypeError("`encodeDotInKeys` option can only be `true` or `false`, when provided");
      }
      if (opts.encoder !== null && typeof opts.encoder !== "undefined" && typeof opts.encoder !== "function") {
        throw new TypeError("Encoder has to be a function.");
      }
      const charset = opts.charset || defaults.charset;
      if (typeof opts.charset !== "undefined" && opts.charset !== "utf-8" && opts.charset !== "iso-8859-1") {
        throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
      }
      let format = formats_1.default_format;
      if (typeof opts.format !== "undefined") {
        if (!(0, utils_1.has)(formats_1.formatters, opts.format)) {
          throw new TypeError("Unknown format option provided.");
        }
        format = opts.format;
      }
      const formatter = formats_1.formatters[format];
      let filter = defaults.filter;
      if (typeof opts.filter === "function" || (0, values_1.isArray)(opts.filter)) {
        filter = opts.filter;
      }
      let arrayFormat;
      if (opts.arrayFormat && opts.arrayFormat in array_prefix_generators) {
        arrayFormat = opts.arrayFormat;
      } else if ("indices" in opts) {
        arrayFormat = opts.indices ? "indices" : "repeat";
      } else {
        arrayFormat = defaults.arrayFormat;
      }
      if ("commaRoundTrip" in opts && typeof opts.commaRoundTrip !== "boolean") {
        throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
      }
      const allowDots = typeof opts.allowDots === "undefined" ? !!opts.encodeDotInKeys === true ? true : defaults.allowDots : !!opts.allowDots;
      return {
        addQueryPrefix: typeof opts.addQueryPrefix === "boolean" ? opts.addQueryPrefix : defaults.addQueryPrefix,
        // @ts-ignore
        allowDots,
        allowEmptyArrays: typeof opts.allowEmptyArrays === "boolean" ? !!opts.allowEmptyArrays : defaults.allowEmptyArrays,
        arrayFormat,
        charset,
        charsetSentinel: typeof opts.charsetSentinel === "boolean" ? opts.charsetSentinel : defaults.charsetSentinel,
        commaRoundTrip: !!opts.commaRoundTrip,
        delimiter: typeof opts.delimiter === "undefined" ? defaults.delimiter : opts.delimiter,
        encode: typeof opts.encode === "boolean" ? opts.encode : defaults.encode,
        encodeDotInKeys: typeof opts.encodeDotInKeys === "boolean" ? opts.encodeDotInKeys : defaults.encodeDotInKeys,
        encoder: typeof opts.encoder === "function" ? opts.encoder : defaults.encoder,
        encodeValuesOnly: typeof opts.encodeValuesOnly === "boolean" ? opts.encodeValuesOnly : defaults.encodeValuesOnly,
        filter,
        format,
        formatter,
        serializeDate: typeof opts.serializeDate === "function" ? opts.serializeDate : defaults.serializeDate,
        skipNulls: typeof opts.skipNulls === "boolean" ? opts.skipNulls : defaults.skipNulls,
        // @ts-ignore
        sort: typeof opts.sort === "function" ? opts.sort : null,
        strictNullHandling: typeof opts.strictNullHandling === "boolean" ? opts.strictNullHandling : defaults.strictNullHandling
      };
    }
    function stringify(object, opts = {}) {
      let obj = object;
      const options = normalize_stringify_options(opts);
      let obj_keys;
      let filter;
      if (typeof options.filter === "function") {
        filter = options.filter;
        obj = filter("", obj);
      } else if ((0, values_1.isArray)(options.filter)) {
        filter = options.filter;
        obj_keys = filter;
      }
      const keys = [];
      if (typeof obj !== "object" || obj === null) {
        return "";
      }
      const generateArrayPrefix = array_prefix_generators[options.arrayFormat];
      const commaRoundTrip = generateArrayPrefix === "comma" && options.commaRoundTrip;
      if (!obj_keys) {
        obj_keys = Object.keys(obj);
      }
      if (options.sort) {
        obj_keys.sort(options.sort);
      }
      const sideChannel = /* @__PURE__ */ new WeakMap();
      for (let i = 0; i < obj_keys.length; ++i) {
        const key = obj_keys[i];
        if (options.skipNulls && obj[key] === null) {
          continue;
        }
        push_to_array(keys, inner_stringify(
          obj[key],
          key,
          // @ts-expect-error
          generateArrayPrefix,
          commaRoundTrip,
          options.allowEmptyArrays,
          options.strictNullHandling,
          options.skipNulls,
          options.encodeDotInKeys,
          options.encode ? options.encoder : null,
          options.filter,
          options.sort,
          options.allowDots,
          options.serializeDate,
          options.format,
          options.formatter,
          options.encodeValuesOnly,
          options.charset,
          sideChannel
        ));
      }
      const joined = keys.join(options.delimiter);
      let prefix = options.addQueryPrefix === true ? "?" : "";
      if (options.charsetSentinel) {
        if (options.charset === "iso-8859-1") {
          prefix += "utf8=%26%2310003%3B&";
        } else {
          prefix += "utf8=%E2%9C%93&";
        }
      }
      return joined.length > 0 ? prefix + joined : "";
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/query.js
var require_query = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/query.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.stringifyQuery = stringifyQuery;
    var tslib_1 = require_tslib();
    var qs = tslib_1.__importStar(require_stringify());
    function stringifyQuery(query) {
      return qs.stringify(query, { arrayFormat: "brackets" });
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/node.js
var require_node = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/node.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.util = exports2.stream = exports2.path = exports2.os = exports2.fs = exports2.crypto = exports2.child_process = void 0;
    var tslib_1 = require_tslib();
    var child_process = tslib_1.__importStar(require("node:child_process"));
    exports2.child_process = child_process;
    var crypto2 = tslib_1.__importStar(require("node:crypto"));
    exports2.crypto = crypto2;
    var fs2 = tslib_1.__importStar(require("node:fs"));
    exports2.fs = fs2;
    var os = tslib_1.__importStar(require("node:os"));
    exports2.os = os;
    var path2 = tslib_1.__importStar(require("node:path"));
    exports2.path = path2;
    var stream = tslib_1.__importStar(require("node:stream"));
    exports2.stream = stream;
    var util = tslib_1.__importStar(require("node:util"));
    exports2.util = util;
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/types.js
var require_types = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/types.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.WorkloadIdentityError = exports2.ADVISORY_REFRESH_BACKOFF_IN_SECONDS = exports2.MANDATORY_REFRESH_THRESHOLD_IN_SECONDS = exports2.ADVISORY_REFRESH_THRESHOLD_IN_SECONDS = exports2.FEDERATION_BETA_HEADER = exports2.OAUTH_API_BETA_HEADER = exports2.TOKEN_ENDPOINT = exports2.GRANT_TYPE_REFRESH_TOKEN = exports2.GRANT_TYPE_JWT_BEARER = void 0;
    exports2.requireSecureTokenEndpoint = requireSecureTokenEndpoint;
    exports2.parseTokenResponse = parseTokenResponse;
    exports2.redactSensitive = redactSensitive;
    exports2.checkCredentialsFileSafety = checkCredentialsFileSafety;
    exports2.writeCredentialsFileAtomic = writeCredentialsFileAtomic;
    var error_1 = require_error();
    exports2.GRANT_TYPE_JWT_BEARER = "urn:ietf:params:oauth:grant-type:jwt-bearer";
    exports2.GRANT_TYPE_REFRESH_TOKEN = "refresh_token";
    exports2.TOKEN_ENDPOINT = "/v1/oauth/token";
    exports2.OAUTH_API_BETA_HEADER = "oauth-2025-04-20";
    exports2.FEDERATION_BETA_HEADER = "oidc-federation-2026-04-01";
    exports2.ADVISORY_REFRESH_THRESHOLD_IN_SECONDS = 120;
    exports2.MANDATORY_REFRESH_THRESHOLD_IN_SECONDS = 30;
    exports2.ADVISORY_REFRESH_BACKOFF_IN_SECONDS = 5;
    var MAX_TOKEN_RESPONSE_BYTES = 1 << 20;
    function requireSecureTokenEndpoint(baseURL) {
      if (!baseURL)
        return;
      let u;
      try {
        u = new URL(baseURL);
      } catch (err) {
        throw new WorkloadIdentityError(`Invalid token endpoint base URL "${baseURL}": ${err}`);
      }
      if (u.protocol === "https:")
        return;
      const host = u.hostname.toLowerCase().replace(/^\[|\]$/g, "");
      if (u.protocol === "http:" && (host === "localhost" || host === "127.0.0.1" || host === "::1")) {
        return;
      }
      throw new WorkloadIdentityError(`Refusing to send credential over non-https token endpoint "${baseURL}"`);
    }
    async function parseTokenResponse(resp, requestId) {
      const text = await readLimitedText(resp);
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        throw new WorkloadIdentityError(`Token endpoint returned non-JSON response (status ${resp.status})`, resp.status, redactSensitive(text), requestId);
      }
      if (!data.access_token) {
        throw new WorkloadIdentityError(`Token endpoint response missing access_token: ${JSON.stringify(redactSensitive(data))}`, resp.status, redactSensitive(data), requestId);
      }
      if (data.token_type && data.token_type.toLowerCase() !== "bearer") {
        throw new WorkloadIdentityError(`Token endpoint response: unsupported token_type "${data.token_type}" (want Bearer)`, resp.status, redactSensitive(data), requestId);
      }
      return data;
    }
    var MAX_ERROR_BODY_CHARS = 2e3;
    var SAFE_ERROR_KEYS = /* @__PURE__ */ new Set(["error", "error_description", "error_uri"]);
    function redactSensitive(body) {
      if (body == null)
        return body;
      if (typeof body === "string") {
        let parsed;
        try {
          parsed = JSON.parse(body);
        } catch {
          if (body.length <= MAX_ERROR_BODY_CHARS)
            return body;
          return body.slice(0, MAX_ERROR_BODY_CHARS) + `... <${body.length - MAX_ERROR_BODY_CHARS} more chars>`;
        }
        return JSON.stringify(redactSensitive(parsed));
      }
      if (typeof body === "object" && !Array.isArray(body)) {
        const out = {};
        for (const [k, v] of Object.entries(body)) {
          if (SAFE_ERROR_KEYS.has(k))
            out[k] = v;
        }
        return out;
      }
      return null;
    }
    async function checkCredentialsFileSafety(path2, onWarn = (m) => console.warn(`anthropic-sdk: ${m}`)) {
      if (typeof process === "undefined" || process.platform === "win32")
        return;
      const { fs: fs2 } = await Promise.resolve().then(() => __importStar(require_node()));
      let resolved = path2;
      let st;
      try {
        resolved = await fs2.promises.realpath(path2);
        st = await fs2.promises.stat(resolved);
      } catch {
        return;
      }
      const mode = st.mode & 511;
      if (mode & 18) {
        throw new WorkloadIdentityError(`Credentials file at ${resolved} is group/world-writable (mode 0o${mode.toString(8)}); this allows other local users to plant tokens. Run \`chmod 600 ${resolved}\`.`);
      }
      if (mode & 36) {
        throw new WorkloadIdentityError(`Credentials file at ${resolved} is group/world-readable (mode 0o${mode.toString(8)}); run \`chmod 600 ${resolved}\` before retrying.`);
      }
      if (typeof process.getuid === "function" && st.uid !== process.getuid()) {
        onWarn(`credentials file at ${resolved} is owned by uid ${st.uid} (current process uid ${process.getuid()}); verify this is intentional.`);
      }
    }
    async function writeCredentialsFileAtomic(targetPath, data) {
      const { fs: fs2, path: path2 } = await Promise.resolve().then(() => __importStar(require_node()));
      const dir = path2.dirname(targetPath);
      await fs2.promises.mkdir(dir, { recursive: true, mode: 448 });
      const tmpPath = `${targetPath}.${process.pid}.${Math.random().toString(36).slice(2)}.tmp`;
      try {
        const fh = await fs2.promises.open(tmpPath, "w", 384);
        try {
          await fh.writeFile(JSON.stringify(data, null, 2));
          await fh.sync();
        } finally {
          await fh.close();
        }
        await fs2.promises.rename(tmpPath, targetPath);
      } catch (err) {
        await fs2.promises.unlink(tmpPath).catch(() => {
        });
        throw err;
      }
      try {
        const dirFh = await fs2.promises.open(dir, "r");
        try {
          await dirFh.sync();
        } finally {
          await dirFh.close();
        }
      } catch {
      }
    }
    async function readLimitedText(resp) {
      if (!resp.body) {
        return "";
      }
      const reader = resp.body.getReader();
      const chunks = [];
      let received = 0;
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done)
          break;
        if (received + value.length > MAX_TOKEN_RESPONSE_BYTES) {
          const remaining = MAX_TOKEN_RESPONSE_BYTES - received;
          if (remaining > 0)
            chunks.push(value.subarray(0, remaining));
          await reader.cancel();
          break;
        }
        chunks.push(value);
        received += value.length;
      }
      let merged;
      if (chunks.length === 1) {
        merged = chunks[0];
      } else {
        merged = new Uint8Array(chunks.reduce((n, c) => n + c.length, 0));
        let offset = 0;
        for (const c of chunks) {
          merged.set(c, offset);
          offset += c.length;
        }
      }
      return new TextDecoder("utf-8").decode(merged);
    }
    var WorkloadIdentityError = class extends error_1.AnthropicError {
      constructor(message, statusCode = null, body = null, requestId = null) {
        super(message);
        this.statusCode = statusCode;
        this.body = body;
        this.requestId = requestId;
      }
    };
    exports2.WorkloadIdentityError = WorkloadIdentityError;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/time.js
var require_time = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/time.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.nowAsSeconds = nowAsSeconds;
    function nowAsSeconds() {
      return Math.floor(Date.now() / 1e3);
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/token-cache.js
var require_token_cache = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/token-cache.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TokenCache = void 0;
    var types_1 = require_types();
    var time_1 = require_time();
    var TokenCache = class {
      constructor(provider, onAdvisoryRefreshError) {
        this.cached = null;
        this.pendingRefresh = null;
        this.nextForce = false;
        this.lastAdvisoryError = 0;
        this.provider = provider;
        this.onAdvisoryRefreshError = onAdvisoryRefreshError;
      }
      async getToken() {
        const force = this.nextForce;
        this.nextForce = false;
        const cached = this.cached;
        if (force || cached == null) {
          const token2 = await this.refresh(force);
          return token2.token;
        }
        if (cached.expiresAt == null) {
          return cached.token;
        }
        const remaining = cached.expiresAt - (0, time_1.nowAsSeconds)();
        if (remaining > types_1.ADVISORY_REFRESH_THRESHOLD_IN_SECONDS) {
          return cached.token;
        }
        if (remaining > types_1.MANDATORY_REFRESH_THRESHOLD_IN_SECONDS) {
          this.backgroundRefresh();
          return cached.token;
        }
        const token = await this.refresh();
        return token.token;
      }
      /**
       * Clears the cached token and marks the next {@link getToken} as a forced
       * refresh, so the underlying provider bypasses any on-disk freshness check.
       * Called after a 401 — the server has just told us the token is bad even
       * if its `expires_at` still looks fresh.
       */
      invalidate() {
        this.cached = null;
        this.nextForce = true;
      }
      /**
       * Mandatory refresh. Joins any in-flight refresh unless forced — a forced
       * refresh must not coalesce into a non-forced one that may re-serve the
       * same stale disk token.
       */
      refresh(force = false) {
        if (this.pendingRefresh && !force) {
          return this.pendingRefresh;
        }
        return this.doRefresh(force);
      }
      /**
       * Advisory background refresh. Shares the same in-flight promise as
       * mandatory refreshes for deduplication, but swallows errors so the
       * stale cached token keeps being served. Backs off for
       * {@link ADVISORY_REFRESH_BACKOFF_IN_SECONDS} after a failure so an
       * outage during the advisory window doesn't hammer the token endpoint.
       */
      backgroundRefresh() {
        if (this.pendingRefresh) {
          return;
        }
        if ((0, time_1.nowAsSeconds)() - this.lastAdvisoryError < types_1.ADVISORY_REFRESH_BACKOFF_IN_SECONDS) {
          return;
        }
        this.doRefresh().catch((err) => {
          this.lastAdvisoryError = (0, time_1.nowAsSeconds)();
          this.onAdvisoryRefreshError?.(err);
        });
      }
      /**
       * Core refresh. Sets {@link pendingRefresh} so concurrent callers
       * (both advisory and mandatory) coalesce into a single provider call.
       */
      doRefresh(force = false) {
        this.pendingRefresh = this.provider(force ? { forceRefresh: true } : void 0).then((token) => {
          this.cached = token;
          this.pendingRefresh = null;
          return token;
        }, (err) => {
          this.pendingRefresh = null;
          throw err;
        });
        return this.pendingRefresh;
      }
    };
    exports2.TokenCache = TokenCache;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/env.js
var require_env = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/env.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.readEnv = void 0;
    var readEnv = (env) => {
      if (typeof globalThis.process !== "undefined") {
        return globalThis.process.env?.[env]?.trim() || void 0;
      }
      if (typeof globalThis.Deno !== "undefined") {
        return globalThis.Deno.env?.get?.(env)?.trim() || void 0;
      }
      return void 0;
    };
    exports2.readEnv = readEnv;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/bytes.js
var require_bytes = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/bytes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.concatBytes = concatBytes;
    exports2.encodeUTF8 = encodeUTF8;
    exports2.decodeUTF8 = decodeUTF8;
    function concatBytes(buffers) {
      let length = 0;
      for (const buffer of buffers) {
        length += buffer.length;
      }
      const output = new Uint8Array(length);
      let index = 0;
      for (const buffer of buffers) {
        output.set(buffer, index);
        index += buffer.length;
      }
      return output;
    }
    var encodeUTF8_;
    function encodeUTF8(str) {
      let encoder;
      return (encodeUTF8_ ?? (encoder = new globalThis.TextEncoder(), encodeUTF8_ = encoder.encode.bind(encoder)))(str);
    }
    var decodeUTF8_;
    function decodeUTF8(bytes) {
      let decoder;
      return (decodeUTF8_ ?? (decoder = new globalThis.TextDecoder(), decodeUTF8_ = decoder.decode.bind(decoder)))(bytes);
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/base64.js
var require_base64 = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/base64.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.fromBase64 = exports2.toBase64 = void 0;
    var error_1 = require_error();
    var bytes_1 = require_bytes();
    var toBase64 = (data) => {
      if (!data)
        return "";
      if (typeof globalThis.Buffer !== "undefined") {
        return globalThis.Buffer.from(data).toString("base64");
      }
      if (typeof data === "string") {
        data = (0, bytes_1.encodeUTF8)(data);
      }
      if (typeof btoa !== "undefined") {
        return btoa(String.fromCharCode.apply(null, data));
      }
      throw new error_1.AnthropicError("Cannot generate base64 string; Expected `Buffer` or `btoa` to be defined");
    };
    exports2.toBase64 = toBase64;
    var fromBase64 = (str) => {
      if (typeof globalThis.Buffer !== "undefined") {
        const buf = globalThis.Buffer.from(str, "base64");
        return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
      }
      if (typeof atob !== "undefined") {
        const bstr = atob(str);
        const buf = new Uint8Array(bstr.length);
        for (let i = 0; i < bstr.length; i++) {
          buf[i] = bstr.charCodeAt(i);
        }
        return buf;
      }
      throw new error_1.AnthropicError("Cannot decode base64 string; Expected `Buffer` or `atob` to be defined");
    };
    exports2.fromBase64 = fromBase64;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/log.js
var require_log = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/log.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.formatRequestDetails = exports2.parseLogLevel = exports2.defaultLogLevel = void 0;
    exports2.loggerFor = loggerFor;
    exports2.defaultLogger = defaultLogger;
    exports2.debugLogRequestDetails = debugLogRequestDetails;
    var values_1 = require_values();
    var env_1 = require_env();
    exports2.defaultLogLevel = "warn";
    var levelNumbers = {
      off: 0,
      error: 200,
      warn: 300,
      info: 400,
      debug: 500
    };
    var parseLogLevel = (maybeLevel, sourceName, logger) => {
      if (!maybeLevel) {
        return void 0;
      }
      if ((0, values_1.hasOwn)(levelNumbers, maybeLevel)) {
        return maybeLevel;
      }
      logger.warn(`${sourceName} was set to ${JSON.stringify(maybeLevel)}, expected one of ${JSON.stringify(Object.keys(levelNumbers))}`);
      return void 0;
    };
    exports2.parseLogLevel = parseLogLevel;
    function noop() {
    }
    function makeLogFn(fnLevel, logger, logLevel) {
      if (!logger || levelNumbers[fnLevel] > levelNumbers[logLevel]) {
        return noop;
      } else {
        return logger[fnLevel].bind(logger);
      }
    }
    var noopLogger = {
      error: noop,
      warn: noop,
      info: noop,
      debug: noop
    };
    var cachedLoggers = /* @__PURE__ */ new WeakMap();
    function filterLogger(logger, logLevel) {
      const cachedLogger = cachedLoggers.get(logger);
      if (cachedLogger && cachedLogger[0] === logLevel) {
        return cachedLogger[1];
      }
      const levelLogger = {
        error: makeLogFn("error", logger, logLevel),
        warn: makeLogFn("warn", logger, logLevel),
        info: makeLogFn("info", logger, logLevel),
        debug: makeLogFn("debug", logger, logLevel)
      };
      cachedLoggers.set(logger, [logLevel, levelLogger]);
      return levelLogger;
    }
    function loggerFor(client) {
      const logger = client.logger;
      const logLevel = client.logLevel ?? "off";
      if (!logger) {
        return noopLogger;
      }
      return filterLogger(logger, logLevel);
    }
    var lastEnvLevel;
    var cachedDefaultLogger;
    function defaultLogger() {
      const envLevel = (0, env_1.readEnv)("ANTHROPIC_LOG");
      if (!cachedDefaultLogger || envLevel !== lastEnvLevel) {
        lastEnvLevel = envLevel;
        cachedDefaultLogger = filterLogger(console, (0, exports2.parseLogLevel)(envLevel, "process.env['ANTHROPIC_LOG']", filterLogger(console, exports2.defaultLogLevel)) ?? exports2.defaultLogLevel);
      }
      return cachedDefaultLogger;
    }
    function debugLogRequestDetails(logger, message, details) {
      if (logger.debug === noop) {
        return;
      }
      logger.debug(message, (0, exports2.formatRequestDetails)(details));
    }
    var formatRequestDetails = (details) => {
      if (details.options) {
        details.options = { ...details.options };
        delete details.options["headers"];
      }
      if (details.headers) {
        details.headers = Object.fromEntries((details.headers instanceof Headers ? [...details.headers] : Object.entries(details.headers)).map(([name, value]) => [
          name,
          name.toLowerCase() === "authorization" || name.toLowerCase() === "api-key" || name.toLowerCase() === "x-api-key" || name.toLowerCase() === "cookie" || name.toLowerCase() === "set-cookie" ? "***" : value
        ]));
      }
      if ("retryOfRequestLogID" in details) {
        if (details.retryOfRequestLogID) {
          details.retryOf = details.retryOfRequestLogID;
        }
        delete details.retryOfRequestLogID;
      }
      return details;
    };
    exports2.formatRequestDetails = formatRequestDetails;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/uuid.js
var require_uuid = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/uuid.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.uuid4 = void 0;
    var uuid4 = function() {
      const { crypto: crypto2 } = globalThis;
      if (crypto2?.randomUUID) {
        exports2.uuid4 = crypto2.randomUUID.bind(crypto2);
        return crypto2.randomUUID();
      }
      const u8 = new Uint8Array(1);
      const randomByte = crypto2 ? () => crypto2.getRandomValues(u8)[0] : () => Math.random() * 255 & 255;
      return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (c) => (+c ^ randomByte() & 15 >> +c / 4).toString(16));
    };
    exports2.uuid4 = uuid4;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils.js
var require_utils2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_values(), exports2);
    tslib_1.__exportStar(require_base64(), exports2);
    tslib_1.__exportStar(require_env(), exports2);
    tslib_1.__exportStar(require_log(), exports2);
    tslib_1.__exportStar(require_uuid(), exports2);
    tslib_1.__exportStar(require_sleep(), exports2);
    tslib_1.__exportStar(require_query(), exports2);
  }
});

// node_modules/@anthropic-ai/sdk/core/credentials.js
var require_credentials = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/credentials.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getCredentialsPath = exports2.loadCredentials = exports2.loadConfigWithSource = exports2.loadConfig = exports2.CREDENTIALS_FILE_VERSION = exports2.CONFIG_FILE_VERSION = void 0;
    var detect_platform_1 = require_detect_platform();
    var utils_1 = require_utils2();
    exports2.CONFIG_FILE_VERSION = "1.0";
    exports2.CREDENTIALS_FILE_VERSION = "1.0";
    var PROFILE_NAME_PATTERN = /^[A-Za-z0-9_.-]+$/;
    function validateProfileName(name) {
      if (!name) {
        throw new Error("profile name is empty");
      }
      if (name === "." || name === "..") {
        throw new Error(`profile name "${name}" is not allowed`);
      }
      if (name.includes("/") || name.includes("\\")) {
        throw new Error(`profile name "${name}" must not contain path separators`);
      }
      if (!PROFILE_NAME_PATTERN.test(name)) {
        throw new Error(`profile name "${name}" contains disallowed characters (allowed: letters, digits, '_', '.', '-')`);
      }
    }
    var loadConfig = async (profile) => {
      return (await (0, exports2.loadConfigWithSource)(profile))?.config ?? null;
    };
    exports2.loadConfig = loadConfig;
    var loadConfigWithSource = async (profile) => {
      var _a, _b;
      const rootConfigPath = await getRootConfigPath();
      if (rootConfigPath === null) {
        return null;
      }
      const profileName = profile ?? await getActiveProfileName();
      if (profileName === null) {
        return null;
      }
      validateProfileName(profileName);
      const { fs: fs2, path: path2 } = await Promise.resolve().then(() => __importStar(require_node()));
      const configPath = path2.join(rootConfigPath, "configs", `${profileName}.json`);
      let configRaw;
      try {
        configRaw = await fs2.promises.readFile(configPath, "utf-8");
      } catch (err) {
        if (err?.code !== "ENOENT") {
          throw new Error(`failed to read config file ${configPath}: ${err}`);
        }
        configRaw = null;
      }
      if (configRaw === null) {
        const organizationId = (0, utils_1.readEnv)("ANTHROPIC_ORGANIZATION_ID");
        const identityTokenFile = (0, utils_1.readEnv)("ANTHROPIC_IDENTITY_TOKEN_FILE");
        const federationRuleId = (0, utils_1.readEnv)("ANTHROPIC_FEDERATION_RULE_ID");
        if (federationRuleId && organizationId) {
          return {
            fromFile: false,
            config: {
              organization_id: organizationId,
              // A defaulted-but-empty CI variable (`ANTHROPIC_WORKSPACE_ID=""`) is
              // treated as unset — readEnv coerces empty to undefined, and the body
              // builder's truthy check skips it — so `"workspace_id": ""` never goes
              // on the wire.
              workspace_id: (0, utils_1.readEnv)("ANTHROPIC_WORKSPACE_ID"),
              base_url: (0, utils_1.readEnv)("ANTHROPIC_BASE_URL"),
              authentication: {
                type: "oidc_federation",
                federation_rule_id: federationRuleId,
                service_account_id: (0, utils_1.readEnv)("ANTHROPIC_SERVICE_ACCOUNT_ID"),
                identity_token: identityTokenFile ? { source: "file", path: identityTokenFile } : void 0,
                scope: (0, utils_1.readEnv)("ANTHROPIC_SCOPE")
              }
            }
          };
        }
        return null;
      }
      let config;
      try {
        config = JSON.parse(configRaw);
      } catch (err) {
        throw new Error(`failed to parse config file ${configPath}: ${err}`);
      }
      if (!config.authentication) {
        throw new Error(`config file ${configPath} is missing "authentication"`);
      }
      const authType = config.authentication.type;
      if (authType !== "oidc_federation" && authType !== "user_oauth") {
        throw new Error(`authentication.type "${authType}" is not a known authentication type`);
      }
      config.organization_id ?? (config.organization_id = (0, utils_1.readEnv)("ANTHROPIC_ORGANIZATION_ID"));
      config.workspace_id ?? (config.workspace_id = (0, utils_1.readEnv)("ANTHROPIC_WORKSPACE_ID"));
      config.base_url ?? (config.base_url = (0, utils_1.readEnv)("ANTHROPIC_BASE_URL"));
      (_a = config.authentication).scope ?? (_a.scope = (0, utils_1.readEnv)("ANTHROPIC_SCOPE"));
      if (config.authentication.type === "oidc_federation") {
        if (!config.authentication.identity_token) {
          const identityTokenFile = (0, utils_1.readEnv)("ANTHROPIC_IDENTITY_TOKEN_FILE");
          if (identityTokenFile) {
            config.authentication.identity_token = {
              source: "file",
              path: identityTokenFile
            };
          }
        }
        if (!config.authentication.federation_rule_id) {
          config.authentication.federation_rule_id = (0, utils_1.readEnv)("ANTHROPIC_FEDERATION_RULE_ID") ?? "";
        }
        (_b = config.authentication).service_account_id ?? (_b.service_account_id = (0, utils_1.readEnv)("ANTHROPIC_SERVICE_ACCOUNT_ID"));
      }
      return { config, fromFile: true };
    };
    exports2.loadConfigWithSource = loadConfigWithSource;
    var loadCredentials = async () => {
      const config = await (0, exports2.loadConfig)();
      const credentialsPath = await (0, exports2.getCredentialsPath)(config);
      if (!credentialsPath) {
        return null;
      }
      const { fs: fs2 } = await Promise.resolve().then(() => __importStar(require_node()));
      let raw;
      try {
        raw = await fs2.promises.readFile(credentialsPath, "utf-8");
      } catch (err) {
        if (err?.code !== "ENOENT") {
          throw new Error(`failed to read credentials file ${credentialsPath}: ${err}`);
        }
        return null;
      }
      let creds;
      try {
        creds = JSON.parse(raw);
      } catch (err) {
        throw new Error(`failed to parse credentials file ${credentialsPath}: ${err}`);
      }
      if (creds.type && creds.type !== "oauth_token") {
        throw new Error(`credentials file ${credentialsPath} has unsupported type "${creds.type}" (want "oauth_token")`);
      }
      return creds;
    };
    exports2.loadCredentials = loadCredentials;
    var getCredentialsPath = async (config, profile) => {
      if (config?.authentication.credentials_path) {
        return config.authentication.credentials_path;
      }
      const rootConfigPath = await getRootConfigPath();
      if (!rootConfigPath) {
        return null;
      }
      const profileName = profile ?? await getActiveProfileName();
      if (!profileName) {
        return null;
      }
      validateProfileName(profileName);
      const { path: path2 } = await Promise.resolve().then(() => __importStar(require_node()));
      return path2.join(rootConfigPath, "credentials", `${profileName}.json`);
    };
    exports2.getCredentialsPath = getCredentialsPath;
    var getRootConfigPath = async () => {
      if (!supportsLocalConfigFiles()) {
        return null;
      }
      const { path: path2 } = await Promise.resolve().then(() => __importStar(require_node()));
      const configDir = (0, utils_1.readEnv)("ANTHROPIC_CONFIG_DIR");
      if (configDir) {
        return configDir;
      }
      const os = (0, detect_platform_1.getPlatformHeaders)()["X-Stainless-OS"];
      if (os === "Windows") {
        const appData = (0, utils_1.readEnv)("APPDATA");
        if (appData) {
          return path2.join(appData, "Anthropic");
        }
        const userProfile = (0, utils_1.readEnv)("USERPROFILE");
        if (userProfile) {
          return path2.join(userProfile, "AppData", "Roaming", "Anthropic");
        }
        return null;
      }
      const xdgConfigHome = (0, utils_1.readEnv)("XDG_CONFIG_HOME");
      if (xdgConfigHome) {
        return path2.join(xdgConfigHome, "anthropic");
      }
      const home = (0, utils_1.readEnv)("HOME");
      if (home) {
        return path2.join(home, ".config", "anthropic");
      }
      return null;
    };
    var supportsLocalConfigFiles = () => {
      const runtime = (0, detect_platform_1.getPlatformHeaders)()["X-Stainless-Runtime"];
      return runtime === "node" || runtime === "deno";
    };
    var getActiveProfileName = async () => {
      const rootConfigPath = await getRootConfigPath();
      if (!rootConfigPath) {
        return null;
      }
      const profileName = (0, utils_1.readEnv)("ANTHROPIC_PROFILE");
      if (profileName) {
        return profileName;
      }
      const { fs: fs2, path: path2 } = await Promise.resolve().then(() => __importStar(require_node()));
      const filePath = path2.join(rootConfigPath, "active_config");
      try {
        return (await fs2.promises.readFile(filePath, "utf-8")).trim() || "default";
      } catch (err) {
        if (err?.code !== "ENOENT") {
          throw new Error(`failed to read ${filePath}: ${err}`);
        }
        return "default";
      }
    };
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/identity-token.js
var require_identity_token = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/identity-token.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.identityTokenFromFile = identityTokenFromFile;
    exports2.identityTokenFromValue = identityTokenFromValue;
    var error_1 = require_error();
    function identityTokenFromFile(path2) {
      if (!path2) {
        throw new error_1.AnthropicError("Identity token file path is empty");
      }
      return async () => {
        const { fs: fs2 } = await Promise.resolve().then(() => __importStar(require_node()));
        let content;
        try {
          content = await fs2.promises.readFile(path2, "utf-8");
        } catch (err) {
          throw new error_1.AnthropicError(`Failed to read identity token file at ${path2}: ${err}`);
        }
        const token = content.trim();
        if (!token) {
          throw new error_1.AnthropicError(`Identity token file at ${path2} is empty`);
        }
        return token;
      };
    }
    function identityTokenFromValue(token) {
      if (!token) {
        throw new error_1.AnthropicError("Identity token value is empty");
      }
      return () => token;
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/oidc-federation.js
var require_oidc_federation = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/oidc-federation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.oidcFederationProvider = oidcFederationProvider;
    var types_1 = require_types();
    var time_1 = require_time();
    var version_1 = require_version();
    function oidcFederationProvider(config) {
      return async () => {
        (0, types_1.requireSecureTokenEndpoint)(config.baseURL);
        const jwt = await config.identityTokenProvider();
        if (jwt.length > 16 * 1024) {
          throw new types_1.WorkloadIdentityError(`Identity token is ${Math.ceil(jwt.length / 1024)} KiB, exceeds the 16 KiB assertion limit`);
        }
        const body = {
          grant_type: types_1.GRANT_TYPE_JWT_BEARER,
          assertion: jwt,
          federation_rule_id: config.federationRuleId,
          organization_id: config.organizationId
        };
        if (config.serviceAccountId) {
          body["service_account_id"] = config.serviceAccountId;
        }
        if (config.workspaceId) {
          body["workspace_id"] = config.workspaceId;
        }
        const url = `${config.baseURL}${types_1.TOKEN_ENDPOINT}`;
        let resp;
        try {
          resp = await config.fetch(url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "anthropic-beta": `${types_1.OAUTH_API_BETA_HEADER},${types_1.FEDERATION_BETA_HEADER}`,
              "User-Agent": config.userAgent || `anthropic-sdk-typescript/${version_1.VERSION} oidcFederationProvider`
            },
            body: JSON.stringify(body)
          });
        } catch (err) {
          throw new types_1.WorkloadIdentityError(`Failed to reach token endpoint ${url}: ${err}`);
        }
        const requestId = resp.headers.get("Request-Id");
        if (!resp.ok) {
          const text = await resp.text().catch(() => "");
          const redacted = (0, types_1.redactSensitive)(text);
          let hint = "";
          if (resp.status === 401) {
            const hintMiddle = config.workspaceId ? "" : "If your federation rule is scoped to multiple workspaces, set the ANTHROPIC_WORKSPACE_ID environment variable, the 'workspace_id' config key, or the `workspaceId` option. ";
            hint = ` Ensure your federation rule matches your identity token. ${hintMiddle}View your authentication events in the Workload identity page of Claude Console for more details.`;
          }
          throw new types_1.WorkloadIdentityError(`Token exchange failed with status ${resp.status}${requestId ? ` (request-id ${requestId})` : ""}: ${redacted}${hint}`, resp.status, redacted, requestId);
        }
        const data = await (0, types_1.parseTokenResponse)(resp, requestId);
        const expiresIn = Number(data.expires_in);
        if (!Number.isFinite(expiresIn)) {
          throw new types_1.WorkloadIdentityError(`Token endpoint response missing required fields: ${JSON.stringify((0, types_1.redactSensitive)(data))}`, resp.status, (0, types_1.redactSensitive)(data), requestId);
        }
        return {
          token: data.access_token,
          expiresAt: (0, time_1.nowAsSeconds)() + expiresIn
        };
      };
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/user-oauth.js
var require_user_oauth = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/user-oauth.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.userOAuthProvider = userOAuthProvider;
    var credentials_1 = require_credentials();
    var types_1 = require_types();
    var time_1 = require_time();
    var version_1 = require_version();
    function userOAuthProvider(config) {
      return async (opts) => {
        const { fs: fs2 } = await Promise.resolve().then(() => __importStar(require_node()));
        await (0, types_1.checkCredentialsFileSafety)(config.credentialsPath, config.onSafetyWarning);
        let raw;
        try {
          raw = await fs2.promises.readFile(config.credentialsPath, "utf-8");
        } catch (err) {
          throw new types_1.WorkloadIdentityError(`Credentials file not found at ${config.credentialsPath}: ${err}`);
        }
        let creds;
        try {
          creds = JSON.parse(raw);
        } catch (err) {
          throw new types_1.WorkloadIdentityError(`Credentials file at ${config.credentialsPath} is not valid JSON: ${err}`);
        }
        const accessToken = creds.access_token;
        if (!accessToken) {
          throw new types_1.WorkloadIdentityError(`Credentials file at ${config.credentialsPath} must include 'access_token'`);
        }
        const expiresAt = creds.expires_at;
        if (!opts?.forceRefresh && (expiresAt == null || (0, time_1.nowAsSeconds)() < expiresAt - types_1.MANDATORY_REFRESH_THRESHOLD_IN_SECONDS)) {
          return { token: accessToken, expiresAt: expiresAt ?? null };
        }
        const refreshToken = creds.refresh_token;
        if (!config.clientId || !refreshToken) {
          throw new types_1.WorkloadIdentityError(`Access token at ${config.credentialsPath} has expired and no refresh is available (client_id ${config.clientId ? "set" : "empty"}, refresh_token ${refreshToken ? "set" : "empty"})`);
        }
        (0, types_1.requireSecureTokenEndpoint)(config.baseURL);
        const body = {
          grant_type: types_1.GRANT_TYPE_REFRESH_TOKEN,
          refresh_token: refreshToken,
          client_id: config.clientId
        };
        const url = `${config.baseURL}${types_1.TOKEN_ENDPOINT}`;
        let resp;
        try {
          resp = await config.fetch(url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "anthropic-beta": types_1.OAUTH_API_BETA_HEADER,
              "User-Agent": config.userAgent || `anthropic-sdk-typescript/${version_1.VERSION} userOAuthProvider`
            },
            body: JSON.stringify(body)
          });
        } catch (err) {
          throw new types_1.WorkloadIdentityError(`User OAuth refresh failed to reach token endpoint: ${err}`);
        }
        const requestId = resp.headers.get("Request-Id");
        if (!resp.ok) {
          const text = await resp.text().catch(() => "");
          throw new types_1.WorkloadIdentityError(`User OAuth refresh failed (HTTP ${resp.status}): ${(0, types_1.redactSensitive)(text)}`, resp.status, (0, types_1.redactSensitive)(text), requestId);
        }
        const data = await (0, types_1.parseTokenResponse)(resp, requestId);
        const expiresIn = Number(data.expires_in);
        if (!Number.isFinite(expiresIn)) {
          throw new types_1.WorkloadIdentityError(`User OAuth refresh response missing or invalid expires_in: ${JSON.stringify((0, types_1.redactSensitive)(data))}`, resp.status, (0, types_1.redactSensitive)(data), requestId);
        }
        const newExpiresAt = (0, time_1.nowAsSeconds)() + expiresIn;
        const newRefreshToken = data.refresh_token || refreshToken;
        await (0, types_1.writeCredentialsFileAtomic)(config.credentialsPath, {
          ...creds,
          version: credentials_1.CREDENTIALS_FILE_VERSION,
          type: "oauth_token",
          access_token: data.access_token,
          expires_at: newExpiresAt,
          refresh_token: newRefreshToken
        });
        return { token: data.access_token, expiresAt: newExpiresAt };
      };
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/credential-chain.js
var require_credential_chain = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/credential-chain.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.resolveCredentialsFromConfig = resolveCredentialsFromConfig;
    exports2.defaultCredentials = defaultCredentials;
    var env_1 = require_env();
    var credentials_1 = require_credentials();
    var types_1 = require_types();
    var time_1 = require_time();
    var identity_token_1 = require_identity_token();
    var oidc_federation_1 = require_oidc_federation();
    var user_oauth_1 = require_user_oauth();
    function resolveCredentialsFromConfig(config, options) {
      const credentialsPath = config.authentication.credentials_path ?? null;
      const effectiveBaseURL = (config.base_url || options.baseURL).replace(/\/+$/, "");
      const provider = buildProvider(config, credentialsPath, effectiveBaseURL, options);
      const extraHeaders = {};
      if (config.workspace_id && config.authentication.type === "user_oauth") {
        extraHeaders["anthropic-workspace-id"] = config.workspace_id;
      }
      return { provider, extraHeaders, baseURL: config.base_url || void 0 };
    }
    async function defaultCredentials(options, profile) {
      const loaded = await (0, credentials_1.loadConfigWithSource)(profile);
      if (!loaded) {
        return null;
      }
      const { config, fromFile } = loaded;
      const withPath = config.authentication.credentials_path || !fromFile ? config : {
        ...config,
        authentication: {
          ...config.authentication,
          credentials_path: await (0, credentials_1.getCredentialsPath)(config, profile) ?? void 0
        }
      };
      return resolveCredentialsFromConfig(withPath, options);
    }
    function buildProvider(config, credentialsPath, baseURL, options) {
      switch (config.authentication.type) {
        case "oidc_federation": {
          const auth = config.authentication;
          const identityProvider = resolveIdentityTokenProvider(auth);
          if (!identityProvider) {
            throw new types_1.WorkloadIdentityError("oidc_federation config requires an identity token (set authentication.identity_token, ANTHROPIC_IDENTITY_TOKEN_FILE, or ANTHROPIC_IDENTITY_TOKEN)");
          }
          if (!auth.federation_rule_id) {
            throw new types_1.WorkloadIdentityError("oidc_federation config requires 'federation_rule_id'. Set it in authentication.federation_rule_id in your profile, or via ANTHROPIC_FEDERATION_RULE_ID (profile takes precedence).");
          }
          if (!config.organization_id) {
            throw new types_1.WorkloadIdentityError("oidc_federation config requires organization_id (set ANTHROPIC_ORGANIZATION_ID or config.organization_id)");
          }
          const exchange = (0, oidc_federation_1.oidcFederationProvider)({
            identityTokenProvider: identityProvider,
            federationRuleId: auth.federation_rule_id,
            organizationId: config.organization_id,
            serviceAccountId: auth.service_account_id,
            workspaceId: config.workspace_id,
            baseURL,
            fetch: options.fetch,
            userAgent: options.userAgent
          });
          if (credentialsPath) {
            return cachedExchangeProvider(exchange, credentialsPath, options.onCacheWriteError, options.onSafetyWarning);
          }
          return exchange;
        }
        case "user_oauth": {
          if (!credentialsPath) {
            throw new types_1.WorkloadIdentityError("user_oauth config requires authentication.credentials_path (or load via a profile so it defaults to <config_dir>/credentials/<profile>.json)");
          }
          return (0, user_oauth_1.userOAuthProvider)({
            credentialsPath,
            clientId: config.authentication.client_id,
            baseURL,
            fetch: options.fetch,
            userAgent: options.userAgent,
            onSafetyWarning: options.onSafetyWarning
          });
        }
        default: {
          const t = config.authentication.type;
          throw new types_1.WorkloadIdentityError(`authentication.type "${t}" is not a known authentication type`);
        }
      }
    }
    function resolveIdentityTokenProvider(auth) {
      if (auth.identity_token) {
        const source = auth.identity_token.source;
        if (source !== "file") {
          throw new types_1.WorkloadIdentityError(`identity_token.source "${source}" is not supported by this SDK version (only "file")`);
        }
        if (!auth.identity_token.path) {
          throw new types_1.WorkloadIdentityError(`identity_token.source "file" requires a non-empty path`);
        }
        return (0, identity_token_1.identityTokenFromFile)(auth.identity_token.path);
      }
      const tokenFile = (0, env_1.readEnv)("ANTHROPIC_IDENTITY_TOKEN_FILE");
      if (tokenFile) {
        return (0, identity_token_1.identityTokenFromFile)(tokenFile);
      }
      const tokenValue = (0, env_1.readEnv)("ANTHROPIC_IDENTITY_TOKEN");
      if (tokenValue) {
        return (0, identity_token_1.identityTokenFromValue)(tokenValue);
      }
      return null;
    }
    function cachedExchangeProvider(exchange, credentialsPath, onCacheWriteError, onSafetyWarning) {
      return async (opts) => {
        const { fs: fs2 } = await Promise.resolve().then(() => __importStar(require_node()));
        await (0, types_1.checkCredentialsFileSafety)(credentialsPath, onSafetyWarning);
        let existing;
        try {
          const raw = await fs2.promises.readFile(credentialsPath, "utf-8");
          existing = JSON.parse(raw);
          const token = existing?.["access_token"];
          if (token && !opts?.forceRefresh) {
            const expiresAt = existing?.["expires_at"];
            if (expiresAt == null || (0, time_1.nowAsSeconds)() < expiresAt - types_1.MANDATORY_REFRESH_THRESHOLD_IN_SECONDS) {
              return { token, expiresAt: expiresAt ?? null };
            }
          }
        } catch (err) {
          const code = err?.code;
          if (code !== "ENOENT" && !(err instanceof SyntaxError)) {
            onCacheWriteError?.(err);
          }
        }
        const result = await exchange(opts);
        try {
          await (0, types_1.writeCredentialsFileAtomic)(credentialsPath, {
            ...existing ?? {},
            version: credentials_1.CREDENTIALS_FILE_VERSION,
            type: "oauth_token",
            access_token: result.token,
            expires_at: result.expiresAt
          });
        } catch (err) {
          onCacheWriteError?.(err);
        }
        return result;
      };
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/decoders/line.js
var require_line = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/decoders/line.js"(exports2) {
    "use strict";
    var _LineDecoder_buffer;
    var _LineDecoder_carriageReturnIndex;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.LineDecoder = void 0;
    exports2.findDoubleNewlineIndex = findDoubleNewlineIndex;
    var tslib_1 = require_tslib();
    var bytes_1 = require_bytes();
    var LineDecoder = /* @__PURE__ */ (() => {
      class LineDecoder2 {
        constructor() {
          _LineDecoder_buffer.set(this, void 0);
          _LineDecoder_carriageReturnIndex.set(this, void 0);
          tslib_1.__classPrivateFieldSet(this, _LineDecoder_buffer, new Uint8Array(), "f");
          tslib_1.__classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
        }
        decode(chunk) {
          if (chunk == null) {
            return [];
          }
          const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk) : typeof chunk === "string" ? (0, bytes_1.encodeUTF8)(chunk) : chunk;
          tslib_1.__classPrivateFieldSet(this, _LineDecoder_buffer, (0, bytes_1.concatBytes)([tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f"), binaryChunk]), "f");
          const lines = [];
          let patternIndex;
          while ((patternIndex = findNewlineIndex(tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f"), tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f"))) != null) {
            if (patternIndex.carriage && tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") == null) {
              tslib_1.__classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, patternIndex.index, "f");
              continue;
            }
            if (tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") != null && (patternIndex.index !== tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") + 1 || patternIndex.carriage)) {
              lines.push((0, bytes_1.decodeUTF8)(tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(0, tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") - 1)));
              tslib_1.__classPrivateFieldSet(this, _LineDecoder_buffer, tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f")), "f");
              tslib_1.__classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
              continue;
            }
            const endIndex = tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") !== null ? patternIndex.preceding - 1 : patternIndex.preceding;
            const line = (0, bytes_1.decodeUTF8)(tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(0, endIndex));
            lines.push(line);
            tslib_1.__classPrivateFieldSet(this, _LineDecoder_buffer, tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(patternIndex.index), "f");
            tslib_1.__classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
          }
          return lines;
        }
        flush() {
          if (!tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f").length) {
            return [];
          }
          return this.decode("\n");
        }
      }
      _LineDecoder_buffer = /* @__PURE__ */ new WeakMap(), _LineDecoder_carriageReturnIndex = /* @__PURE__ */ new WeakMap();
      LineDecoder2.NEWLINE_CHARS = /* @__PURE__ */ new Set(["\n", "\r"]);
      LineDecoder2.NEWLINE_REGEXP = /\r\n|[\n\r]/g;
      return LineDecoder2;
    })();
    exports2.LineDecoder = LineDecoder;
    function findNewlineIndex(buffer, startIndex) {
      const newline = 10;
      const carriage = 13;
      for (let i = startIndex ?? 0; i < buffer.length; i++) {
        if (buffer[i] === newline) {
          return { preceding: i, index: i + 1, carriage: false };
        }
        if (buffer[i] === carriage) {
          return { preceding: i, index: i + 1, carriage: true };
        }
      }
      return null;
    }
    function findDoubleNewlineIndex(buffer) {
      const newline = 10;
      const carriage = 13;
      for (let i = 0; i < buffer.length - 1; i++) {
        if (buffer[i] === newline && buffer[i + 1] === newline) {
          return i + 2;
        }
        if (buffer[i] === carriage && buffer[i + 1] === carriage) {
          return i + 2;
        }
        if (buffer[i] === carriage && buffer[i + 1] === newline && i + 3 < buffer.length && buffer[i + 2] === carriage && buffer[i + 3] === newline) {
          return i + 4;
        }
      }
      return -1;
    }
  }
});

// node_modules/@anthropic-ai/sdk/core/streaming.js
var require_streaming = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/streaming.js"(exports2) {
    "use strict";
    var _Stream_client;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Stream = void 0;
    exports2._iterSSEMessages = _iterSSEMessages;
    var tslib_1 = require_tslib();
    var error_1 = require_error();
    var shims_1 = require_shims();
    var line_1 = require_line();
    var shims_2 = require_shims();
    var errors_1 = require_errors();
    var values_1 = require_values();
    var bytes_1 = require_bytes();
    var log_1 = require_log();
    var error_2 = require_error();
    var request_signal_1 = require_request_signal();
    var Stream = /* @__PURE__ */ (() => {
      class Stream2 {
        constructor(iterator, controller, client) {
          this.iterator = iterator;
          _Stream_client.set(this, void 0);
          this.controller = controller;
          tslib_1.__classPrivateFieldSet(this, _Stream_client, client, "f");
        }
        /**
         * Iterate the raw Server-Sent Events from `response` — `{event, data, raw}`
         * objects, before any JSON parsing or event-name filtering.
         *
         * This reads `response.body` directly (not a clone), so the response is
         * consumed. Use this in middleware that fully replaces the stream body; for
         * read-only observation of parsed events, use `ctx.parse()` instead.
         */
        static rawEvents(response, controller = new AbortController()) {
          return _iterSSEMessages(response, controller);
        }
        static fromSSEResponse(response, controller, client) {
          let consumed = false;
          const logger = client ? (0, log_1.loggerFor)(client) : console;
          async function* iterator() {
            if (consumed) {
              throw new error_1.AnthropicError("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
            }
            consumed = true;
            let done = false;
            try {
              for await (const sse of _iterSSEMessages(response, controller)) {
                if (sse.event === "completion") {
                  try {
                    yield JSON.parse(sse.data);
                  } catch (e) {
                    logger.error(`Could not parse message into JSON:`, sse.data);
                    logger.error(`From chunk:`, sse.raw);
                    throw e;
                  }
                }
                if (sse.event === "message_start" || sse.event === "message_delta" || sse.event === "message_stop" || sse.event === "content_block_start" || sse.event === "content_block_delta" || sse.event === "content_block_stop" || sse.event === "message" || sse.event === "user.message" || sse.event === "user.interrupt" || sse.event === "user.tool_confirmation" || sse.event === "user.custom_tool_result" || sse.event === "user.tool_result" || sse.event === "agent.message" || sse.event === "agent.thinking" || sse.event === "agent.tool_use" || sse.event === "agent.tool_result" || sse.event === "agent.mcp_tool_use" || sse.event === "agent.mcp_tool_result" || sse.event === "agent.custom_tool_use" || sse.event === "agent.thread_context_compacted" || sse.event === "session.status_running" || sse.event === "session.status_idle" || sse.event === "session.status_rescheduled" || sse.event === "session.status_terminated" || sse.event === "session.error" || sse.event === "session.deleted" || sse.event === "session.updated" || sse.event === "span.model_request_start" || sse.event === "span.model_request_end" || sse.event === "span.outcome_evaluation_start" || sse.event === "span.outcome_evaluation_ongoing" || sse.event === "span.outcome_evaluation_end" || sse.event === "user.define_outcome" || sse.event === "agent.thread_message_received" || sse.event === "agent.thread_message_sent" || sse.event === "agent.session_thread_message_received" || sse.event === "agent.session_thread_message_sent" || sse.event === "session.thread_created" || sse.event === "session.thread_status_created" || sse.event === "session.thread_status_running" || sse.event === "session.thread_status_idle" || sse.event === "session.thread_status_rescheduled" || sse.event === "session.thread_status_terminated" || sse.event === "event_start" || sse.event === "event_delta" || sse.event === "system.message") {
                  try {
                    yield JSON.parse(sse.data);
                  } catch (e) {
                    logger.error(`Could not parse message into JSON:`, sse.data);
                    logger.error(`From chunk:`, sse.raw);
                    throw e;
                  }
                }
                if (sse.event === "ping") {
                  continue;
                }
                if (sse.event === "error") {
                  const body = (0, values_1.safeJSON)(sse.data) ?? sse.data;
                  const type = body?.error?.type;
                  throw new error_2.APIError(void 0, body, void 0, response.headers, type);
                }
              }
              done = true;
            } catch (e) {
              if ((0, errors_1.isAbortError)(e))
                return;
              throw e;
            } finally {
              if (!done)
                controller.abort();
              (0, request_signal_1.releaseRequestSignal)(controller);
            }
          }
          return new Stream2(iterator, controller, client);
        }
        /**
         * Generates a Stream from a newline-separated ReadableStream
         * where each item is a JSON value.
         */
        static fromReadableStream(readableStream, controller, client) {
          let consumed = false;
          async function* iterLines() {
            const lineDecoder = new line_1.LineDecoder();
            const iter = (0, shims_2.ReadableStreamToAsyncIterable)(readableStream);
            for await (const chunk of iter) {
              for (const line of lineDecoder.decode(chunk)) {
                yield line;
              }
            }
            for (const line of lineDecoder.flush()) {
              yield line;
            }
          }
          async function* iterator() {
            if (consumed) {
              throw new error_1.AnthropicError("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
            }
            consumed = true;
            let done = false;
            try {
              for await (const line of iterLines()) {
                if (done)
                  continue;
                if (line)
                  yield JSON.parse(line);
              }
              done = true;
            } catch (e) {
              if ((0, errors_1.isAbortError)(e))
                return;
              throw e;
            } finally {
              if (!done)
                controller.abort();
              (0, request_signal_1.releaseRequestSignal)(controller);
            }
          }
          return new Stream2(iterator, controller, client);
        }
        [(_Stream_client = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
          return this.iterator();
        }
        /**
         * Splits the stream into two streams which can be
         * independently read from at different speeds.
         */
        tee() {
          const left = [];
          const right = [];
          const iterator = this.iterator();
          const teeIterator = (queue) => {
            return {
              next: () => {
                if (queue.length === 0) {
                  const result = iterator.next();
                  left.push(result);
                  right.push(result);
                }
                return queue.shift();
              }
            };
          };
          return [
            new Stream2(() => teeIterator(left), this.controller, tslib_1.__classPrivateFieldGet(this, _Stream_client, "f")),
            new Stream2(() => teeIterator(right), this.controller, tslib_1.__classPrivateFieldGet(this, _Stream_client, "f"))
          ];
        }
        /**
         * Converts this stream to a newline-separated ReadableStream of
         * JSON stringified values in the stream
         * which can be turned back into a Stream with `Stream.fromReadableStream()`.
         */
        toReadableStream() {
          const self = this;
          let iter;
          return (0, shims_1.makeReadableStream)({
            async start() {
              iter = self[Symbol.asyncIterator]();
            },
            async pull(ctrl) {
              try {
                const { value, done } = await iter.next();
                if (done)
                  return ctrl.close();
                const bytes = (0, bytes_1.encodeUTF8)(JSON.stringify(value) + "\n");
                ctrl.enqueue(bytes);
              } catch (err) {
                ctrl.error(err);
              }
            },
            async cancel() {
              await iter.return?.();
            }
          });
        }
      }
      return Stream2;
    })();
    exports2.Stream = Stream;
    async function* _iterSSEMessages(response, controller) {
      if (!response.body) {
        controller.abort();
        if (typeof globalThis.navigator !== "undefined" && globalThis.navigator.product === "ReactNative") {
          throw new error_1.AnthropicError(`The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api`);
        }
        throw new error_1.AnthropicError(`Attempted to iterate over a response with no body`);
      }
      const sseDecoder = new SSEDecoder();
      const lineDecoder = new line_1.LineDecoder();
      const iter = (0, shims_2.ReadableStreamToAsyncIterable)(response.body);
      for await (const sseChunk of iterSSEChunks(iter)) {
        for (const line of lineDecoder.decode(sseChunk)) {
          const sse = sseDecoder.decode(line);
          if (sse)
            yield sse;
        }
      }
      for (const line of lineDecoder.flush()) {
        const sse = sseDecoder.decode(line);
        if (sse)
          yield sse;
      }
    }
    async function* iterSSEChunks(iterator) {
      let data = new Uint8Array();
      for await (const chunk of iterator) {
        if (chunk == null) {
          continue;
        }
        const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk) : typeof chunk === "string" ? (0, bytes_1.encodeUTF8)(chunk) : chunk;
        let newData = new Uint8Array(data.length + binaryChunk.length);
        newData.set(data);
        newData.set(binaryChunk, data.length);
        data = newData;
        let patternIndex;
        while ((patternIndex = (0, line_1.findDoubleNewlineIndex)(data)) !== -1) {
          yield data.subarray(0, patternIndex);
          data = data.subarray(patternIndex);
        }
      }
      if (data.length > 0) {
        yield data;
      }
    }
    var SSEDecoder = class {
      constructor() {
        this.event = null;
        this.data = [];
        this.chunks = [];
      }
      decode(line) {
        if (line.endsWith("\r")) {
          line = line.substring(0, line.length - 1);
        }
        if (!line) {
          if (!this.event && !this.data.length)
            return null;
          const sse = {
            event: this.event,
            data: this.data.join("\n"),
            raw: this.chunks
          };
          this.event = null;
          this.data = [];
          this.chunks = [];
          return sse;
        }
        this.chunks.push(line);
        if (line.startsWith(":")) {
          return null;
        }
        let [fieldname, _, value] = partition(line, ":");
        if (value.startsWith(" ")) {
          value = value.substring(1);
        }
        if (fieldname === "event") {
          this.event = value;
        } else if (fieldname === "data") {
          this.data.push(value);
        }
        return null;
      }
    };
    function partition(str, delimiter) {
      const index = str.indexOf(delimiter);
      if (index !== -1) {
        return [str.substring(0, index), delimiter, str.substring(index + delimiter.length)];
      }
      return [str, "", ""];
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/parse.js
var require_parse = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/parse.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.defaultParseResponse = defaultParseResponse;
    exports2.addResponseIDs = addResponseIDs;
    var streaming_1 = require_streaming();
    var log_1 = require_log();
    var request_signal_1 = require_request_signal();
    async function defaultParseResponse(client, props) {
      const { response, requestLogID, retryOfRequestLogID, startTime } = props;
      const body = await (async () => {
        if (props.options.stream) {
          (0, log_1.loggerFor)(client).debug("response", response.status, response.url, response.headers, response.body);
          return streaming_1.Stream.fromSSEResponse(response, props.controller, client);
        }
        if (response.status === 204) {
          return null;
        }
        if (props.options.__binaryResponse) {
          return response;
        }
        const contentType = response.headers.get("content-type");
        const mediaType = contentType?.split(";")[0]?.trim();
        const isJSON = mediaType?.includes("application/json") || mediaType?.endsWith("+json");
        if (isJSON) {
          const contentLength = response.headers.get("content-length");
          if (contentLength === "0") {
            return void 0;
          }
          const json = await response.json();
          return addResponseIDs(json, response);
        }
        const text = await response.text();
        return text;
      })().finally(() => {
        if (!props.options.stream && !props.options.__binaryResponse) {
          (0, request_signal_1.releaseRequestSignal)(props.controller);
        }
      });
      (0, log_1.debugLogRequestDetails)((0, log_1.loggerFor)(client), `[${requestLogID}] response parsed`, {
        retryOfRequestLogID,
        url: response.url,
        status: response.status,
        body,
        durationMs: Date.now() - startTime
      });
      return body;
    }
    function addResponseIDs(value, response) {
      if (!value || typeof value !== "object" || Array.isArray(value)) {
        return value;
      }
      return Object.defineProperties(value, {
        _request_id: { value: response.headers.get("request-id"), enumerable: false },
        _workspace_id: { value: response.headers.get("anthropic-workspace-id"), enumerable: false }
      });
    }
  }
});

// node_modules/@anthropic-ai/sdk/core/middleware.js
var require_middleware = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/middleware.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isFetchOriginError = isFetchOriginError;
    exports2.isRetryableError = isRetryableError;
    exports2.wrapFetchWithMiddleware = wrapFetchWithMiddleware;
    exports2.applyMiddleware = applyMiddleware;
    var errors_1 = require_errors();
    var parse_1 = require_parse();
    var log_1 = require_log();
    var error_1 = require_error();
    var streaming_1 = require_streaming();
    var fetchOriginErrors = /* @__PURE__ */ new WeakSet();
    function isFetchOriginError(err) {
      return typeof err === "object" && err !== null && fetchOriginErrors.has(err);
    }
    function isRetryableError(err) {
      const seen = /* @__PURE__ */ new Set();
      while (typeof err === "object" && err !== null && !seen.has(err)) {
        seen.add(err);
        if (isFetchOriginError(err) || (0, errors_1.isAbortError)(err) || err instanceof error_1.APIConnectionError || err instanceof error_1.RetryableError) {
          return true;
        }
        err = err.cause;
      }
      return false;
    }
    function wrapFetchWithMiddleware(fetchFn, middleware, options, client) {
      return async (url, init = {}) => {
        if (middleware.length === 0) {
          return fetchFn.call(void 0, url, init);
        }
        const headers = init.headers instanceof Headers ? init.headers : new Headers(init.headers);
        const response = await applyMiddleware(fetchFn, middleware, options, client)({
          ...init,
          headers,
          url: typeof url === "string" ? url : url instanceof URL ? url.href : url.url
        });
        if (response.bodyUsed || response.body?.locked) {
          throw new error_1.AnthropicError("middleware consumed the response body; use response.clone() to inspect it, or return new Response(body, response) to consume and replace it");
        }
        return response;
      };
    }
    function createMiddlewareContext(options, client) {
      const cache = /* @__PURE__ */ new WeakMap();
      return {
        options,
        // Resolved per chain, so changes to the client's `logLevel`/`logger`
        // apply to subsequent requests.
        logger: client ? (0, log_1.loggerFor)(client) : (0, log_1.defaultLogger)(),
        parse(response) {
          if (options?.stream && response.ok) {
            return parseMiddlewareResponse(response, options, client);
          }
          let parsed = cache.get(response);
          if (!parsed) {
            parsed = parseMiddlewareResponse(response, options, client);
            cache.set(response, parsed);
          }
          return parsed;
        }
      };
    }
    async function parseMiddlewareResponse(response, options, client) {
      if (response.bodyUsed || response.body?.locked) {
        throw new error_1.AnthropicError("cannot ctx.parse() a response whose body was already consumed; call ctx.parse() instead of reading the body, or read via response.clone()");
      }
      if (options?.stream && response.ok) {
        return streaming_1.Stream.fromSSEResponse(response.clone(), new AbortController(), client);
      }
      if (response.status === 204) {
        return null;
      }
      if (options?.__binaryResponse) {
        return response;
      }
      const contentType = response.headers.get("content-type");
      const mediaType = contentType?.split(";")[0]?.trim();
      const isJSON = mediaType?.includes("application/json") || mediaType?.endsWith("+json");
      if (isJSON) {
        if (response.headers.get("content-length") === "0") {
          return void 0;
        }
        return (0, parse_1.addResponseIDs)(await response.clone().json(), response);
      }
      return await response.clone().text();
    }
    function applyMiddleware(fetchFn, middleware, options, client) {
      let next = async ({ url, ...init }) => {
        try {
          return await fetchFn.call(void 0, url, init);
        } catch (err) {
          const error = (0, errors_1.castToError)(err);
          fetchOriginErrors.add(error);
          throw error;
        }
      };
      const ctx = createMiddlewareContext(options, client);
      for (let i = middleware.length - 1; i >= 0; i--) {
        const mw = middleware[i];
        const nextInner = next;
        next = async (request) => mw(request, nextInner, ctx);
      }
      return next;
    }
  }
});

// node_modules/@anthropic-ai/sdk/core/api-promise.js
var require_api_promise = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/api-promise.js"(exports2) {
    "use strict";
    var _APIPromise_client;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.APIPromise = void 0;
    var tslib_1 = require_tslib();
    var parse_1 = require_parse();
    var APIPromise = /* @__PURE__ */ (() => {
      class APIPromise2 extends Promise {
        constructor(client, responsePromise, parseResponse = parse_1.defaultParseResponse) {
          super((resolve) => {
            resolve(null);
          });
          this.responsePromise = responsePromise;
          this.parseResponse = parseResponse;
          _APIPromise_client.set(this, void 0);
          tslib_1.__classPrivateFieldSet(this, _APIPromise_client, client, "f");
        }
        _thenUnwrap(transform) {
          return new APIPromise2(tslib_1.__classPrivateFieldGet(this, _APIPromise_client, "f"), this.responsePromise, async (client, props) => (0, parse_1.addResponseIDs)(transform(await this.parseResponse(client, props), props), props.response));
        }
        /**
         * Gets the raw `Response` instance instead of parsing the response
         * data.
         *
         * If you want to parse the response body but still get the `Response`
         * instance, you can use {@link withResponse()}.
         *
         * 👋 Getting the wrong TypeScript type for `Response`?
         * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
         * to your `tsconfig.json`.
         */
        asResponse() {
          return this.responsePromise.then((p) => p.response);
        }
        /**
         * Gets the parsed response data, the raw `Response` instance and the ID of the request,
         * returned via the `request-id` header which is useful for debugging requests and resporting
         * issues to Anthropic.
         *
         * If you just want to get the raw `Response` instance without parsing it,
         * you can use {@link asResponse()}.
         *
         * 👋 Getting the wrong TypeScript type for `Response`?
         * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
         * to your `tsconfig.json`.
         */
        async withResponse() {
          const [data, response] = await Promise.all([this.parse(), this.asResponse()]);
          return {
            data,
            response,
            request_id: response.headers.get("request-id"),
            workspace_id: response.headers.get("anthropic-workspace-id")
          };
        }
        parse() {
          if (!this.parsedPromise) {
            this.parsedPromise = this.responsePromise.then((data) => this.parseResponse(tslib_1.__classPrivateFieldGet(this, _APIPromise_client, "f"), data));
          }
          return this.parsedPromise;
        }
        then(onfulfilled, onrejected) {
          return this.parse().then(onfulfilled, onrejected);
        }
        catch(onrejected) {
          return this.parse().catch(onrejected);
        }
        finally(onfinally) {
          return this.parse().finally(onfinally);
        }
      }
      _APIPromise_client = /* @__PURE__ */ new WeakMap();
      return APIPromise2;
    })();
    exports2.APIPromise = APIPromise;
  }
});

// node_modules/@anthropic-ai/sdk/core/pagination.js
var require_pagination = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/pagination.js"(exports2) {
    "use strict";
    var _AbstractPage_client;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BidirectionalPageCursor = exports2.PageCursor = exports2.TokenPage = exports2.Page = exports2.PagePromise = exports2.AbstractPage = void 0;
    var tslib_1 = require_tslib();
    var error_1 = require_error();
    var parse_1 = require_parse();
    var api_promise_1 = require_api_promise();
    var values_1 = require_values();
    var AbstractPage = /* @__PURE__ */ (() => {
      class AbstractPage2 {
        constructor(client, response, body, options) {
          _AbstractPage_client.set(this, void 0);
          tslib_1.__classPrivateFieldSet(this, _AbstractPage_client, client, "f");
          this.options = options;
          this.response = response;
          this.body = body;
        }
        hasNextPage() {
          const items = this.getPaginatedItems();
          if (!items.length)
            return false;
          return this.nextPageRequestOptions() != null;
        }
        async getNextPage() {
          const nextOptions = this.nextPageRequestOptions();
          if (!nextOptions) {
            throw new error_1.AnthropicError("No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.");
          }
          return await tslib_1.__classPrivateFieldGet(this, _AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
        }
        async *iterPages() {
          let page = this;
          yield page;
          while (page.hasNextPage()) {
            page = await page.getNextPage();
            yield page;
          }
        }
        async *[(_AbstractPage_client = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
          for await (const page of this.iterPages()) {
            for (const item of page.getPaginatedItems()) {
              yield item;
            }
          }
        }
      }
      return AbstractPage2;
    })();
    exports2.AbstractPage = AbstractPage;
    var PagePromise = /* @__PURE__ */ (() => {
      class PagePromise2 extends api_promise_1.APIPromise {
        constructor(client, request, Page2) {
          super(client, request, async (client2, props) => new Page2(client2, props.response, await (0, parse_1.defaultParseResponse)(client2, props), props.options));
        }
        /**
         * Allow auto-paginating iteration on an unawaited list call, eg:
         *
         *    for await (const item of client.items.list()) {
         *      console.log(item)
         *    }
         */
        async *[Symbol.asyncIterator]() {
          const page = await this;
          for await (const item of page) {
            yield item;
          }
        }
      }
      return PagePromise2;
    })();
    exports2.PagePromise = PagePromise;
    var Page = class extends AbstractPage {
      constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.has_more = body.has_more || false;
        this.first_id = body.first_id || null;
        this.last_id = body.last_id || null;
      }
      getPaginatedItems() {
        return this.data ?? [];
      }
      hasNextPage() {
        if (this.has_more === false) {
          return false;
        }
        return super.hasNextPage();
      }
      nextPageRequestOptions() {
        if (this.options.query?.["before_id"]) {
          const first_id = this.first_id;
          if (!first_id) {
            return null;
          }
          return {
            ...this.options,
            query: {
              ...(0, values_1.maybeObj)(this.options.query),
              before_id: first_id
            }
          };
        }
        const cursor = this.last_id;
        if (!cursor) {
          return null;
        }
        return {
          ...this.options,
          query: {
            ...(0, values_1.maybeObj)(this.options.query),
            after_id: cursor
          }
        };
      }
    };
    exports2.Page = Page;
    var TokenPage = class extends AbstractPage {
      constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.has_more = body.has_more || false;
        this.next_page = body.next_page || null;
      }
      getPaginatedItems() {
        return this.data ?? [];
      }
      hasNextPage() {
        if (this.has_more === false) {
          return false;
        }
        return super.hasNextPage();
      }
      nextPageRequestOptions() {
        const cursor = this.next_page;
        if (!cursor) {
          return null;
        }
        return {
          ...this.options,
          query: {
            ...(0, values_1.maybeObj)(this.options.query),
            page_token: cursor
          }
        };
      }
    };
    exports2.TokenPage = TokenPage;
    var PageCursor = class extends AbstractPage {
      constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.next_page = body.next_page || null;
      }
      getPaginatedItems() {
        return this.data ?? [];
      }
      nextPageRequestOptions() {
        const cursor = this.next_page;
        if (!cursor) {
          return null;
        }
        return {
          ...this.options,
          query: {
            ...(0, values_1.maybeObj)(this.options.query),
            page: cursor
          }
        };
      }
    };
    exports2.PageCursor = PageCursor;
    var BidirectionalPageCursor = class extends AbstractPage {
      constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.next_page = body.next_page || null;
        this.prev_page = body.prev_page || null;
      }
      getPaginatedItems() {
        return this.data ?? [];
      }
      nextPageRequestOptions() {
        const cursor = this.next_page;
        if (!cursor) {
          return null;
        }
        return {
          ...this.options,
          query: {
            ...(0, values_1.maybeObj)(this.options.query),
            page: cursor
          }
        };
      }
    };
    exports2.BidirectionalPageCursor = BidirectionalPageCursor;
  }
});

// node_modules/@anthropic-ai/sdk/internal/uploads.js
var require_uploads = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/uploads.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createForm = exports2.multipartFormRequestOptions = exports2.maybeMultipartFormRequestOptions = exports2.isAsyncIterable = exports2.checkFileSupport = void 0;
    exports2.makeFile = makeFile;
    exports2.getName = getName;
    var shims_1 = require_shims();
    var checkFileSupport = () => {
      if (typeof File === "undefined") {
        const { process: process2 } = globalThis;
        const isOldNode = typeof process2?.versions?.node === "string" && parseInt(process2.versions.node.split(".")) < 20;
        throw new Error("`File` is not defined as a global, which is required for file uploads." + (isOldNode ? " Update to Node 20 LTS or newer, or set `globalThis.File` to `import('node:buffer').File`." : ""));
      }
    };
    exports2.checkFileSupport = checkFileSupport;
    function makeFile(fileBits, fileName, options) {
      (0, exports2.checkFileSupport)();
      return new File(fileBits, fileName ?? "unknown_file", options);
    }
    function getName(value, stripPath) {
      const val = typeof value === "object" && value !== null && ("name" in value && value.name && String(value.name) || "url" in value && value.url && String(value.url) || "filename" in value && value.filename && String(value.filename) || "path" in value && value.path && String(value.path)) || "";
      return stripPath ? val.split(/[\\/]/).pop() || void 0 : val;
    }
    var isAsyncIterable = (value) => value != null && typeof value === "object" && typeof value[Symbol.asyncIterator] === "function";
    exports2.isAsyncIterable = isAsyncIterable;
    var maybeMultipartFormRequestOptions = async (opts, fetch2) => {
      if (!hasUploadableValue(opts.body))
        return opts;
      return { ...opts, body: await (0, exports2.createForm)(opts.body, fetch2) };
    };
    exports2.maybeMultipartFormRequestOptions = maybeMultipartFormRequestOptions;
    var multipartFormRequestOptions = async (opts, fetch2, stripFilenames = true) => {
      return { ...opts, body: await (0, exports2.createForm)(opts.body, fetch2, stripFilenames) };
    };
    exports2.multipartFormRequestOptions = multipartFormRequestOptions;
    var supportsFormDataMap = /* @__PURE__ */ new WeakMap();
    function supportsFormData(fetchObject) {
      const fetch2 = typeof fetchObject === "function" ? fetchObject : fetchObject.fetch;
      const cached = supportsFormDataMap.get(fetch2);
      if (cached)
        return cached;
      const promise = (async () => {
        try {
          const FetchResponse = "Response" in fetch2 ? fetch2.Response : (await fetch2("data:,")).constructor;
          const data = new FormData();
          if (data.toString() === await new FetchResponse(data).text()) {
            return false;
          }
          return true;
        } catch {
          return true;
        }
      })();
      supportsFormDataMap.set(fetch2, promise);
      return promise;
    }
    var createForm = async (body, fetch2, stripFilenames = true) => {
      if (!await supportsFormData(fetch2)) {
        throw new TypeError("The provided fetch function does not support file uploads with the current global FormData class.");
      }
      const form = new FormData();
      await Promise.all(Object.entries(body || {}).map(([key, value]) => addFormValue(form, key, value, stripFilenames)));
      return form;
    };
    exports2.createForm = createForm;
    var isUploadable = (value) => typeof value === "object" && value !== null && (value instanceof Response || (0, exports2.isAsyncIterable)(value) || value instanceof Blob);
    var hasUploadableValue = (value) => {
      if (isUploadable(value))
        return true;
      if (Array.isArray(value))
        return value.some(hasUploadableValue);
      if (value && typeof value === "object") {
        for (const k in value) {
          if (hasUploadableValue(value[k]))
            return true;
        }
      }
      return false;
    };
    var addFormValue = async (form, key, value, stripFilenames) => {
      if (value === void 0)
        return;
      if (value == null) {
        throw new TypeError(`Received null for "${key}"; to pass null in FormData, you must use the string 'null'`);
      }
      if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
        form.append(key, String(value));
      } else if (value instanceof Response) {
        let options = {};
        const contentType = value.headers.get("Content-Type");
        if (contentType) {
          options = { type: contentType };
        }
        form.append(key, makeFile([await value.blob()], getName(value, stripFilenames), options));
      } else if ((0, exports2.isAsyncIterable)(value)) {
        form.append(key, makeFile([await new Response((0, shims_1.ReadableStreamFrom)(value)).blob()], getName(value, stripFilenames)));
      } else if (value instanceof Blob) {
        form.append(key, makeFile([value], getName(value, stripFilenames) || void 0, { type: value.type }));
      } else if (Array.isArray(value)) {
        await Promise.all(value.map((entry) => addFormValue(form, key + "[]", entry, stripFilenames)));
      } else if (typeof value.then === "function") {
        throw new TypeError(`Received a Promise for "${key}"; await it first, e.g. \`await toFile(...)\``);
      } else if (value instanceof ArrayBuffer || ArrayBuffer.isView(value)) {
        throw new TypeError(`Received ${value.constructor.name} for "${key}"; to upload raw bytes, wrap them with \`await toFile(bytes, 'filename')\``);
      } else if (typeof value === "object") {
        await Promise.all(Object.entries(value).map(([name, prop]) => addFormValue(form, `${key}[${name}]`, prop, stripFilenames)));
      } else {
        throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${value} instead`);
      }
    };
  }
});

// node_modules/@anthropic-ai/sdk/internal/to-file.js
var require_to_file = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/to-file.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.toFile = toFile;
    var uploads_1 = require_uploads();
    var uploads_2 = require_uploads();
    var isBlobLike = (value) => value != null && typeof value === "object" && typeof value.size === "number" && typeof value.type === "string" && typeof value.text === "function" && typeof value.slice === "function" && typeof value.arrayBuffer === "function";
    var isFileLike = (value) => value != null && typeof value === "object" && typeof value.name === "string" && typeof value.lastModified === "number" && isBlobLike(value);
    var isResponseLike = (value) => value != null && typeof value === "object" && typeof value.url === "string" && typeof value.blob === "function";
    async function toFile(value, name, options) {
      (0, uploads_2.checkFileSupport)();
      value = await value;
      name || (name = (0, uploads_1.getName)(value, true));
      if (isFileLike(value)) {
        if (value instanceof File && name == null && options == null) {
          return value;
        }
        return (0, uploads_1.makeFile)([await value.arrayBuffer()], name ?? value.name, {
          type: value.type,
          lastModified: value.lastModified,
          ...options
        });
      }
      if (isResponseLike(value)) {
        const blob = await value.blob();
        name || (name = new URL(value.url).pathname.split(/[\\/]/).pop());
        return (0, uploads_1.makeFile)(await getBytes(blob), name, options);
      }
      const parts = await getBytes(value);
      if (!options?.type) {
        const type = parts.find((part) => typeof part === "object" && "type" in part && part.type);
        if (typeof type === "string") {
          options = { ...options, type };
        }
      }
      return (0, uploads_1.makeFile)(parts, name, options);
    }
    async function getBytes(value) {
      let parts = [];
      if (typeof value === "string" || ArrayBuffer.isView(value) || // includes Uint8Array, Buffer, etc.
      value instanceof ArrayBuffer) {
        parts.push(value);
      } else if (isBlobLike(value)) {
        parts.push(value instanceof Blob ? value : await value.arrayBuffer());
      } else if ((0, uploads_1.isAsyncIterable)(value)) {
        for await (const chunk of value) {
          parts.push(...await getBytes(chunk));
        }
      } else {
        const constructor = value?.constructor?.name;
        throw new Error(`Unexpected data type: ${typeof value}${constructor ? `; constructor: ${constructor}` : ""}${propsForError(value)}`);
      }
      return parts;
    }
    function propsForError(value) {
      if (typeof value !== "object" || value === null)
        return "";
      const props = Object.getOwnPropertyNames(value);
      return `; props: [${props.map((p) => `"${p}"`).join(", ")}]`;
    }
  }
});

// node_modules/@anthropic-ai/sdk/core/uploads.js
var require_uploads2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/uploads.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.toFile = void 0;
    var to_file_1 = require_to_file();
    Object.defineProperty(exports2, "toFile", { enumerable: true, get: function() {
      return to_file_1.toFile;
    } });
  }
});

// node_modules/@anthropic-ai/sdk/resources/shared.js
var require_shared = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/shared.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// node_modules/@anthropic-ai/sdk/core/resource.js
var require_resource = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/resource.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.APIResource = void 0;
    var APIResource = class {
      constructor(client) {
        this._client = client;
      }
    };
    exports2.APIResource = APIResource;
  }
});

// node_modules/@anthropic-ai/sdk/internal/headers.js
var require_headers = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/headers.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isEmptyHeaders = exports2.buildHeaders = exports2.appendHeaderValue = exports2.APPEND_HEADERS = void 0;
    var values_1 = require_values();
    var brand_privateNullableHeaders = /* @__PURE__ */ Symbol.for("brand.privateNullableHeaders");
    function* iterateHeaders(headers) {
      if (!headers)
        return;
      if (brand_privateNullableHeaders in headers) {
        const { values, nulls } = headers;
        yield* values.entries();
        for (const name of nulls) {
          yield [name, null];
        }
        return;
      }
      let shouldClear = false;
      let iter;
      if (headers instanceof Headers) {
        iter = headers.entries();
      } else if ((0, values_1.isReadonlyArray)(headers)) {
        iter = headers;
      } else {
        shouldClear = true;
        iter = Object.entries(headers ?? {});
      }
      for (let row of iter) {
        const name = row[0];
        if (typeof name !== "string")
          throw new TypeError("expected header name to be a string");
        const values = (0, values_1.isReadonlyArray)(row[1]) ? row[1] : [row[1]];
        let didClear = false;
        for (const value of values) {
          if (value === void 0)
            continue;
          if (shouldClear && !didClear) {
            didClear = true;
            yield [name, clearSentinel];
          }
          yield [name, value];
        }
      }
    }
    var clearSentinel = /* @__PURE__ */ Symbol("clear");
    exports2.APPEND_HEADERS = /* @__PURE__ */ new Set(["x-stainless-helper"]);
    var appendHeaderValue = (existing, addition) => {
      const tokens = existing ? existing.split(",").map((t) => t.trim()).filter(Boolean) : [];
      for (const tok of addition.split(",").map((t) => t.trim())) {
        if (tok && !tokens.includes(tok))
          tokens.push(tok);
      }
      return tokens.join(", ");
    };
    exports2.appendHeaderValue = appendHeaderValue;
    var buildHeaders = (newHeaders) => {
      const targetHeaders = new Headers();
      const nullHeaders = /* @__PURE__ */ new Set();
      for (const headers of newHeaders) {
        const seenHeaders = /* @__PURE__ */ new Set();
        for (const [name, value] of iterateHeaders(headers)) {
          const lowerName = name.toLowerCase();
          if (exports2.APPEND_HEADERS.has(lowerName)) {
            if (value === clearSentinel)
              continue;
            if (value === null) {
              targetHeaders.delete(name);
              nullHeaders.add(lowerName);
            } else {
              targetHeaders.set(name, (0, exports2.appendHeaderValue)(targetHeaders.get(name), value));
              nullHeaders.delete(lowerName);
            }
            continue;
          }
          if (value === clearSentinel || !seenHeaders.has(lowerName)) {
            targetHeaders.delete(name);
            seenHeaders.add(lowerName);
            if (value === clearSentinel)
              continue;
          }
          if (value === null) {
            targetHeaders.delete(name);
            nullHeaders.add(lowerName);
          } else {
            targetHeaders.append(name, value);
            nullHeaders.delete(lowerName);
          }
        }
      }
      return { [brand_privateNullableHeaders]: true, values: targetHeaders, nulls: nullHeaders };
    };
    exports2.buildHeaders = buildHeaders;
    var isEmptyHeaders = (headers) => {
      for (const _ of iterateHeaders(headers))
        return false;
      return true;
    };
    exports2.isEmptyHeaders = isEmptyHeaders;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/path.js
var require_path = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/path.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.path = exports2.createPathTagFunction = void 0;
    exports2.encodeURIPath = encodeURIPath;
    var error_1 = require_error();
    function encodeURIPath(str) {
      return str.replace(/[^A-Za-z0-9\-._~!$&'()*+,;=:@]+/g, encodeURIComponent);
    }
    var EMPTY = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.create(null));
    var createPathTagFunction = (pathEncoder = encodeURIPath) => function path2(statics, ...params) {
      if (statics.length === 1)
        return statics[0];
      let postPath = false;
      const invalidSegments = [];
      const path3 = statics.reduce((previousValue, currentValue, index) => {
        if (/[?#]/.test(currentValue)) {
          postPath = true;
        }
        const value = params[index];
        let encoded = (postPath ? encodeURIComponent : pathEncoder)("" + value);
        if (index !== params.length && (value == null || typeof value === "object" && // handle values from other realms
        value.toString === Object.getPrototypeOf(Object.getPrototypeOf(value.hasOwnProperty ?? EMPTY) ?? EMPTY)?.toString)) {
          encoded = value + "";
          invalidSegments.push({
            start: previousValue.length + currentValue.length,
            length: encoded.length,
            error: `Value of type ${Object.prototype.toString.call(value).slice(8, -1)} is not a valid path parameter`
          });
        }
        return previousValue + currentValue + (index === params.length ? "" : encoded);
      }, "");
      const pathOnly = path3.split(/[?#]/, 1)[0];
      const invalidSegmentPattern = /(?<=^|\/)(?:\.|%2e){1,2}(?=\/|$)/gi;
      let match;
      while ((match = invalidSegmentPattern.exec(pathOnly)) !== null) {
        invalidSegments.push({
          start: match.index,
          length: match[0].length,
          error: `Value "${match[0]}" can't be safely passed as a path parameter`
        });
      }
      invalidSegments.sort((a, b) => a.start - b.start);
      if (invalidSegments.length > 0) {
        let lastEnd = 0;
        const underline = invalidSegments.reduce((acc, segment) => {
          const spaces = " ".repeat(segment.start - lastEnd);
          const arrows = "^".repeat(segment.length);
          lastEnd = segment.start + segment.length;
          return acc + spaces + arrows;
        }, "");
        throw new error_1.AnthropicError(`Path parameters result in path with invalid segments:
${invalidSegments.map((e) => e.error).join("\n")}
${path3}
${underline}`);
      }
      return path3;
    };
    exports2.createPathTagFunction = createPathTagFunction;
    exports2.path = (0, exports2.createPathTagFunction)(encodeURIPath);
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/deployment-runs.js
var require_deployment_runs = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/deployment-runs.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DeploymentRuns = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var DeploymentRuns = class extends resource_1.APIResource {
      /**
       * Get Deployment Run
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeploymentRun =
       *   await client.beta.deploymentRuns.retrieve(
       *     'deployment_run_id',
       *   );
       * ```
       */
      retrieve(deploymentRunID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/deployment_runs/${deploymentRunID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List Deployment Runs
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsDeploymentRun of client.beta.deploymentRuns.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList("/v1/deployment_runs?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.DeploymentRuns = DeploymentRuns;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/deployments.js
var require_deployments = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/deployments.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Deployments = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Deployments = class extends resource_1.APIResource {
      /**
       * Create Deployment
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeployment =
       *   await client.beta.deployments.create({
       *     agent: 'string',
       *     environment_id: 'x',
       *     initial_events: [
       *       {
       *         content: [
       *           {
       *             text: 'Where is my order #1234?',
       *             type: 'text',
       *           },
       *         ],
       *         type: 'user.message',
       *       },
       *     ],
       *     name: 'x',
       *   });
       * ```
       */
      create(params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post("/v1/deployments?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Get Deployment
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeployment =
       *   await client.beta.deployments.retrieve(
       *     'depl_011CZkZcDH3vPqd7xnEfwTai',
       *   );
       * ```
       */
      retrieve(deploymentID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/deployments/${deploymentID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Update Deployment
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeployment =
       *   await client.beta.deployments.update(
       *     'depl_011CZkZcDH3vPqd7xnEfwTai',
       *   );
       * ```
       */
      update(deploymentID, params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/deployments/${deploymentID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List Deployments
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsDeployment of client.beta.deployments.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList("/v1/deployments?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Archive Deployment
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeployment =
       *   await client.beta.deployments.archive(
       *     'depl_011CZkZcDH3vPqd7xnEfwTai',
       *   );
       * ```
       */
      archive(deploymentID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/deployments/${deploymentID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Pause Deployment
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeployment =
       *   await client.beta.deployments.pause(
       *     'depl_011CZkZcDH3vPqd7xnEfwTai',
       *   );
       * ```
       */
      pause(deploymentID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/deployments/${deploymentID}/pause?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Run Deployment Now
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeploymentRun =
       *   await client.beta.deployments.run(
       *     'depl_011CZkZcDH3vPqd7xnEfwTai',
       *   );
       * ```
       */
      run(deploymentID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/deployments/${deploymentID}/run?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Unpause Deployment
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeployment =
       *   await client.beta.deployments.unpause(
       *     'depl_011CZkZcDH3vPqd7xnEfwTai',
       *   );
       * ```
       */
      unpause(deploymentID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/deployments/${deploymentID}/unpause?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.Deployments = Deployments;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/dreams.js
var require_dreams = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/dreams.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Dreams = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Dreams = class extends resource_1.APIResource {
      /**
       * Start an asynchronous job that uses past sessions to produce a reorganized
       * version of a memory store and get back the dream to poll for the result.
       *
       * By default the dream writes its result to a new memory store and doesn't change
       * the input memory store. The response has `status` set to `pending` and an empty
       * `outputs` array. Poll the dream until `status` is `completed`, `failed`, or
       * `canceled`.
       *
       * See the
       * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#create-a-dream)
       * to learn more about creating dreams.
       *
       * @example
       * ```ts
       * const betaDream = await client.beta.dreams.create({
       *   inputs: [{ memory_store_id: 'x', type: 'memory_store' }],
       *   model: 'string',
       * });
       * ```
       */
      create(params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post("/v1/dreams?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "dreaming-2026-04-21"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Get a dream by ID to check its status, output memory store, and token usage.
       *
       * Archived dreams are returned too.
       *
       * See the
       * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#track-progress)
       * for how to poll a dream and what each status means.
       *
       * @example
       * ```ts
       * const betaDream = await client.beta.dreams.retrieve(
       *   'dream_id',
       * );
       * ```
       */
      retrieve(dreamID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/dreams/${dreamID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "dreaming-2026-04-21"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List the dreams in the workspace, newest first.
       *
       * Archived dreams are left out unless `include_archived` is `true`.
       *
       * See the
       * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#list-dreams)
       * for how to page through dreams.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaDream of client.beta.dreams.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList("/v1/dreams?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "dreaming-2026-04-21"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Hide a `completed`, `failed`, or `canceled` dream from the default list of
       * dreams.
       *
       * Archiving a `pending` or `running` dream returns a 400 error, so cancel it
       * first. Archiving an archived dream returns it unchanged. An archived dream can
       * still be fetched by ID. Archiving can't be undone.
       *
       * See the
       * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#archive-a-dream)
       * to learn more about archiving dreams.
       *
       * @example
       * ```ts
       * const betaDream = await client.beta.dreams.archive(
       *   'dream_id',
       * );
       * ```
       */
      archive(dreamID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/dreams/${dreamID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "dreaming-2026-04-21"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Stop a `pending` or `running` dream.
       *
       * The response shows `status` as `canceled`, unless the dream reached `completed`
       * or `failed` first. `usage` can keep changing after the response. Canceling a
       * `canceled` dream returns it unchanged. Canceling a `completed` or `failed` dream
       * returns a 400 error.
       *
       * See the
       * [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams#cancel-a-dream)
       * to learn more about canceling dreams.
       *
       * @example
       * ```ts
       * const betaDream = await client.beta.dreams.cancel(
       *   'dream_id',
       * );
       * ```
       */
      cancel(dreamID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/dreams/${dreamID}/cancel?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "dreaming-2026-04-21"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.Dreams = Dreams;
  }
});

// node_modules/@anthropic-ai/sdk/internal/stainless-helper-header.js
var require_stainless_helper_header = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/stainless-helper-header.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SDK_HELPER_SYMBOL = exports2.STAINLESS_HELPER_METHOD_HEADER = exports2.STAINLESS_HELPER_HEADER = void 0;
    exports2.helperHeader = helperHeader;
    exports2.wasCreatedByStainlessHelper = wasCreatedByStainlessHelper;
    exports2.collectStainlessHelpers = collectStainlessHelpers;
    exports2.stainlessHelperHeader = stainlessHelperHeader;
    exports2.stainlessHelperHeaderFromFile = stainlessHelperHeaderFromFile;
    exports2.STAINLESS_HELPER_HEADER = "x-stainless-helper";
    exports2.STAINLESS_HELPER_METHOD_HEADER = "x-stainless-helper-method";
    function helperHeader(value) {
      return { [exports2.STAINLESS_HELPER_HEADER]: value };
    }
    exports2.SDK_HELPER_SYMBOL = /* @__PURE__ */ Symbol("anthropic.sdk.stainlessHelper");
    function wasCreatedByStainlessHelper(value) {
      return typeof value === "object" && value !== null && exports2.SDK_HELPER_SYMBOL in value;
    }
    function collectStainlessHelpers(tools, messages) {
      const helpers = /* @__PURE__ */ new Set();
      if (tools) {
        for (const tool of tools) {
          if (wasCreatedByStainlessHelper(tool)) {
            helpers.add(tool[exports2.SDK_HELPER_SYMBOL]);
          }
        }
      }
      if (messages) {
        for (const message of messages) {
          if (wasCreatedByStainlessHelper(message)) {
            helpers.add(message[exports2.SDK_HELPER_SYMBOL]);
          }
          const content = message.content;
          if (Array.isArray(content)) {
            for (const block of content) {
              if (wasCreatedByStainlessHelper(block)) {
                helpers.add(block[exports2.SDK_HELPER_SYMBOL]);
              }
              const definition = block?.tool?.definition;
              if (wasCreatedByStainlessHelper(definition)) {
                helpers.add(definition[exports2.SDK_HELPER_SYMBOL]);
              }
            }
          }
        }
      }
      return Array.from(helpers);
    }
    function stainlessHelperHeader(tools, messages) {
      const helpers = collectStainlessHelpers(tools, messages);
      if (helpers.length === 0)
        return {};
      return { [exports2.STAINLESS_HELPER_HEADER]: helpers.join(", ") };
    }
    function stainlessHelperHeaderFromFile(file) {
      if (wasCreatedByStainlessHelper(file)) {
        return { [exports2.STAINLESS_HELPER_HEADER]: file[exports2.SDK_HELPER_SYMBOL] };
      }
      return {};
    }
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/files.js
var require_files = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/files.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Files = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var uploads_1 = require_uploads();
    var path_1 = require_path();
    var Files = class extends resource_1.APIResource {
      /**
       * List Files
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaFileMetadata of client.beta.files.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList("/v1/files?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Delete File
       *
       * @example
       * ```ts
       * const betaDeletedFile = await client.beta.files.delete(
       *   'file_id',
       * );
       * ```
       */
      delete(fileID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/files/${fileID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Download File
       *
       * @example
       * ```ts
       * const response = await client.beta.files.download(
       *   'file_id',
       * );
       *
       * const content = await response.blob();
       * console.log(content);
       * ```
       */
      download(fileID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/files/${fileID}/content?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              Accept: "application/binary",
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ]),
          __binaryResponse: true
        });
      }
      /**
       * Get File Metadata
       *
       * @example
       * ```ts
       * const betaFileMetadata =
       *   await client.beta.files.retrieveMetadata('file_id');
       * ```
       */
      retrieveMetadata(fileID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/files/${fileID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Upload File
       *
       * @example
       * ```ts
       * const betaFileMetadata = await client.beta.files.upload({
       *   file: fs.createReadStream('path/to/file'),
       * });
       * ```
       */
      upload(params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post("/v1/files?beta=true", (0, uploads_1.multipartFormRequestOptions)({
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            (0, stainless_helper_header_1.stainlessHelperHeaderFromFile)(body.file),
            options?.headers
          ])
        }, this._client));
      }
    };
    exports2.Files = Files;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/models.js
var require_models = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/models.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Models = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Models = class extends resource_1.APIResource {
      /**
       * Get a specific model.
       *
       * The Models API response can be used to determine information about a specific
       * model or resolve a model alias to a model ID.
       *
       * @example
       * ```ts
       * const betaModelInfo = await client.beta.models.retrieve(
       *   'model_id',
       * );
       * ```
       */
      retrieve(modelID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/models/${modelID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List available models.
       *
       * The Models API response can be used to determine which models are available for
       * use in the API. More recently released models are listed first.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaModelInfo of client.beta.models.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList("/v1/models?beta=true", pagination_1.Page, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.Models = Models;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/user-profiles.js
var require_user_profiles = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/user-profiles.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.UserProfiles = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var UserProfiles = class extends resource_1.APIResource {
      /**
       * Create User Profile
       *
       * @example
       * ```ts
       * const betaUserProfile =
       *   await client.beta.userProfiles.create();
       * ```
       */
      create(params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post("/v1/user_profiles?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "user-profiles-2026-08-18"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Get User Profile
       *
       * @example
       * ```ts
       * const betaUserProfile =
       *   await client.beta.userProfiles.retrieve(
       *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
       *   );
       * ```
       */
      retrieve(userProfileID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/user_profiles/${userProfileID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "user-profiles-2026-08-18"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Update User Profile
       *
       * @example
       * ```ts
       * const betaUserProfile =
       *   await client.beta.userProfiles.update(
       *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
       *   );
       * ```
       */
      update(userProfileID, params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/user_profiles/${userProfileID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "user-profiles-2026-08-18"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List User Profiles
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaUserProfile of client.beta.userProfiles.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList("/v1/user_profiles?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "user-profiles-2026-08-18"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Create Enrollment URL
       *
       * @example
       * ```ts
       * const betaUserProfileEnrollmentURL =
       *   await client.beta.userProfiles.createEnrollmentURL(
       *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
       *   );
       * ```
       */
      createEnrollmentURL(userProfileID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/user_profiles/${userProfileID}/enrollment_url?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "user-profiles-2026-08-18"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.UserProfiles = UserProfiles;
  }
});

// node_modules/@stablelib/base64/lib/base64.js
var require_base642 = __commonJS({
  "node_modules/@stablelib/base64/lib/base64.js"(exports2) {
    "use strict";
    var __extends = exports2 && exports2.__extends || /* @__PURE__ */ (function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
          d2.__proto__ = b2;
        } || function(d2, b2) {
          for (var p in b2) if (b2.hasOwnProperty(p)) d2[p] = b2[p];
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    var INVALID_BYTE = 256;
    var Coder = (
      /** @class */
      (function() {
        function Coder2(_paddingCharacter) {
          if (_paddingCharacter === void 0) {
            _paddingCharacter = "=";
          }
          this._paddingCharacter = _paddingCharacter;
        }
        Coder2.prototype.encodedLength = function(length) {
          if (!this._paddingCharacter) {
            return (length * 8 + 5) / 6 | 0;
          }
          return (length + 2) / 3 * 4 | 0;
        };
        Coder2.prototype.encode = function(data) {
          var out = "";
          var i = 0;
          for (; i < data.length - 2; i += 3) {
            var c = data[i] << 16 | data[i + 1] << 8 | data[i + 2];
            out += this._encodeByte(c >>> 3 * 6 & 63);
            out += this._encodeByte(c >>> 2 * 6 & 63);
            out += this._encodeByte(c >>> 1 * 6 & 63);
            out += this._encodeByte(c >>> 0 * 6 & 63);
          }
          var left = data.length - i;
          if (left > 0) {
            var c = data[i] << 16 | (left === 2 ? data[i + 1] << 8 : 0);
            out += this._encodeByte(c >>> 3 * 6 & 63);
            out += this._encodeByte(c >>> 2 * 6 & 63);
            if (left === 2) {
              out += this._encodeByte(c >>> 1 * 6 & 63);
            } else {
              out += this._paddingCharacter || "";
            }
            out += this._paddingCharacter || "";
          }
          return out;
        };
        Coder2.prototype.maxDecodedLength = function(length) {
          if (!this._paddingCharacter) {
            return (length * 6 + 7) / 8 | 0;
          }
          return length / 4 * 3 | 0;
        };
        Coder2.prototype.decodedLength = function(s) {
          return this.maxDecodedLength(s.length - this._getPaddingLength(s));
        };
        Coder2.prototype.decode = function(s) {
          if (s.length === 0) {
            return new Uint8Array(0);
          }
          var paddingLength = this._getPaddingLength(s);
          var length = s.length - paddingLength;
          var out = new Uint8Array(this.maxDecodedLength(length));
          var op = 0;
          var i = 0;
          var haveBad = 0;
          var v0 = 0, v1 = 0, v2 = 0, v3 = 0;
          for (; i < length - 4; i += 4) {
            v0 = this._decodeChar(s.charCodeAt(i + 0));
            v1 = this._decodeChar(s.charCodeAt(i + 1));
            v2 = this._decodeChar(s.charCodeAt(i + 2));
            v3 = this._decodeChar(s.charCodeAt(i + 3));
            out[op++] = v0 << 2 | v1 >>> 4;
            out[op++] = v1 << 4 | v2 >>> 2;
            out[op++] = v2 << 6 | v3;
            haveBad |= v0 & INVALID_BYTE;
            haveBad |= v1 & INVALID_BYTE;
            haveBad |= v2 & INVALID_BYTE;
            haveBad |= v3 & INVALID_BYTE;
          }
          if (i < length - 1) {
            v0 = this._decodeChar(s.charCodeAt(i));
            v1 = this._decodeChar(s.charCodeAt(i + 1));
            out[op++] = v0 << 2 | v1 >>> 4;
            haveBad |= v0 & INVALID_BYTE;
            haveBad |= v1 & INVALID_BYTE;
          }
          if (i < length - 2) {
            v2 = this._decodeChar(s.charCodeAt(i + 2));
            out[op++] = v1 << 4 | v2 >>> 2;
            haveBad |= v2 & INVALID_BYTE;
          }
          if (i < length - 3) {
            v3 = this._decodeChar(s.charCodeAt(i + 3));
            out[op++] = v2 << 6 | v3;
            haveBad |= v3 & INVALID_BYTE;
          }
          if (haveBad !== 0) {
            throw new Error("Base64Coder: incorrect characters for decoding");
          }
          return out;
        };
        Coder2.prototype._encodeByte = function(b) {
          var result = b;
          result += 65;
          result += 25 - b >>> 8 & 0 - 65 - 26 + 97;
          result += 51 - b >>> 8 & 26 - 97 - 52 + 48;
          result += 61 - b >>> 8 & 52 - 48 - 62 + 43;
          result += 62 - b >>> 8 & 62 - 43 - 63 + 47;
          return String.fromCharCode(result);
        };
        Coder2.prototype._decodeChar = function(c) {
          var result = INVALID_BYTE;
          result += (42 - c & c - 44) >>> 8 & -INVALID_BYTE + c - 43 + 62;
          result += (46 - c & c - 48) >>> 8 & -INVALID_BYTE + c - 47 + 63;
          result += (47 - c & c - 58) >>> 8 & -INVALID_BYTE + c - 48 + 52;
          result += (64 - c & c - 91) >>> 8 & -INVALID_BYTE + c - 65 + 0;
          result += (96 - c & c - 123) >>> 8 & -INVALID_BYTE + c - 97 + 26;
          return result;
        };
        Coder2.prototype._getPaddingLength = function(s) {
          var paddingLength = 0;
          if (this._paddingCharacter) {
            for (var i = s.length - 1; i >= 0; i--) {
              if (s[i] !== this._paddingCharacter) {
                break;
              }
              paddingLength++;
            }
            if (s.length < 4 || paddingLength > 2) {
              throw new Error("Base64Coder: incorrect padding");
            }
          }
          return paddingLength;
        };
        return Coder2;
      })()
    );
    exports2.Coder = Coder;
    var stdCoder = new Coder();
    function encode(data) {
      return stdCoder.encode(data);
    }
    exports2.encode = encode;
    function decode(s) {
      return stdCoder.decode(s);
    }
    exports2.decode = decode;
    var URLSafeCoder = (
      /** @class */
      (function(_super) {
        __extends(URLSafeCoder2, _super);
        function URLSafeCoder2() {
          return _super !== null && _super.apply(this, arguments) || this;
        }
        URLSafeCoder2.prototype._encodeByte = function(b) {
          var result = b;
          result += 65;
          result += 25 - b >>> 8 & 0 - 65 - 26 + 97;
          result += 51 - b >>> 8 & 26 - 97 - 52 + 48;
          result += 61 - b >>> 8 & 52 - 48 - 62 + 45;
          result += 62 - b >>> 8 & 62 - 45 - 63 + 95;
          return String.fromCharCode(result);
        };
        URLSafeCoder2.prototype._decodeChar = function(c) {
          var result = INVALID_BYTE;
          result += (44 - c & c - 46) >>> 8 & -INVALID_BYTE + c - 45 + 62;
          result += (94 - c & c - 96) >>> 8 & -INVALID_BYTE + c - 95 + 63;
          result += (47 - c & c - 58) >>> 8 & -INVALID_BYTE + c - 48 + 52;
          result += (64 - c & c - 91) >>> 8 & -INVALID_BYTE + c - 65 + 0;
          result += (96 - c & c - 123) >>> 8 & -INVALID_BYTE + c - 97 + 26;
          return result;
        };
        return URLSafeCoder2;
      })(Coder)
    );
    exports2.URLSafeCoder = URLSafeCoder;
    var urlSafeCoder = new URLSafeCoder();
    function encodeURLSafe(data) {
      return urlSafeCoder.encode(data);
    }
    exports2.encodeURLSafe = encodeURLSafe;
    function decodeURLSafe(s) {
      return urlSafeCoder.decode(s);
    }
    exports2.decodeURLSafe = decodeURLSafe;
    exports2.encodedLength = function(length) {
      return stdCoder.encodedLength(length);
    };
    exports2.maxDecodedLength = function(length) {
      return stdCoder.maxDecodedLength(length);
    };
    exports2.decodedLength = function(s) {
      return stdCoder.decodedLength(s);
    };
  }
});

// node_modules/fast-sha256/sha256.js
var require_sha256 = __commonJS({
  "node_modules/fast-sha256/sha256.js"(exports2, module2) {
    (function(root, factory) {
      var exports3 = {};
      factory(exports3);
      var sha256 = exports3["default"];
      for (var k in exports3) {
        sha256[k] = exports3[k];
      }
      if (typeof module2 === "object" && typeof module2.exports === "object") {
        module2.exports = sha256;
      } else if (typeof define === "function" && define.amd) {
        define(function() {
          return sha256;
        });
      } else {
        root.sha256 = sha256;
      }
    })(exports2, function(exports3) {
      "use strict";
      exports3.__esModule = true;
      exports3.digestLength = 32;
      exports3.blockSize = 64;
      var K = new Uint32Array([
        1116352408,
        1899447441,
        3049323471,
        3921009573,
        961987163,
        1508970993,
        2453635748,
        2870763221,
        3624381080,
        310598401,
        607225278,
        1426881987,
        1925078388,
        2162078206,
        2614888103,
        3248222580,
        3835390401,
        4022224774,
        264347078,
        604807628,
        770255983,
        1249150122,
        1555081692,
        1996064986,
        2554220882,
        2821834349,
        2952996808,
        3210313671,
        3336571891,
        3584528711,
        113926993,
        338241895,
        666307205,
        773529912,
        1294757372,
        1396182291,
        1695183700,
        1986661051,
        2177026350,
        2456956037,
        2730485921,
        2820302411,
        3259730800,
        3345764771,
        3516065817,
        3600352804,
        4094571909,
        275423344,
        430227734,
        506948616,
        659060556,
        883997877,
        958139571,
        1322822218,
        1537002063,
        1747873779,
        1955562222,
        2024104815,
        2227730452,
        2361852424,
        2428436474,
        2756734187,
        3204031479,
        3329325298
      ]);
      function hashBlocks(w, v, p, pos, len) {
        var a, b, c, d, e, f, g, h, u, i, j, t1, t2;
        while (len >= 64) {
          a = v[0];
          b = v[1];
          c = v[2];
          d = v[3];
          e = v[4];
          f = v[5];
          g = v[6];
          h = v[7];
          for (i = 0; i < 16; i++) {
            j = pos + i * 4;
            w[i] = (p[j] & 255) << 24 | (p[j + 1] & 255) << 16 | (p[j + 2] & 255) << 8 | p[j + 3] & 255;
          }
          for (i = 16; i < 64; i++) {
            u = w[i - 2];
            t1 = (u >>> 17 | u << 32 - 17) ^ (u >>> 19 | u << 32 - 19) ^ u >>> 10;
            u = w[i - 15];
            t2 = (u >>> 7 | u << 32 - 7) ^ (u >>> 18 | u << 32 - 18) ^ u >>> 3;
            w[i] = (t1 + w[i - 7] | 0) + (t2 + w[i - 16] | 0);
          }
          for (i = 0; i < 64; i++) {
            t1 = (((e >>> 6 | e << 32 - 6) ^ (e >>> 11 | e << 32 - 11) ^ (e >>> 25 | e << 32 - 25)) + (e & f ^ ~e & g) | 0) + (h + (K[i] + w[i] | 0) | 0) | 0;
            t2 = ((a >>> 2 | a << 32 - 2) ^ (a >>> 13 | a << 32 - 13) ^ (a >>> 22 | a << 32 - 22)) + (a & b ^ a & c ^ b & c) | 0;
            h = g;
            g = f;
            f = e;
            e = d + t1 | 0;
            d = c;
            c = b;
            b = a;
            a = t1 + t2 | 0;
          }
          v[0] += a;
          v[1] += b;
          v[2] += c;
          v[3] += d;
          v[4] += e;
          v[5] += f;
          v[6] += g;
          v[7] += h;
          pos += 64;
          len -= 64;
        }
        return pos;
      }
      var Hash = (
        /** @class */
        (function() {
          function Hash2() {
            this.digestLength = exports3.digestLength;
            this.blockSize = exports3.blockSize;
            this.state = new Int32Array(8);
            this.temp = new Int32Array(64);
            this.buffer = new Uint8Array(128);
            this.bufferLength = 0;
            this.bytesHashed = 0;
            this.finished = false;
            this.reset();
          }
          Hash2.prototype.reset = function() {
            this.state[0] = 1779033703;
            this.state[1] = 3144134277;
            this.state[2] = 1013904242;
            this.state[3] = 2773480762;
            this.state[4] = 1359893119;
            this.state[5] = 2600822924;
            this.state[6] = 528734635;
            this.state[7] = 1541459225;
            this.bufferLength = 0;
            this.bytesHashed = 0;
            this.finished = false;
            return this;
          };
          Hash2.prototype.clean = function() {
            for (var i = 0; i < this.buffer.length; i++) {
              this.buffer[i] = 0;
            }
            for (var i = 0; i < this.temp.length; i++) {
              this.temp[i] = 0;
            }
            this.reset();
          };
          Hash2.prototype.update = function(data, dataLength) {
            if (dataLength === void 0) {
              dataLength = data.length;
            }
            if (this.finished) {
              throw new Error("SHA256: can't update because hash was finished.");
            }
            var dataPos = 0;
            this.bytesHashed += dataLength;
            if (this.bufferLength > 0) {
              while (this.bufferLength < 64 && dataLength > 0) {
                this.buffer[this.bufferLength++] = data[dataPos++];
                dataLength--;
              }
              if (this.bufferLength === 64) {
                hashBlocks(this.temp, this.state, this.buffer, 0, 64);
                this.bufferLength = 0;
              }
            }
            if (dataLength >= 64) {
              dataPos = hashBlocks(this.temp, this.state, data, dataPos, dataLength);
              dataLength %= 64;
            }
            while (dataLength > 0) {
              this.buffer[this.bufferLength++] = data[dataPos++];
              dataLength--;
            }
            return this;
          };
          Hash2.prototype.finish = function(out) {
            if (!this.finished) {
              var bytesHashed = this.bytesHashed;
              var left = this.bufferLength;
              var bitLenHi = bytesHashed / 536870912 | 0;
              var bitLenLo = bytesHashed << 3;
              var padLength = bytesHashed % 64 < 56 ? 64 : 128;
              this.buffer[left] = 128;
              for (var i = left + 1; i < padLength - 8; i++) {
                this.buffer[i] = 0;
              }
              this.buffer[padLength - 8] = bitLenHi >>> 24 & 255;
              this.buffer[padLength - 7] = bitLenHi >>> 16 & 255;
              this.buffer[padLength - 6] = bitLenHi >>> 8 & 255;
              this.buffer[padLength - 5] = bitLenHi >>> 0 & 255;
              this.buffer[padLength - 4] = bitLenLo >>> 24 & 255;
              this.buffer[padLength - 3] = bitLenLo >>> 16 & 255;
              this.buffer[padLength - 2] = bitLenLo >>> 8 & 255;
              this.buffer[padLength - 1] = bitLenLo >>> 0 & 255;
              hashBlocks(this.temp, this.state, this.buffer, 0, padLength);
              this.finished = true;
            }
            for (var i = 0; i < 8; i++) {
              out[i * 4 + 0] = this.state[i] >>> 24 & 255;
              out[i * 4 + 1] = this.state[i] >>> 16 & 255;
              out[i * 4 + 2] = this.state[i] >>> 8 & 255;
              out[i * 4 + 3] = this.state[i] >>> 0 & 255;
            }
            return this;
          };
          Hash2.prototype.digest = function() {
            var out = new Uint8Array(this.digestLength);
            this.finish(out);
            return out;
          };
          Hash2.prototype._saveState = function(out) {
            for (var i = 0; i < this.state.length; i++) {
              out[i] = this.state[i];
            }
          };
          Hash2.prototype._restoreState = function(from, bytesHashed) {
            for (var i = 0; i < this.state.length; i++) {
              this.state[i] = from[i];
            }
            this.bytesHashed = bytesHashed;
            this.finished = false;
            this.bufferLength = 0;
          };
          return Hash2;
        })()
      );
      exports3.Hash = Hash;
      var HMAC = (
        /** @class */
        (function() {
          function HMAC2(key) {
            this.inner = new Hash();
            this.outer = new Hash();
            this.blockSize = this.inner.blockSize;
            this.digestLength = this.inner.digestLength;
            var pad = new Uint8Array(this.blockSize);
            if (key.length > this.blockSize) {
              new Hash().update(key).finish(pad).clean();
            } else {
              for (var i = 0; i < key.length; i++) {
                pad[i] = key[i];
              }
            }
            for (var i = 0; i < pad.length; i++) {
              pad[i] ^= 54;
            }
            this.inner.update(pad);
            for (var i = 0; i < pad.length; i++) {
              pad[i] ^= 54 ^ 92;
            }
            this.outer.update(pad);
            this.istate = new Uint32Array(8);
            this.ostate = new Uint32Array(8);
            this.inner._saveState(this.istate);
            this.outer._saveState(this.ostate);
            for (var i = 0; i < pad.length; i++) {
              pad[i] = 0;
            }
          }
          HMAC2.prototype.reset = function() {
            this.inner._restoreState(this.istate, this.inner.blockSize);
            this.outer._restoreState(this.ostate, this.outer.blockSize);
            return this;
          };
          HMAC2.prototype.clean = function() {
            for (var i = 0; i < this.istate.length; i++) {
              this.ostate[i] = this.istate[i] = 0;
            }
            this.inner.clean();
            this.outer.clean();
          };
          HMAC2.prototype.update = function(data) {
            this.inner.update(data);
            return this;
          };
          HMAC2.prototype.finish = function(out) {
            if (this.outer.finished) {
              this.outer.finish(out);
            } else {
              this.inner.finish(out);
              this.outer.update(out, this.digestLength).finish(out);
            }
            return this;
          };
          HMAC2.prototype.digest = function() {
            var out = new Uint8Array(this.digestLength);
            this.finish(out);
            return out;
          };
          return HMAC2;
        })()
      );
      exports3.HMAC = HMAC;
      function hash(data) {
        var h = new Hash().update(data);
        var digest = h.digest();
        h.clean();
        return digest;
      }
      exports3.hash = hash;
      exports3["default"] = hash;
      function hmac(key, data) {
        var h = new HMAC(key).update(data);
        var digest = h.digest();
        h.clean();
        return digest;
      }
      exports3.hmac = hmac;
      function fillBuffer(buffer, hmac2, info, counter) {
        var num = counter[0];
        if (num === 0) {
          throw new Error("hkdf: cannot expand more");
        }
        hmac2.reset();
        if (num > 1) {
          hmac2.update(buffer);
        }
        if (info) {
          hmac2.update(info);
        }
        hmac2.update(counter);
        hmac2.finish(buffer);
        counter[0]++;
      }
      var hkdfSalt = new Uint8Array(exports3.digestLength);
      function hkdf(key, salt, info, length) {
        if (salt === void 0) {
          salt = hkdfSalt;
        }
        if (length === void 0) {
          length = 32;
        }
        var counter = new Uint8Array([1]);
        var okm = hmac(salt, key);
        var hmac_ = new HMAC(okm);
        var buffer = new Uint8Array(hmac_.digestLength);
        var bufpos = buffer.length;
        var out = new Uint8Array(length);
        for (var i = 0; i < length; i++) {
          if (bufpos === buffer.length) {
            fillBuffer(buffer, hmac_, info, counter);
            bufpos = 0;
          }
          out[i] = buffer[bufpos++];
        }
        hmac_.clean();
        buffer.fill(0);
        counter.fill(0);
        return out;
      }
      exports3.hkdf = hkdf;
      function pbkdf2(password, salt, iterations, dkLen) {
        var prf = new HMAC(password);
        var len = prf.digestLength;
        var ctr = new Uint8Array(4);
        var t = new Uint8Array(len);
        var u = new Uint8Array(len);
        var dk = new Uint8Array(dkLen);
        for (var i = 0; i * len < dkLen; i++) {
          var c = i + 1;
          ctr[0] = c >>> 24 & 255;
          ctr[1] = c >>> 16 & 255;
          ctr[2] = c >>> 8 & 255;
          ctr[3] = c >>> 0 & 255;
          prf.reset();
          prf.update(salt);
          prf.update(ctr);
          prf.finish(u);
          for (var j = 0; j < len; j++) {
            t[j] = u[j];
          }
          for (var j = 2; j <= iterations; j++) {
            prf.reset();
            prf.update(u).finish(u);
            for (var k = 0; k < len; k++) {
              t[k] ^= u[k];
            }
          }
          for (var j = 0; j < len && i * len + j < dkLen; j++) {
            dk[i * len + j] = t[j];
          }
        }
        for (var i = 0; i < len; i++) {
          t[i] = u[i] = 0;
        }
        for (var i = 0; i < 4; i++) {
          ctr[i] = 0;
        }
        prf.clean();
        return dk;
      }
      exports3.pbkdf2 = pbkdf2;
    });
  }
});

// node_modules/standardwebhooks/dist/timing_safe_equal.js
var require_timing_safe_equal = __commonJS({
  "node_modules/standardwebhooks/dist/timing_safe_equal.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.timingSafeEqual = timingSafeEqual;
    function assert(expr, msg = "") {
      if (!expr) {
        throw new Error(msg);
      }
    }
    function timingSafeEqual(a, b) {
      if (a.byteLength !== b.byteLength) {
        return false;
      }
      if (!(a instanceof DataView)) {
        a = new DataView(ArrayBuffer.isView(a) ? a.buffer : a);
      }
      if (!(b instanceof DataView)) {
        b = new DataView(ArrayBuffer.isView(b) ? b.buffer : b);
      }
      assert(a instanceof DataView);
      assert(b instanceof DataView);
      const length = a.byteLength;
      let out = 0;
      let i = -1;
      while (++i < length) {
        out |= a.getUint8(i) ^ b.getUint8(i);
      }
      return out === 0;
    }
  }
});

// node_modules/standardwebhooks/dist/index.js
var require_dist = __commonJS({
  "node_modules/standardwebhooks/dist/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Webhook = exports2.WebhookVerificationError = void 0;
    var base64 = require_base642();
    var sha256 = require_sha256();
    var timing_safe_equal_1 = require_timing_safe_equal();
    var WEBHOOK_TOLERANCE_IN_SECONDS = 5 * 60;
    var ExtendableError = class _ExtendableError extends Error {
      constructor(message) {
        super(message);
        Object.setPrototypeOf(this, _ExtendableError.prototype);
        this.name = "ExtendableError";
        this.stack = new Error(message).stack;
      }
    };
    var WebhookVerificationError = class _WebhookVerificationError extends ExtendableError {
      constructor(message) {
        super(message);
        Object.setPrototypeOf(this, _WebhookVerificationError.prototype);
        this.name = "WebhookVerificationError";
      }
    };
    exports2.WebhookVerificationError = WebhookVerificationError;
    var Webhook = class _Webhook {
      constructor(secret, options) {
        if ((options === null || options === void 0 ? void 0 : options.format) === "raw") {
          if (secret instanceof Uint8Array) {
            this.key = secret;
          } else {
            this.key = Uint8Array.from(secret, (c) => c.charCodeAt(0));
          }
        } else {
          if (typeof secret !== "string") {
            throw new Error("Expected secret to be of type string");
          }
          if (secret.startsWith(_Webhook.prefix)) {
            secret = secret.substring(_Webhook.prefix.length);
          }
          this.key = base64.decode(secret);
        }
        if (this.key.length === 0) {
          throw new Error("Secret can't be empty.");
        }
      }
      verify(payload, headers, options) {
        var _a;
        const jsonParse = (_a = options === null || options === void 0 ? void 0 : options.jsonParse) !== null && _a !== void 0 ? _a : true;
        const normalizedHeaders = {};
        for (const key of Object.keys(headers)) {
          normalizedHeaders[key.toLowerCase()] = headers[key];
        }
        const msgId = normalizedHeaders["webhook-id"];
        const msgSignature = normalizedHeaders["webhook-signature"];
        const msgTimestamp = normalizedHeaders["webhook-timestamp"];
        if (!msgSignature || !msgId || !msgTimestamp) {
          throw new WebhookVerificationError("Missing required headers");
        }
        const timestamp = this.verifyTimestamp(msgTimestamp);
        const computedSignature = this.sign(msgId, timestamp, payload);
        const expectedSignature = computedSignature.split(",")[1];
        const passedSignatures = msgSignature.split(" ");
        const encoder = new globalThis.TextEncoder();
        for (const versionedSignature of passedSignatures) {
          const [version, signature] = versionedSignature.split(",");
          if (version !== "v1") {
            continue;
          }
          if ((0, timing_safe_equal_1.timingSafeEqual)(encoder.encode(signature), encoder.encode(expectedSignature))) {
            const payloadString = payload.toString();
            if (payloadString === "") {
              return void 0;
            }
            if (jsonParse) {
              return JSON.parse(payloadString);
            } else {
              return void 0;
            }
          }
        }
        throw new WebhookVerificationError("No matching signature found");
      }
      sign(msgId, timestamp, payload) {
        if (typeof payload === "string") {
        } else if (payload.constructor.name === "Buffer") {
          payload = payload.toString();
        } else {
          throw new Error("Expected payload to be of type string or Buffer.");
        }
        const encoder = new TextEncoder();
        const timestampNumber = Math.floor(timestamp.getTime() / 1e3);
        const toSign = encoder.encode(`${msgId}.${timestampNumber}.${payload}`);
        const expectedSignature = base64.encode(sha256.hmac(this.key, toSign));
        return `v1,${expectedSignature}`;
      }
      verifyTimestamp(timestampHeader) {
        const now = Math.floor(Date.now() / 1e3);
        const timestamp = parseInt(timestampHeader, 10);
        if (Number.isNaN(timestamp)) {
          throw new WebhookVerificationError("Invalid Signature Headers");
        }
        if (now - timestamp > WEBHOOK_TOLERANCE_IN_SECONDS) {
          throw new WebhookVerificationError("Message timestamp too old");
        }
        if (timestamp > now + WEBHOOK_TOLERANCE_IN_SECONDS) {
          throw new WebhookVerificationError("Message timestamp too new");
        }
        return new Date(timestamp * 1e3);
      }
    };
    exports2.Webhook = Webhook;
    Webhook.prefix = "whsec_";
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/webhooks.js
var require_webhooks = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/webhooks.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Webhooks = void 0;
    var resource_1 = require_resource();
    var standardwebhooks_1 = require_dist();
    var Webhooks = class extends resource_1.APIResource {
      /**
       * Parses a webhook payload into an event without verifying its signature. Prefer
       * `unwrap()` unless you have already verified the signature yourself.
       */
      parseUnverified(body) {
        return JSON.parse(body);
      }
      /**
       * Verifies the webhook signature from the `webhook-id`, `webhook-timestamp` and
       * `webhook-signature` headers using your webhook signing key, then parses the
       * payload into an event. Fails if the signature is missing or invalid.
       */
      unwrap(body, options) {
        const headers = options?.headers;
        if (headers == null)
          throw new Error("Webhook headers are required in order to verify the signature");
        const keyStr = options.key === void 0 ? this._client.webhookKey : options.key;
        if (!keyStr)
          throw new Error("Webhook key must not be null or empty in order to unwrap");
        const wh = new standardwebhooks_1.Webhook(keyStr);
        wh.verify(body, headers);
        return JSON.parse(body);
      }
    };
    exports2.Webhooks = Webhooks;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/agents/versions.js
var require_versions = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/agents/versions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Versions = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Versions = class extends resource_1.APIResource {
      /**
       * List Agent Versions
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsAgent of client.beta.agents.versions.list(
       *   'agent_011CZkYpogX7uDKUyvBTophP',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(agentID, params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/agents/${agentID}/versions?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.Versions = Versions;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/agents/agents.js
var require_agents = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/agents/agents.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Agents = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var VersionsAPI = tslib_1.__importStar(require_versions());
    var versions_1 = require_versions();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Agents = /* @__PURE__ */ (() => {
      class Agents2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.versions = new VersionsAPI.Versions(this._client);
        }
        /**
         * Create Agent
         *
         * @example
         * ```ts
         * const betaManagedAgentsAgent =
         *   await client.beta.agents.create({
         *     model: 'claude-opus-5',
         *     name: 'My First Agent',
         *   });
         * ```
         */
        create(params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post("/v1/agents?beta=true", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Get Agent
         *
         * @example
         * ```ts
         * const betaManagedAgentsAgent =
         *   await client.beta.agents.retrieve(
         *     'agent_011CZkYpogX7uDKUyvBTophP',
         *   );
         * ```
         */
        retrieve(agentID, params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/agents/${agentID}?beta=true`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Update Agent
         *
         * @example
         * ```ts
         * const betaManagedAgentsAgent =
         *   await client.beta.agents.update(
         *     'agent_011CZkYpogX7uDKUyvBTophP',
         *     { description: 'updated' },
         *   );
         * ```
         */
        update(agentID, params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/agents/${agentID}?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * List Agents
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaManagedAgentsAgent of client.beta.agents.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.getAPIList("/v1/agents?beta=true", pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Archive Agent
         *
         * @example
         * ```ts
         * const betaManagedAgentsAgent =
         *   await client.beta.agents.archive(
         *     'agent_011CZkYpogX7uDKUyvBTophP',
         *   );
         * ```
         */
        archive(agentID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.post((0, path_1.path)`/v1/agents/${agentID}/archive?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
      }
      Agents2.Versions = versions_1.Versions;
      return Agents2;
    })();
    exports2.Agents = Agents;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/abort.js
var require_abort = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/abort.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.linkAbort = linkAbort;
    function linkAbort(external, controller) {
      if (!external)
        return () => {
        };
      if (external.aborted) {
        controller.abort();
        return () => {
        };
      }
      const onAbort = () => controller.abort();
      external.addEventListener("abort", onAbort);
      return () => external.removeEventListener("abort", onAbort);
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/backoff.js
var require_backoff = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/backoff.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isStatus = isStatus;
    exports2.is4xx = is4xx;
    exports2.isFatal4xx = isFatal4xx;
    exports2.backoff = backoff;
    exports2.jitter = jitter;
    exports2.applyJitter = applyJitter;
    var error_1 = require_error();
    function isStatus(e, code) {
      return e instanceof error_1.APIError && e.status === code;
    }
    function is4xx(e) {
      return e instanceof error_1.APIError && typeof e.status === "number" && e.status >= 400 && e.status < 500;
    }
    function isFatal4xx(e) {
      return is4xx(e) && !isStatus(e, 408) && !isStatus(e, 409) && !isStatus(e, 429);
    }
    function backoff(attempt, baseMs, capMs) {
      return Math.min(baseMs * 2 ** attempt, capMs);
    }
    function jitter(lowMs, highMs) {
      return lowMs + Math.random() * (highMs - lowMs);
    }
    function applyJitter(ms) {
      return ms * (1 - Math.random() * 0.25);
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/helper-client.js
var require_helper_client = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/helper-client.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.copyClientForHelper = copyClientForHelper;
    var error_1 = require_error();
    var headers_1 = require_headers();
    var stainless_helper_header_1 = require_stainless_helper_header();
    function copyClientForHelper(client, { authToken, helper }) {
      if (!authToken) {
        throw new error_1.AnthropicError(`copyClientForHelper: expected a non-empty authToken but received ${JSON.stringify(authToken)}`);
      }
      const internal = client;
      const parentDefaults = internal._options.defaultHeaders;
      const parentAuthExtraHeaders = internal._authState?.extraHeaders;
      const inheritedAuthExtraHeaders = parentAuthExtraHeaders ? Object.fromEntries(Object.entries(parentAuthExtraHeaders).filter(([name]) => {
        const lower = name.toLowerCase();
        return lower !== "authorization" && lower !== "x-api-key";
      })) : void 0;
      const defaultHeaders = (0, headers_1.buildHeaders)([
        inheritedAuthExtraHeaders,
        parentDefaults,
        { [stainless_helper_header_1.STAINLESS_HELPER_HEADER]: helper }
      ]);
      return client.withOptions({
        apiKey: null,
        authToken,
        baseURL: client.baseURL,
        credentials: void 0,
        defaultHeaders
      });
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/environments/poller.js
var require_poller = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/environments/poller.js"(exports2) {
    "use strict";
    var _WorkPoller_runnerClient;
    var _WorkPoller_consumed;
    var _WorkPoller_controller;
    var _WorkPoller_detachExternal;
    var _WorkPoller_autoStop;
    var _WorkPoller_drain;
    var _WorkPoller_blockMs;
    var _WorkPoller_reclaimOlderThanMs;
    var _WorkPoller_requestOpts;
    var _IdleLog_log;
    var _IdleLog_environmentId;
    var _IdleLog_idleSince;
    var _IdleLog_lastReport;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.WorkPoller = exports2.POLL_BLOCK_MS = exports2.jitter = exports2.isStatus = exports2.isFatal4xx = exports2.is4xx = void 0;
    exports2.backoff = backoff;
    var tslib_1 = require_tslib();
    var error_1 = require_error();
    var log_1 = require_log();
    var sleep_1 = require_sleep();
    var uuid_1 = require_uuid();
    var abort_1 = require_abort();
    var headers_1 = require_headers();
    var backoff_1 = require_backoff();
    var helper_client_1 = require_helper_client();
    var backoff_2 = require_backoff();
    Object.defineProperty(exports2, "is4xx", { enumerable: true, get: function() {
      return backoff_2.is4xx;
    } });
    Object.defineProperty(exports2, "isFatal4xx", { enumerable: true, get: function() {
      return backoff_2.isFatal4xx;
    } });
    Object.defineProperty(exports2, "isStatus", { enumerable: true, get: function() {
      return backoff_2.isStatus;
    } });
    Object.defineProperty(exports2, "jitter", { enumerable: true, get: function() {
      return backoff_2.jitter;
    } });
    exports2.POLL_BLOCK_MS = 999;
    var POLL_BACKOFF_BASE_MS = 1e3;
    var POLL_BACKOFF_CAP_MS = 6e4;
    var IDLE_REPORT_INTERVAL_MS = 3e5;
    var WorkPoller = /* @__PURE__ */ (() => {
      class WorkPoller2 {
        constructor(opts) {
          _WorkPoller_runnerClient.set(this, void 0);
          _WorkPoller_consumed.set(this, false);
          _WorkPoller_controller.set(this, void 0);
          _WorkPoller_detachExternal.set(this, void 0);
          _WorkPoller_autoStop.set(this, void 0);
          _WorkPoller_drain.set(this, void 0);
          _WorkPoller_blockMs.set(this, void 0);
          _WorkPoller_reclaimOlderThanMs.set(this, void 0);
          _WorkPoller_requestOpts.set(this, void 0);
          this.client = opts.client;
          this.environmentId = opts.environmentId;
          this.environmentKey = opts.environmentKey;
          this.workerId = opts.workerId ?? defaultWorkerId();
          tslib_1.__classPrivateFieldSet(this, _WorkPoller_runnerClient, (0, helper_client_1.copyClientForHelper)(opts.client, {
            authToken: opts.environmentKey,
            helper: "environments-work-poller"
          }), "f");
          tslib_1.__classPrivateFieldSet(this, _WorkPoller_autoStop, opts.autoStop ?? true, "f");
          tslib_1.__classPrivateFieldSet(this, _WorkPoller_drain, opts.drain ?? false, "f");
          tslib_1.__classPrivateFieldSet(this, _WorkPoller_blockMs, opts.blockMs === void 0 ? exports2.POLL_BLOCK_MS : opts.blockMs, "f");
          tslib_1.__classPrivateFieldSet(this, _WorkPoller_reclaimOlderThanMs, opts.reclaimOlderThanMs ?? null, "f");
          tslib_1.__classPrivateFieldSet(this, _WorkPoller_requestOpts, opts.requestOptions, "f");
          tslib_1.__classPrivateFieldSet(this, _WorkPoller_controller, new AbortController(), "f");
          tslib_1.__classPrivateFieldSet(this, _WorkPoller_detachExternal, (0, abort_1.linkAbort)(opts.signal, tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f")), "f");
        }
        /** Read-only view of this iterator's abort signal. */
        get signal() {
          return tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal;
        }
        /** Abort the iterator. The current `for await` will exit cleanly. */
        abort() {
          tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").abort();
        }
        async *[(_WorkPoller_runnerClient = /* @__PURE__ */ new WeakMap(), _WorkPoller_consumed = /* @__PURE__ */ new WeakMap(), _WorkPoller_controller = /* @__PURE__ */ new WeakMap(), _WorkPoller_detachExternal = /* @__PURE__ */ new WeakMap(), _WorkPoller_autoStop = /* @__PURE__ */ new WeakMap(), _WorkPoller_drain = /* @__PURE__ */ new WeakMap(), _WorkPoller_blockMs = /* @__PURE__ */ new WeakMap(), _WorkPoller_reclaimOlderThanMs = /* @__PURE__ */ new WeakMap(), _WorkPoller_requestOpts = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
          if (tslib_1.__classPrivateFieldGet(this, _WorkPoller_consumed, "f")) {
            throw new error_1.AnthropicError("Cannot iterate over a consumed WorkPoller");
          }
          tslib_1.__classPrivateFieldSet(this, _WorkPoller_consumed, true, "f");
          const log = (0, log_1.loggerFor)(this.client);
          log.info("poller starting", {
            component: "work-poller",
            environment_id: this.environmentId
          });
          const idle = new IdleLog(log, this.environmentId);
          try {
            let attempt = 0;
            while (!tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal.aborted) {
              let work;
              try {
                work = await tslib_1.__classPrivateFieldGet(this, _WorkPoller_runnerClient, "f").beta.environments.work.poll(this.environmentId, {
                  "Anthropic-Worker-ID": this.workerId,
                  ...tslib_1.__classPrivateFieldGet(this, _WorkPoller_blockMs, "f") !== null ? { block_ms: tslib_1.__classPrivateFieldGet(this, _WorkPoller_blockMs, "f") } : {},
                  ...tslib_1.__classPrivateFieldGet(this, _WorkPoller_reclaimOlderThanMs, "f") !== null ? { reclaim_older_than_ms: tslib_1.__classPrivateFieldGet(this, _WorkPoller_reclaimOlderThanMs, "f") } : {}
                }, { headers: (0, headers_1.buildHeaders)([tslib_1.__classPrivateFieldGet(this, _WorkPoller_requestOpts, "f")?.headers]), signal: tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal });
              } catch (e) {
                if (tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal.aborted)
                  return;
                if ((0, backoff_1.isFatal4xx)(e)) {
                  log.error("poll failed permanently, stopping poller", { error: String(e) });
                  throw e;
                }
                const wait = (0, backoff_1.applyJitter)(backoff(attempt));
                log.warn("poll failed, backing off", { error: String(e), backoff_ms: wait });
                attempt++;
                await (0, sleep_1.sleep)(wait, tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal);
                continue;
              }
              attempt = 0;
              if (work == null) {
                if (tslib_1.__classPrivateFieldGet(this, _WorkPoller_drain, "f"))
                  return;
                idle.onEmptyPoll();
                await (0, sleep_1.sleep)((0, backoff_1.jitter)(1e3, 3e3), tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal);
                continue;
              }
              idle.onClaim();
              log.info("claimed work", {
                component: "work-poller",
                environment_id: this.environmentId,
                work_id: work.id,
                work_type: work.data.type
              });
              try {
                await tslib_1.__classPrivateFieldGet(this, _WorkPoller_runnerClient, "f").beta.environments.work.ack(work.id, { environment_id: work.environment_id }, { headers: (0, headers_1.buildHeaders)([tslib_1.__classPrivateFieldGet(this, _WorkPoller_requestOpts, "f")?.headers]), signal: tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal });
              } catch (e) {
                log.error("ack failed", { work_id: work.id, error: String(e) });
                continue;
              }
              try {
                yield work;
              } finally {
                if (tslib_1.__classPrivateFieldGet(this, _WorkPoller_autoStop, "f")) {
                  try {
                    await tslib_1.__classPrivateFieldGet(this, _WorkPoller_runnerClient, "f").beta.environments.work.stop(work.id, { environment_id: work.environment_id }, { headers: (0, headers_1.buildHeaders)([tslib_1.__classPrivateFieldGet(this, _WorkPoller_requestOpts, "f")?.headers]) });
                  } catch (e) {
                    if (!(0, backoff_1.isStatus)(e, 409))
                      log.warn("stop failed", { work_id: work.id, error: String(e) });
                  }
                }
              }
            }
          } finally {
            tslib_1.__classPrivateFieldGet(this, _WorkPoller_detachExternal, "f").call(this);
          }
        }
      }
      return WorkPoller2;
    })();
    exports2.WorkPoller = WorkPoller;
    function backoff(attempt) {
      return (0, backoff_1.backoff)(attempt, POLL_BACKOFF_BASE_MS, POLL_BACKOFF_CAP_MS);
    }
    var IdleLog = /* @__PURE__ */ (() => {
      class IdleLog2 {
        constructor(log, environmentId) {
          _IdleLog_log.set(this, void 0);
          _IdleLog_environmentId.set(this, void 0);
          _IdleLog_idleSince.set(this, void 0);
          _IdleLog_lastReport.set(this, 0);
          tslib_1.__classPrivateFieldSet(this, _IdleLog_log, log, "f");
          tslib_1.__classPrivateFieldSet(this, _IdleLog_environmentId, environmentId, "f");
        }
        onEmptyPoll() {
          const now = Date.now();
          const fields = { component: "work-poller", environment_id: tslib_1.__classPrivateFieldGet(this, _IdleLog_environmentId, "f") };
          if (tslib_1.__classPrivateFieldGet(this, _IdleLog_idleSince, "f") === void 0) {
            tslib_1.__classPrivateFieldSet(this, _IdleLog_idleSince, tslib_1.__classPrivateFieldSet(this, _IdleLog_lastReport, now, "f"), "f");
            tslib_1.__classPrivateFieldGet(this, _IdleLog_log, "f").info("idle; polling for work", fields);
          } else if (now - tslib_1.__classPrivateFieldGet(this, _IdleLog_lastReport, "f") >= IDLE_REPORT_INTERVAL_MS) {
            tslib_1.__classPrivateFieldSet(this, _IdleLog_lastReport, now, "f");
            tslib_1.__classPrivateFieldGet(this, _IdleLog_log, "f").info(`still polling; idle for ${Math.round((now - tslib_1.__classPrivateFieldGet(this, _IdleLog_idleSince, "f")) / 1e3)}s`, fields);
          } else {
            tslib_1.__classPrivateFieldGet(this, _IdleLog_log, "f").debug("poll returned no work", fields);
          }
        }
        onClaim() {
          tslib_1.__classPrivateFieldSet(this, _IdleLog_idleSince, void 0, "f");
        }
      }
      _IdleLog_log = /* @__PURE__ */ new WeakMap(), _IdleLog_environmentId = /* @__PURE__ */ new WeakMap(), _IdleLog_idleSince = /* @__PURE__ */ new WeakMap(), _IdleLog_lastReport = /* @__PURE__ */ new WeakMap();
      return IdleLog2;
    })();
    function defaultWorkerId() {
      const env = globalThis.process?.env;
      const host = env?.["HOSTNAME"];
      return host ? `${host}-${(0, uuid_1.uuid4)()}` : (0, uuid_1.uuid4)();
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/async-queue.js
var require_async_queue = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/async-queue.js"(exports2) {
    "use strict";
    var _AsyncQueue_items;
    var _AsyncQueue_waiters;
    var _AsyncQueue_closed;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AsyncQueue = void 0;
    var tslib_1 = require_tslib();
    var AsyncQueue = /* @__PURE__ */ (() => {
      class AsyncQueue2 {
        constructor() {
          _AsyncQueue_items.set(this, []);
          _AsyncQueue_waiters.set(this, []);
          _AsyncQueue_closed.set(this, false);
        }
        /** Enqueue an item, or hand it directly to a waiting reader. Returns `false` once closed. */
        push(item) {
          if (tslib_1.__classPrivateFieldGet(this, _AsyncQueue_closed, "f"))
            return false;
          const w = tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").shift();
          if (w)
            w({ done: false, value: item });
          else
            tslib_1.__classPrivateFieldGet(this, _AsyncQueue_items, "f").push(item);
          return true;
        }
        /** Mark the queue done. Idempotent; wakes every pending reader with `done: true`. */
        close() {
          if (tslib_1.__classPrivateFieldGet(this, _AsyncQueue_closed, "f"))
            return;
          tslib_1.__classPrivateFieldSet(this, _AsyncQueue_closed, true, "f");
          while (tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").length > 0) {
            const w = tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").shift();
            w({ done: true, value: void 0 });
          }
        }
        /**
         * Resolve with the next item, or `done: true` once the queue is closed and
         * drained. When `signal` is supplied, aborting it resolves a pending read
         * with `done: true` (cancellation is pushed down here rather than handled by
         * an outer `Promise.race`).
         */
        next(signal) {
          if (tslib_1.__classPrivateFieldGet(this, _AsyncQueue_items, "f").length > 0) {
            return Promise.resolve({ done: false, value: tslib_1.__classPrivateFieldGet(this, _AsyncQueue_items, "f").shift() });
          }
          if (tslib_1.__classPrivateFieldGet(this, _AsyncQueue_closed, "f") || signal?.aborted) {
            return Promise.resolve({ done: true, value: void 0 });
          }
          return new Promise((resolve) => {
            const waiter = (r) => {
              signal?.removeEventListener("abort", onAbort);
              resolve(r);
            };
            const onAbort = () => {
              const idx = tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").indexOf(waiter);
              if (idx >= 0)
                tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").splice(idx, 1);
              resolve({ done: true, value: void 0 });
            };
            tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").push(waiter);
            signal?.addEventListener("abort", onAbort, { once: true });
          });
        }
        /** Synchronously remove and return the next buffered item, or `undefined` if empty. */
        tryShift() {
          return tslib_1.__classPrivateFieldGet(this, _AsyncQueue_items, "f").shift();
        }
      }
      _AsyncQueue_items = /* @__PURE__ */ new WeakMap(), _AsyncQueue_waiters = /* @__PURE__ */ new WeakMap(), _AsyncQueue_closed = /* @__PURE__ */ new WeakMap();
      return AsyncQueue2;
    })();
    exports2.AsyncQueue = AsyncQueue;
  }
});

// node_modules/@anthropic-ai/sdk/lib/tools/ToolError.js
var require_ToolError = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/tools/ToolError.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ToolError = void 0;
    var ToolError = /* @__PURE__ */ (() => {
      class ToolError2 extends Error {
        constructor(content) {
          const message = typeof content === "string" ? content : content.map((block) => {
            if (block.type === "text")
              return block.text;
            return `[${block.type}]`;
          }).join(" ");
          super(message);
          this.name = "ToolError";
          this.content = content;
        }
      }
      return ToolError2;
    })();
    exports2.ToolError = ToolError;
  }
});

// node_modules/@anthropic-ai/sdk/lib/tools/BetaRunnableTool.js
var require_BetaRunnableTool = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/tools/BetaRunnableTool.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.toolName = toolName;
    exports2.toolErrorContent = toolErrorContent;
    exports2.runRunnableTool = runRunnableTool;
    var ToolError_1 = require_ToolError();
    function toolName(tool) {
      return "name" in tool ? tool.name : "mcp_server_name" in tool ? tool.mcp_server_name : tool.type;
    }
    function toolErrorContent(e) {
      return e instanceof ToolError_1.ToolError ? e.content : `Error: ${e instanceof Error ? e.message : String(e)}`;
    }
    async function runRunnableTool(tool, rawInput, context) {
      try {
        const input = tool.parse ? tool.parse(rawInput) : rawInput;
        const content = await tool.run(input, context);
        return { content, isError: false };
      } catch (e) {
        return { content: toolErrorContent(e), isError: true };
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/tools/SessionToolRunner.js
var require_SessionToolRunner = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/tools/SessionToolRunner.js"(exports2) {
    "use strict";
    var _IdleClock_maxIdleMs;
    var _IdleClock_onExpire;
    var _IdleClock_blockers;
    var _IdleClock_armPending;
    var _IdleClock_timer;
    var _SessionToolRunner_instances;
    var _SessionToolRunner_consumed;
    var _SessionToolRunner_controller;
    var _SessionToolRunner_detachExternal;
    var _SessionToolRunner_requestOpts;
    var _SessionToolRunner_toolByName;
    var _SessionToolRunner_logger;
    var _SessionToolRunner_seen;
    var _SessionToolRunner_answered;
    var _SessionToolRunner_confirmationVerdicts;
    var _SessionToolRunner_awaitingConfirmation;
    var _SessionToolRunner_results;
    var _SessionToolRunner_inFlightCount;
    var _SessionToolRunner_sendRetryWindowMs;
    var _SessionToolRunner_onIdle;
    var _SessionToolRunner_idleClock;
    var _SessionToolRunner_requestOptions;
    var _SessionToolRunner_streamLoop;
    var _SessionToolRunner_reconcile;
    var _SessionToolRunner_ingestHistory;
    var _SessionToolRunner_handleStreamEvent;
    var _SessionToolRunner_routeToolEvent;
    var _SessionToolRunner_noteConfirmation;
    var _SessionToolRunner_applyVerdict;
    var _SessionToolRunner_surfaceCall;
    var _SessionToolRunner_execute;
    var _SessionToolRunner_sendResult;
    var _SessionToolRunner_drain;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SessionToolRunner = exports2.DEFAULT_MAX_IDLE_MS = exports2.MANAGED_AGENTS_BETA = void 0;
    var tslib_1 = require_tslib();
    var error_1 = require_error();
    var log_1 = require_log();
    var sleep_1 = require_sleep();
    var backoff_1 = require_backoff();
    var abort_1 = require_abort();
    var async_queue_1 = require_async_queue();
    var headers_1 = require_headers();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var BetaRunnableTool_1 = require_BetaRunnableTool();
    exports2.MANAGED_AGENTS_BETA = "managed-agents-2026-04-01";
    var STREAM_BACKOFF_START_MS = 500;
    var STREAM_BACKOFF_CAP_MS = 1e4;
    var TOOL_TIMEOUT_MS = 12e4;
    var DRAIN_TIMEOUT_MS = 3e4;
    var SEND_BACKOFF_START_MS = 1e3;
    var SEND_BACKOFF_CAP_MS = 3e4;
    var SEND_RETRY_WINDOW_MS = 5 * 6e4;
    exports2.DEFAULT_MAX_IDLE_MS = 6e4;
    function isEndTurnIdle(ev) {
      return ev.type === "session.status_idle" && ev.stop_reason?.type === "end_turn";
    }
    var IdleClock = /* @__PURE__ */ (() => {
      class IdleClock2 {
        constructor(maxIdleMs, onExpire) {
          _IdleClock_maxIdleMs.set(this, void 0);
          _IdleClock_onExpire.set(this, void 0);
          _IdleClock_blockers.set(this, /* @__PURE__ */ new Set());
          _IdleClock_armPending.set(this, false);
          _IdleClock_timer.set(this, void 0);
          tslib_1.__classPrivateFieldSet(this, _IdleClock_maxIdleMs, maxIdleMs, "f");
          tslib_1.__classPrivateFieldSet(this, _IdleClock_onExpire, onExpire, "f");
        }
        /**
         * Arm on `status_idle{end_turn}`; disarm otherwise. `user.tool_confirmation`
         * is neutral: it signals neither agent activity nor an idle, and its effect
         * on the clock flows through {@link block} / {@link unblock} instead —
         * disarming here would discard the pending arm the verdict is about to
         * settle.
         */
        noteEvent(ev) {
          if (ev.type === "user.tool_confirmation")
            return;
          if (isEndTurnIdle(ev))
            this.arm();
          else
            this.disarm();
        }
        /** Register gated work that must resolve before an idle countdown starts. */
        block(toolUseId) {
          tslib_1.__classPrivateFieldGet(this, _IdleClock_blockers, "f").add(toolUseId);
          if (tslib_1.__classPrivateFieldGet(this, _IdleClock_timer, "f") !== void 0) {
            tslib_1.__classPrivateFieldSet(this, _IdleClock_armPending, true, "f");
            clearTimeout(tslib_1.__classPrivateFieldGet(this, _IdleClock_timer, "f"));
            tslib_1.__classPrivateFieldSet(this, _IdleClock_timer, void 0, "f");
          }
        }
        /**
         * Retire gated work (a no-op for ids never blocked); applies a pending arm —
         * with a fresh full `maxIdleMs` window — once the last blocker retires.
         */
        unblock(toolUseId) {
          tslib_1.__classPrivateFieldGet(this, _IdleClock_blockers, "f").delete(toolUseId);
          if (tslib_1.__classPrivateFieldGet(this, _IdleClock_blockers, "f").size === 0 && tslib_1.__classPrivateFieldGet(this, _IdleClock_armPending, "f"))
            this.arm();
        }
        /**
         * (Re)start the idle countdown — or, while blockers are outstanding, hold
         * the arm pending instead. Stopping then would drop a held call when its
         * verdict later arrives, or cut the runner off before a released call's
         * result can drive the next turn.
         */
        arm() {
          if (tslib_1.__classPrivateFieldGet(this, _IdleClock_maxIdleMs, "f") <= 0)
            return;
          if (tslib_1.__classPrivateFieldGet(this, _IdleClock_blockers, "f").size > 0) {
            tslib_1.__classPrivateFieldSet(this, _IdleClock_armPending, true, "f");
            return;
          }
          tslib_1.__classPrivateFieldSet(this, _IdleClock_armPending, false, "f");
          if (tslib_1.__classPrivateFieldGet(this, _IdleClock_timer, "f") !== void 0)
            clearTimeout(tslib_1.__classPrivateFieldGet(this, _IdleClock_timer, "f"));
          tslib_1.__classPrivateFieldSet(this, _IdleClock_timer, setTimeout(tslib_1.__classPrivateFieldGet(this, _IdleClock_onExpire, "f"), tslib_1.__classPrivateFieldGet(this, _IdleClock_maxIdleMs, "f")), "f");
        }
        /**
         * Cancel the idle countdown and any pending arm. Blockers persist — they
         * track real outstanding work, retired only by {@link unblock}.
         */
        disarm() {
          tslib_1.__classPrivateFieldSet(this, _IdleClock_armPending, false, "f");
          if (tslib_1.__classPrivateFieldGet(this, _IdleClock_timer, "f") !== void 0) {
            clearTimeout(tslib_1.__classPrivateFieldGet(this, _IdleClock_timer, "f"));
            tslib_1.__classPrivateFieldSet(this, _IdleClock_timer, void 0, "f");
          }
        }
      }
      _IdleClock_maxIdleMs = /* @__PURE__ */ new WeakMap(), _IdleClock_onExpire = /* @__PURE__ */ new WeakMap(), _IdleClock_blockers = /* @__PURE__ */ new WeakMap(), _IdleClock_armPending = /* @__PURE__ */ new WeakMap(), _IdleClock_timer = /* @__PURE__ */ new WeakMap();
      return IdleClock2;
    })();
    var SessionToolRunner = /* @__PURE__ */ (() => {
      class SessionToolRunner2 {
        constructor(sessionId, opts) {
          _SessionToolRunner_instances.add(this);
          _SessionToolRunner_consumed.set(this, false);
          _SessionToolRunner_controller.set(this, void 0);
          _SessionToolRunner_detachExternal.set(this, void 0);
          _SessionToolRunner_requestOpts.set(this, void 0);
          _SessionToolRunner_toolByName.set(this, void 0);
          _SessionToolRunner_logger.set(this, void 0);
          _SessionToolRunner_seen.set(this, /* @__PURE__ */ new Set());
          _SessionToolRunner_answered.set(this, /* @__PURE__ */ new Set());
          _SessionToolRunner_confirmationVerdicts.set(this, /* @__PURE__ */ new Map());
          _SessionToolRunner_awaitingConfirmation.set(this, /* @__PURE__ */ new Map());
          _SessionToolRunner_results.set(this, new async_queue_1.AsyncQueue());
          _SessionToolRunner_inFlightCount.set(this, 0);
          _SessionToolRunner_sendRetryWindowMs.set(this, SEND_RETRY_WINDOW_MS);
          _SessionToolRunner_onIdle.set(this, null);
          _SessionToolRunner_idleClock.set(this, void 0);
          this.client = opts.client;
          this.sessionId = sessionId;
          this.tools = opts.tools;
          this.maxIdleMs = opts.maxIdleMs ?? exports2.DEFAULT_MAX_IDLE_MS;
          tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_logger, (0, log_1.loggerFor)(opts.client), "f");
          tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_toolByName, new Map(opts.tools.map((t) => [(0, BetaRunnableTool_1.toolName)(t), t])), "f");
          tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_controller, new AbortController(), "f");
          tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_detachExternal, (0, abort_1.linkAbort)(opts.signal, tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f")), "f");
          tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_requestOpts, opts.requestOptions, "f");
          tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_idleClock, new IdleClock(this.maxIdleMs, () => {
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("session idle after end_turn; stopping", {
              component: "session-tool-runner",
              session_id: this.sessionId,
              max_idle_ms: this.maxIdleMs
            });
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
          }), "f");
        }
        /** Read-only view of this runner's abort signal. */
        get signal() {
          return tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal;
        }
        /** Abort the runner. Background tasks will wind down and `for await` will exit cleanly. */
        abort() {
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
        }
        /**
         * @internal
         * `EnvironmentWorker` keeps this equal to the lease TTL each heartbeat
         * reports; applies to a send already retrying.
         */
        _setSendRetryWindow(ms) {
          tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_sendRetryWindowMs, ms, "f");
        }
        async *[(_SessionToolRunner_consumed = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_controller = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_detachExternal = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_requestOpts = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_toolByName = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_logger = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_seen = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_answered = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_confirmationVerdicts = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_awaitingConfirmation = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_results = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_inFlightCount = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_sendRetryWindowMs = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_onIdle = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_idleClock = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_instances = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
          if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_consumed, "f")) {
            throw new error_1.AnthropicError("Cannot iterate over a consumed SessionToolRunner");
          }
          tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_consumed, true, "f");
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("session tool runner starting", {
            component: "session-tool-runner",
            session_id: this.sessionId
          });
          const streamPromise = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_streamLoop).call(this).catch((e) => {
            if (!tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal.aborted) {
              tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").error("stream loop failed", { error: String(e) });
            }
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
          });
          try {
            while (true) {
              const next = await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_results, "f").next(tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal);
              if (next.done)
                break;
              yield next.value;
            }
            await streamPromise;
            let pending;
            while ((pending = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_results, "f").tryShift()) !== void 0) {
              yield pending;
            }
          } finally {
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").disarm();
            await streamPromise;
            try {
              await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_drain).call(this);
            } catch (e) {
              tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("drain failed", { error: String(e) });
            }
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_results, "f").close();
            for (const t of this.tools) {
              try {
                await t.close?.();
              } catch (e) {
                tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("tool.close failed", { tool: (0, BetaRunnableTool_1.toolName)(t), error: String(e) });
              }
            }
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_detachExternal, "f").call(this);
          }
        }
      }
      return SessionToolRunner2;
    })();
    exports2.SessionToolRunner = SessionToolRunner;
    _SessionToolRunner_requestOptions = function _SessionToolRunner_requestOptions2() {
      return {
        ...tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_requestOpts, "f"),
        headers: (0, headers_1.buildHeaders)([(0, stainless_helper_header_1.helperHeader)("session-tool-runner"), tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_requestOpts, "f")?.headers]),
        signal: tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal
      };
    }, _SessionToolRunner_streamLoop = // ===== event stream =====
    async function _SessionToolRunner_streamLoop2() {
      const ctrl = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f");
      let backoff = STREAM_BACKOFF_START_MS;
      while (!ctrl.signal.aborted) {
        try {
          const stream = await this.client.beta.sessions.events.stream(this.sessionId, {}, tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_requestOptions).call(this));
          await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_reconcile).call(this);
          for await (const ev of stream) {
            backoff = STREAM_BACKOFF_START_MS;
            if (await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_handleStreamEvent).call(this, ev))
              return;
          }
        } catch (e) {
          ctrl.signal.throwIfAborted();
          if ((0, backoff_1.isFatal4xx)(e)) {
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").error("permanent stream failure, shutting down", { error: String(e) });
            ctrl.abort();
            throw e;
          }
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("stream disconnected, reconnecting", {
            error: String(e),
            backoff_ms: backoff
          });
        }
        ctrl.signal.throwIfAborted();
        await (0, sleep_1.sleep)(backoff, ctrl.signal);
        backoff = Math.min(backoff * 2, STREAM_BACKOFF_CAP_MS);
      }
    }, _SessionToolRunner_reconcile = /**
     * Read full history before dispatching so a `tool_use` whose result appears
     * later in the same history is not re-executed. Runs after the live stream is
     * already attached (see {@link SessionToolRunner.#streamLoop}).
     */
    async function _SessionToolRunner_reconcile2() {
      const ctrl = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f");
      const pending = [];
      let lastWasEndTurn = false;
      try {
        for await (const ev of this.client.beta.sessions.events.list(this.sessionId, { limit: 1e3 }, tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_requestOptions).call(this))) {
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_ingestHistory).call(this, ev, pending);
          lastWasEndTurn = isEndTurnIdle(ev);
        }
      } catch (e) {
        ctrl.signal.throwIfAborted();
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("reconcile list failed", { error: String(e) });
        for (const ev of pending)
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_seen, "f").delete(ev.id);
        return;
      }
      const unanswered = pending.filter((ev) => !tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id));
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").disarm();
      for (const ev of unanswered)
        await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_routeToolEvent).call(this, ev);
      for (const held of [...tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").values()]) {
        const verdict = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_confirmationVerdicts, "f").get(held.id);
        if (verdict !== void 0)
          await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_applyVerdict).call(this, held, verdict);
      }
      const outstanding = unanswered.filter((ev) => !tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id) && !tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").has(ev.id));
      if (lastWasEndTurn && outstanding.length === 0)
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").arm();
      else
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").disarm();
    }, _SessionToolRunner_ingestHistory = function _SessionToolRunner_ingestHistory2(ev, pending) {
      if (ev.type === "agent.tool_use" || ev.type === "agent.custom_tool_use") {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_seen, "f").add(ev.id);
        if (!tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id))
          pending.push(ev);
      } else if (ev.type === "user.tool_result") {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.tool_use_id);
      } else if (ev.type === "user.custom_tool_result") {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.custom_tool_use_id);
      } else if (ev.type === "user.tool_confirmation") {
        if (!tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.tool_use_id))
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_confirmationVerdicts, "f").set(ev.tool_use_id, ev.result);
      }
    }, _SessionToolRunner_handleStreamEvent = /** Returns true when the runner should exit. */
    async function _SessionToolRunner_handleStreamEvent2(ev) {
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").noteEvent(ev);
      switch (ev.type) {
        case "agent.tool_use":
        case "agent.custom_tool_use":
          if (!tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_seen, "f").has(ev.id)) {
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_seen, "f").add(ev.id);
            await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_routeToolEvent).call(this, ev);
          }
          return false;
        case "user.tool_confirmation":
          await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_noteConfirmation).call(this, ev);
          return false;
        case "user.tool_result":
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.tool_use_id);
          return false;
        case "user.custom_tool_result":
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.custom_tool_use_id);
          return false;
        case "session.status_terminated":
        case "session.deleted":
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("session terminated", {
            component: "session-tool-runner",
            session_id: this.sessionId
          });
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
          return true;
        default:
          return false;
      }
    }, _SessionToolRunner_routeToolEvent = // ===== confirmation gating (always_ask tools) =====
    /**
     * Dispatch `ev`, honoring its evaluated permission. A call the server gated
     * (`evaluated_permission == "ask"`) is held until its `user.tool_confirmation`
     * arrives. Fails closed: only an explicit `allow` verdict releases a gated
     * call; a server-side `deny` overrides any recorded verdict; an unrecognized
     * permission is held like `ask` and an unrecognized verdict is denied.
     */
    async function _SessionToolRunner_routeToolEvent2(ev) {
      const permission = ev.evaluated_permission;
      const verdict = permission === "deny" ? "deny" : tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_confirmationVerdicts, "f").get(ev.id);
      if (verdict === void 0) {
        if (permission === void 0 || permission === "allow") {
          await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_execute).call(this, ev, void 0);
        } else if (!tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").has(ev.id)) {
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("tool call awaiting confirmation; holding", {
            component: "session-tool-runner",
            session_id: this.sessionId,
            tool: ev.name,
            tool_use_id: ev.id
          });
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").set(ev.id, ev);
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").block(ev.id);
        }
        return;
      }
      await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_applyVerdict).call(this, ev, verdict);
    }, _SessionToolRunner_noteConfirmation = /** Record an allow/deny verdict and release the held call it gates, if any. */
    async function _SessionToolRunner_noteConfirmation2(ev) {
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_confirmationVerdicts, "f").set(ev.tool_use_id, ev.result);
      const held = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").get(ev.tool_use_id);
      if (held === void 0)
        return;
      await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_applyVerdict).call(this, held, ev.result);
    }, _SessionToolRunner_applyVerdict = /**
     * Dispatch or resolve a gated call according to its verdict.
     *
     * The idle-clock blocker accounting lives here: a denial retires the held
     * call's blocker, while an allow keeps one on the call — taking it now if the
     * verdict was already known when the call was routed, so it was never held —
     * until `#execute` has finished with it. The countdown must not run over
     * gated work that is still in flight.
     */
    async function _SessionToolRunner_applyVerdict2(ev, verdict) {
      const wasHeld = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_awaitingConfirmation, "f").delete(ev.id);
      if (verdict === "allow") {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("tool call confirmed", {
          component: "session-tool-runner",
          session_id: this.sessionId,
          tool: ev.name,
          tool_use_id: ev.id
        });
        if (!wasHeld)
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").block(ev.id);
        try {
          await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_execute).call(this, ev, "allow");
        } finally {
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").unblock(ev.id);
        }
        return;
      }
      if (wasHeld)
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleClock, "f").unblock(ev.id);
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.id);
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("tool call denied; not executing", {
        component: "session-tool-runner",
        session_id: this.sessionId,
        tool: ev.name,
        tool_use_id: ev.id
      });
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_surfaceCall).call(this, {
        event: ev,
        toolUseId: ev.id,
        name: ev.name,
        isError: false,
        posted: false,
        confirmation: "deny"
      });
    }, _SessionToolRunner_surfaceCall = function _SessionToolRunner_surfaceCall2(call) {
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_results, "f").push(call);
    }, _SessionToolRunner_execute = // ===== tool execution =====
    async function _SessionToolRunner_execute2(ev, confirmation) {
      var _a, _b;
      if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id))
        return;
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("executing tool", {
        component: "session-tool-runner",
        session_id: this.sessionId,
        tool: ev.name,
        tool_use_id: ev.id
      });
      tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_inFlightCount, (_a = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f"), _a++, _a), "f");
      try {
        const tool = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_toolByName, "f").get(ev.name);
        if (!tool) {
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("tool not owned by this runner; leaving the tool_use_id pending for its owner", {
            component: "session-tool-runner",
            session_id: this.sessionId,
            tool: ev.name,
            tool_use_id: ev.id
          });
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_surfaceCall).call(this, {
            event: ev,
            toolUseId: ev.id,
            name: ev.name,
            isError: false,
            posted: false,
            confirmation
          });
          return;
        }
        let content;
        let isError;
        const toolCtrl = new AbortController();
        const detachTool = (0, abort_1.linkAbort)(tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal, toolCtrl);
        const timer = setTimeout(() => toolCtrl.abort(), TOOL_TIMEOUT_MS);
        try {
          const outcome = await (0, BetaRunnableTool_1.runRunnableTool)(tool, ev.input, {
            toolUse: ev,
            toolUseBlock: ev,
            signal: toolCtrl.signal
          });
          content = outcome.content;
          isError = outcome.isError;
        } finally {
          clearTimeout(timer);
          detachTool();
        }
        const result = buildResultEvent(ev, isError, toSessionContent(content));
        const posted = await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_sendResult).call(this, result, ev.id);
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_surfaceCall).call(this, {
          event: ev,
          result,
          toolUseId: ev.id,
          name: ev.name,
          isError,
          posted,
          confirmation
        });
      } finally {
        tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_inFlightCount, (_b = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f"), _b--, _b), "f");
        if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f") === 0)
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_onIdle, "f")?.call(this);
      }
    }, _SessionToolRunner_sendResult = async function _SessionToolRunner_sendResult2(result, toolUseId) {
      const ctrl = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f");
      const start = Date.now();
      let lastErr;
      let attempt = 0;
      while (true) {
        attempt++;
        ctrl.signal.throwIfAborted();
        try {
          await this.client.beta.sessions.events.send(this.sessionId, { events: [result] }, tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_requestOptions).call(this));
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(toolUseId);
          return true;
        } catch (e) {
          lastErr = e;
          if ((0, backoff_1.isFatal4xx)(e))
            break;
          const remainingMs = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_sendRetryWindowMs, "f") - (Date.now() - start);
          if (remainingMs <= 0)
            break;
          const waitMs = Math.min((0, backoff_1.applyJitter)((0, backoff_1.backoff)(attempt - 1, SEND_BACKOFF_START_MS, SEND_BACKOFF_CAP_MS)), remainingMs);
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("tool result send failed; retrying", {
            tool_use_id: toolUseId,
            attempt,
            backoff_ms: waitMs,
            error: String(e)
          });
          await (0, sleep_1.sleep)(waitMs, ctrl.signal);
        }
      }
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").error("failed to send tool result", {
        tool_use_id: toolUseId,
        attempts: attempt,
        error: String(lastErr)
      });
      return false;
    }, _SessionToolRunner_drain = /** Wait (bounded) for in-flight tool executions to finish during teardown. */
    async function _SessionToolRunner_drain2() {
      if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f") === 0)
        return;
      await Promise.race([new Promise((r) => tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_onIdle, r, "f")), (0, sleep_1.sleep)(DRAIN_TIMEOUT_MS)]);
      tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_onIdle, null, "f");
      if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f") > 0) {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("drain timeout exceeded");
      }
    };
    function buildResultEvent(ev, isError, content) {
      if (ev.type === "agent.custom_tool_use") {
        return { type: "user.custom_tool_result", custom_tool_use_id: ev.id, is_error: isError, content };
      }
      return { type: "user.tool_result", tool_use_id: ev.id, is_error: isError, content };
    }
    function toSessionContent(content) {
      if (typeof content === "string")
        return [{ type: "text", text: content || "(no output)" }];
      const out = content.map((b) => {
        if (b.type === "text")
          return { type: "text", text: b.text || "(no output)" };
        if (b.type === "image" || b.type === "document")
          return b;
        if (b.type === "search_result") {
          return {
            type: "search_result",
            source: b.source,
            title: b.title,
            content: b.content.map((c) => ({ type: "text", text: c.text })),
            citations: { enabled: b.citations?.enabled ?? false }
          };
        }
        return { type: "text", text: JSON.stringify(b) };
      });
      return out.length > 0 ? out : [{ type: "text", text: "(no output)" }];
    }
  }
});

// node_modules/@anthropic-ai/sdk/tools/agent-toolset/sync-interval.js
var require_sync_interval = __commonJS({
  "node_modules/@anthropic-ai/sdk/tools/agent-toolset/sync-interval.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MIN_MEMORY_SYNC_INTERVAL_MS = exports2.DEFAULT_MEMORY_SYNC_INTERVAL_MS = void 0;
    exports2.checkMemorySyncInterval = checkMemorySyncInterval;
    var error_1 = require_error();
    exports2.DEFAULT_MEMORY_SYNC_INTERVAL_MS = 15e3;
    exports2.MIN_MEMORY_SYNC_INTERVAL_MS = 5e3;
    function checkMemorySyncInterval(ms, option) {
      if (!(ms >= exports2.MIN_MEMORY_SYNC_INTERVAL_MS)) {
        throw new error_1.AnthropicError(`${option} must be at least ${exports2.MIN_MEMORY_SYNC_INTERVAL_MS}ms (got ${ms}); to run without memory sync, pass \`memorySyncIntervalMs: null\` to the worker instead`);
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/transform-json-schema.js
var require_transform_json_schema = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/transform-json-schema.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.transformJSONSchema = transformJSONSchema;
    var utils_1 = require_utils2();
    var SUPPORTED_STRING_FORMATS = /* @__PURE__ */ new Set([
      "date-time",
      "time",
      "date",
      "duration",
      "email",
      "hostname",
      "uri",
      "ipv4",
      "ipv6",
      "uuid"
    ]);
    function deepClone(obj) {
      return JSON.parse(JSON.stringify(obj));
    }
    function transformJSONSchema(jsonSchema) {
      const workingCopy = deepClone(jsonSchema);
      return _transformJSONSchema(workingCopy);
    }
    function _transformJSONSchema(jsonSchema) {
      const strictSchema = {};
      const defs = (0, utils_1.pop)(jsonSchema, "$defs");
      if (defs !== void 0) {
        const strictDefs = {};
        strictSchema["$defs"] = strictDefs;
        for (const [name, defSchema] of Object.entries(defs)) {
          strictDefs[name] = _transformJSONSchema(defSchema);
        }
      }
      const ref = (0, utils_1.pop)(jsonSchema, "$ref");
      if (ref !== void 0) {
        strictSchema["$ref"] = ref;
        return strictSchema;
      }
      const type = (0, utils_1.pop)(jsonSchema, "type");
      const anyOf = (0, utils_1.pop)(jsonSchema, "anyOf");
      const oneOf = (0, utils_1.pop)(jsonSchema, "oneOf");
      const allOf = (0, utils_1.pop)(jsonSchema, "allOf");
      if (Array.isArray(anyOf)) {
        strictSchema["anyOf"] = anyOf.map((variant) => _transformJSONSchema(variant));
      } else if (Array.isArray(oneOf)) {
        strictSchema["anyOf"] = oneOf.map((variant) => _transformJSONSchema(variant));
      } else if (Array.isArray(allOf)) {
        strictSchema["allOf"] = allOf.map((entry) => _transformJSONSchema(entry));
      } else {
        if (type === void 0) {
          throw new Error("JSON schema must have a type defined if anyOf/oneOf/allOf are not used");
        }
        strictSchema["type"] = type;
      }
      const description = (0, utils_1.pop)(jsonSchema, "description");
      if (description !== void 0) {
        strictSchema["description"] = description;
      }
      const title = (0, utils_1.pop)(jsonSchema, "title");
      if (title !== void 0) {
        strictSchema["title"] = title;
      }
      if (type === "object") {
        const properties = (0, utils_1.pop)(jsonSchema, "properties") || {};
        strictSchema["properties"] = Object.fromEntries(Object.entries(properties).map(([key, propSchema]) => [
          key,
          _transformJSONSchema(propSchema)
        ]));
        (0, utils_1.pop)(jsonSchema, "additionalProperties");
        strictSchema["additionalProperties"] = false;
        const required = (0, utils_1.pop)(jsonSchema, "required");
        if (required !== void 0) {
          strictSchema["required"] = required;
        }
      } else if (type === "string") {
        const format = (0, utils_1.pop)(jsonSchema, "format");
        if (format !== void 0 && SUPPORTED_STRING_FORMATS.has(format)) {
          strictSchema["format"] = format;
        } else if (format !== void 0) {
          jsonSchema["format"] = format;
        }
      } else if (type === "array") {
        const items = (0, utils_1.pop)(jsonSchema, "items");
        if (items !== void 0) {
          strictSchema["items"] = _transformJSONSchema(items);
        }
        const minItems = (0, utils_1.pop)(jsonSchema, "minItems");
        if (minItems !== void 0 && (minItems === 0 || minItems === 1)) {
          strictSchema["minItems"] = minItems;
        } else if (minItems !== void 0) {
          jsonSchema["minItems"] = minItems;
        }
      }
      if (Object.keys(jsonSchema).length > 0) {
        const existingDescription = strictSchema["description"];
        strictSchema["description"] = (existingDescription ? existingDescription + "\n\n" : "") + "{" + Object.entries(jsonSchema).map(([key, value]) => `${key}: ${JSON.stringify(value)}`).join(", ") + "}";
      }
      return strictSchema;
    }
  }
});

// node_modules/@anthropic-ai/sdk/helpers/beta/json-schema.js
var require_json_schema = __commonJS({
  "node_modules/@anthropic-ai/sdk/helpers/beta/json-schema.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.betaTool = betaTool;
    exports2.betaJSONSchemaOutputFormat = betaJSONSchemaOutputFormat;
    var __1 = require_sdk();
    var transform_json_schema_1 = require_transform_json_schema();
    function betaTool(options) {
      if (options.inputSchema.type !== "object") {
        throw new Error(`JSON schema for tool "${options.name}" must be an object, but got ${options.inputSchema.type}`);
      }
      return {
        type: "custom",
        name: options.name,
        input_schema: options.inputSchema,
        description: options.description,
        run: options.run,
        parse: (content) => content,
        ...options.close ? { close: options.close } : {}
      };
    }
    function betaJSONSchemaOutputFormat(jsonSchema, options) {
      if (jsonSchema.type !== "object") {
        throw new Error(`JSON schema for tool must be an object, but got ${jsonSchema.type}`);
      }
      const transform = options?.transform ?? true;
      if (transform) {
        jsonSchema = (0, transform_json_schema_1.transformJSONSchema)(jsonSchema);
      }
      return {
        type: "json_schema",
        schema: {
          ...jsonSchema
        },
        parse: (content) => {
          try {
            return JSON.parse(content);
          } catch (error) {
            throw new __1.AnthropicError(`Failed to parse structured output: ${error}`);
          }
        }
      };
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/promise.js
var require_promise = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/promise.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.promiseWithResolvers = promiseWithResolvers;
    function promiseWithResolvers() {
      let resolve;
      let reject;
      const promise = new Promise((res, rej) => {
        resolve = res;
        reject = rej;
      });
      return { promise, resolve, reject };
    }
  }
});

// node_modules/@anthropic-ai/sdk/tools/agent-toolset/fs-util.js
var require_fs_util = __commonJS({
  "node_modules/@anthropic-ai/sdk/tools/agent-toolset/fs-util.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.FILE_CREATE_MODE = exports2.DIR_CREATE_MODE = void 0;
    exports2.isWithin = isWithin;
    exports2.containingRoot = containingRoot;
    exports2.errnoCode = errnoCode;
    exports2.canonicalize = canonicalize;
    exports2.confineToRoot = confineToRoot;
    exports2.atomicWriteFile = atomicWriteFile;
    exports2.fsErrorMessage = fsErrorMessage;
    var node_1 = require_node();
    var ToolError_1 = require_ToolError();
    var fs2 = node_1.fs.promises;
    exports2.DIR_CREATE_MODE = 448;
    exports2.FILE_CREATE_MODE = 384;
    function isWithin(root, p) {
      const rel = node_1.path.relative(root, p);
      return rel === "" || !rel.startsWith(".." + node_1.path.sep) && rel !== ".." && !node_1.path.isAbsolute(rel);
    }
    async function containingRoot(roots, target) {
      for (const root of roots) {
        if (isWithin(await canonicalize(node_1.path.resolve(root)), target))
          return root;
      }
      return void 0;
    }
    var MAX_SYMLINK_HOPS = 40;
    function errnoCode(err) {
      const code = err?.code;
      return typeof code === "string" ? code : void 0;
    }
    async function canonicalize(abs) {
      const tail = [];
      let prefix = abs;
      let hops = 0;
      for (; ; ) {
        let real;
        try {
          real = await fs2.realpath(prefix);
        } catch (realpathErr) {
          let isLink;
          try {
            isLink = (await fs2.lstat(prefix)).isSymbolicLink();
          } catch (lstatErr) {
            const code = errnoCode(lstatErr);
            if (code !== "ENOENT" && code !== "ENOTDIR")
              throw lstatErr;
            const parent = node_1.path.dirname(prefix);
            if (parent === prefix)
              throw lstatErr;
            tail.push(node_1.path.basename(prefix));
            prefix = parent;
            continue;
          }
          if (!isLink)
            throw realpathErr;
          if (++hops > MAX_SYMLINK_HOPS) {
            throw Object.assign(new Error("too many levels of symbolic links"), { code: "ELOOP" });
          }
          prefix = node_1.path.resolve(node_1.path.dirname(prefix), await fs2.readlink(prefix));
          continue;
        }
        return tail.length ? node_1.path.join(real, ...tail.reverse()) : real;
      }
    }
    async function confineToRoot(root, p, opts) {
      const allowedRoots = opts?.allowedRoots ?? [];
      const realRoot = await canonicalize(node_1.path.resolve(root));
      let real;
      try {
        real = await canonicalize(node_1.path.resolve(realRoot, p));
      } catch (err) {
        throw new ToolError_1.ToolError(fsErrorMessage(err, `path ${JSON.stringify(p)}`));
      }
      if (isWithin(realRoot, real) || await containingRoot(allowedRoots, real) !== void 0) {
        return real;
      }
      const permitted = allowedRoots.length ? "the session's working directory and its other permitted directories" : "the session's working directory";
      throw new ToolError_1.ToolError(`path ${JSON.stringify(p)} is outside ${permitted}`);
    }
    async function atomicWriteFile(targetPath, content) {
      const dir = node_1.path.dirname(targetPath);
      const tempPath = node_1.path.join(dir, `.tmp-${process.pid}-${node_1.crypto.randomUUID()}`);
      const existingMode = await fs2.stat(targetPath).then((st) => st.mode & 511, () => void 0);
      let handle2;
      try {
        handle2 = await fs2.open(tempPath, "wx", exports2.FILE_CREATE_MODE);
        if (existingMode !== void 0)
          await handle2.chmod(existingMode);
        await handle2.writeFile(content, "utf-8");
        await handle2.sync();
        await handle2.close();
        handle2 = void 0;
        await fs2.rename(tempPath, targetPath);
      } catch (err) {
        if (handle2)
          await handle2.close().catch(() => {
          });
        await fs2.unlink(tempPath).catch(() => {
        });
        throw err;
      }
    }
    function fsErrorMessage(err, file) {
      const code = errnoCode(err);
      switch (code) {
        case "ENOENT":
          return `${file}: no such file or directory`;
        case "EACCES":
        case "EPERM":
          return `${file}: permission denied`;
        case "ENOTDIR":
          return `${file}: not a directory`;
        case "EISDIR":
          return `${file}: is a directory`;
        case "ELOOP":
          return `${file}: too many levels of symbolic links`;
        case "ENAMETOOLONG":
          return `${file}: file name too long`;
        case "ENOSPC":
          return `${file}: no space left on device`;
        case "EMFILE":
        case "ENFILE":
          return `${file}: too many open files`;
        default:
          return `${file}: ${code !== void 0 ? `i/o error (${code})` : "i/o error"}`;
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/tools/agent-toolset/skills.js
var require_skills = __commonJS({
  "node_modules/@anthropic-ai/sdk/tools/agent-toolset/skills.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.setupSkills = setupSkills;
    exports2.classifyArchiveListing = classifyArchiveListing;
    exports2.assertOnlyPlainEntries = assertOnlyPlainEntries;
    exports2.extractSkillArchive = extractSkillArchive;
    var node_1 = require_node();
    var error_1 = require_error();
    var log_1 = require_log();
    var fs_util_1 = require_fs_util();
    var fs2 = node_1.fs.promises;
    var execFileAsync = node_1.util.promisify(node_1.child_process.execFile);
    async function setupSkills(ctx) {
      const { client, sessionId } = ctx;
      if (!client)
        return async () => {
        };
      const log = (0, log_1.loggerFor)(client);
      let session = ctx.session;
      if (!session) {
        if (sessionId === void 0)
          return async () => {
          };
        log.warn("AgentToolContext.sessionId is deprecated and costs an extra session fetch; fetch the session once and set `session` instead", { component: "agent-tool-context" });
        session = await client.beta.sessions.retrieve(sessionId);
      }
      const skillsRoot = node_1.path.resolve(ctx.workdir, "skills");
      const created = [];
      for (const skill of session.agent.skills) {
        try {
          const version = await client.beta.skills.versions.retrieve(skill.version, { skill_id: skill.skill_id });
          let dirname = node_1.path.basename(version.name.trim());
          if (dirname === "" || dirname === "." || dirname === "..")
            dirname = skill.skill_id;
          const dest = node_1.path.resolve(skillsRoot, dirname);
          if (dest !== skillsRoot && !dest.startsWith(skillsRoot + node_1.path.sep)) {
            log.warn("skill name escapes the skills dir; skipping", {
              component: "agent-tool-context",
              name: version.name
            });
            continue;
          }
          const resp = await client.beta.skills.versions.download(version.id, { skill_id: skill.skill_id });
          await fs2.rm(dest, { recursive: true, force: true });
          await fs2.mkdir(dest, { recursive: true, mode: fs_util_1.DIR_CREATE_MODE });
          created.push(dest);
          await extractSkillArchive(resp, dest);
          log.info("downloaded skill", {
            component: "agent-tool-context",
            skill_id: skill.skill_id,
            version: version.id,
            dest
          });
        } catch (e) {
          log.warn("failed to download skill", {
            component: "agent-tool-context",
            skill_id: skill.skill_id,
            error: String(e)
          });
        }
      }
      return async () => {
        for (const dest of created) {
          await fs2.rm(dest, { recursive: true, force: true }).catch((e) => {
            log.warn("failed to clean up skill", { component: "agent-tool-context", dest, error: String(e) });
          });
        }
      };
    }
    function assertSafeMemberNames(names) {
      for (const raw of names) {
        const entry = raw.trim();
        if (!entry)
          continue;
        if (node_1.path.isAbsolute(entry) || entry.split(/[\\/]/).includes("..")) {
          throw new error_1.AnthropicError(`refusing to extract unsafe archive member: ${entry}`);
        }
      }
    }
    var INCONSISTENT_LISTING = "skill archive listing is inconsistent; refusing to extract";
    var PLAIN_TYPE_CHARS = { unzip: /* @__PURE__ */ new Set(["-", "d", "?"]), tar: /* @__PURE__ */ new Set(["-", "d", "C"]) };
    function listingLines(listing) {
      const lines = listing.split("\n");
      if (lines[lines.length - 1] === "")
        lines.pop();
      return lines;
    }
    function canExcludeVerbatim(cmd, name) {
      return /^[\x20-\x7E]+$/.test(name) && !/[\\^#]/.test(name) && !(cmd === "unzip" && name.startsWith("-"));
    }
    function classifyArchiveListing(cmd, names, typed) {
      const nameLines = listingLines(names);
      const typedLines = listingLines(typed);
      if (nameLines.length !== typedLines.length)
        throw new error_1.AnthropicError(INCONSISTENT_LISTING);
      const plain = [];
      const special = [];
      nameLines.forEach((name, i) => {
        if (PLAIN_TYPE_CHARS[cmd].has(typedLines[i].charAt(0))) {
          plain.push(name);
          return;
        }
        if (!canExcludeVerbatim(cmd, name)) {
          throw new error_1.AnthropicError(`refusing to extract archive: cannot safely exclude member ${JSON.stringify(name)}`);
        }
        special.push(name);
      });
      return { plain, special };
    }
    async function assertOnlyPlainEntries(dir) {
      for (const entry of await fs2.readdir(dir, { withFileTypes: true })) {
        if (entry.isDirectory())
          await assertOnlyPlainEntries(node_1.path.join(dir, entry.name));
        else if (!entry.isFile())
          throw new error_1.AnthropicError(INCONSISTENT_LISTING);
      }
    }
    async function runArchiveTool(cmd, args) {
      try {
        const { stdout } = await execFileAsync(cmd, args);
        return stdout;
      } catch (e) {
        if ((0, fs_util_1.errnoCode)(e) === "ENOENT") {
          throw new error_1.AnthropicError(`skill extraction requires the \`${cmd}\` command, but it was not found on PATH`);
        }
        throw e;
      }
    }
    function archiveTopDir(names) {
      let top;
      let nested = false;
      for (const raw of names) {
        const parts = raw.trim().split("/").filter((p) => p !== "" && p !== ".");
        if (parts.length === 0)
          continue;
        const first = parts[0];
        if (top === void 0)
          top = first;
        else if (first !== top)
          return "";
        if (parts.length > 1)
          nested = true;
      }
      return top !== void 0 && nested ? top : "";
    }
    async function extractSkillArchive(resp, dest) {
      const tmp = node_1.path.join(dest, `.skill-archive-${process.pid}-${Date.now()}`);
      if (!resp.body) {
        throw new error_1.AnthropicError("skill download response had no body");
      }
      await node_1.stream.promises.pipeline(node_1.stream.Readable.fromWeb(resp.body), node_1.fs.createWriteStream(tmp));
      const stage = node_1.path.join(node_1.path.dirname(dest), `.skill-stage-${process.pid}-${Date.now()}`);
      const excludeFile = node_1.path.join(node_1.path.dirname(dest), `.skill-exclude-${process.pid}-${Date.now()}`);
      try {
        const head = await readHead(tmp, 4);
        const isZip = head.length >= 4 && head[0] === 80 && head[1] === 75 && head[2] === 3 && head[3] === 4;
        const archiveCmd = isZip ? "unzip" : "tar";
        const names = await runArchiveTool(archiveCmd, isZip ? ["-Z1", tmp] : ["-tf", tmp]);
        const typed = await runArchiveTool(archiveCmd, isZip ? ["-Z", "--h", "--t", tmp] : ["-tvf", tmp]);
        const { plain, special } = classifyArchiveListing(archiveCmd, names, typed);
        assertSafeMemberNames([...plain, ...special]);
        const top = archiveTopDir(plain);
        await fs2.mkdir(stage, { recursive: true, mode: fs_util_1.DIR_CREATE_MODE });
        if (plain.length > 0) {
          await runArchiveTool(archiveCmd, await extractArgs(archiveCmd, tmp, stage, special, excludeFile));
        }
        await assertOnlyPlainEntries(stage);
        const srcRoot = top ? node_1.path.join(stage, top) : stage;
        const entries = await fs2.readdir(srcRoot).catch((e) => {
          throw (0, fs_util_1.errnoCode)(e) === "ENOENT" ? new error_1.AnthropicError(INCONSISTENT_LISTING) : e;
        });
        for (const entry of entries) {
          await fs2.rename(node_1.path.join(srcRoot, entry), node_1.path.join(dest, entry));
        }
      } finally {
        await fs2.rm(tmp, { force: true });
        await fs2.rm(excludeFile, { force: true });
        await fs2.rm(stage, { recursive: true, force: true });
      }
    }
    async function extractArgs(cmd, archive, stage, special, excludeFile) {
      const patterns = special.map((name) => name.replace(/[*?[\\]/g, "\\$&"));
      if (cmd === "unzip") {
        return ["-oq", archive, "-d", stage, ...patterns.length > 0 ? ["-x", ...patterns] : []];
      }
      if (patterns.length === 0)
        return ["-xf", archive, "-C", stage];
      await fs2.writeFile(excludeFile, patterns.join("\n") + "\n", { flag: "wx", mode: 384 });
      return ["-xf", archive, "-C", stage, "-X", excludeFile];
    }
    async function readHead(file, n) {
      const handle2 = await fs2.open(file, "r");
      try {
        const buf = Buffer.alloc(n);
        const { bytesRead } = await handle2.read(buf, 0, n, 0);
        return buf.subarray(0, bytesRead);
      } finally {
        await handle2.close();
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/file-store.js
var require_file_store = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/file-store.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.LocalFileStore = exports2._internals = exports2.FileStore = exports2.FileStoreError = void 0;
    exports2.openFileStore = openFileStore;
    exports2.isPathLegal = isPathLegal;
    var node_1 = require_node();
    var bytes_1 = require_bytes();
    var fsp2 = node_1.fs.promises;
    var C = node_1.fs.constants;
    var OWNER_ONLY_DIR_MODE = 448;
    var OWNER_ONLY_FILE_MODE = 384;
    var OWNER_ONLY_EXEC_MODE = 448;
    var O_NOFOLLOW = C.O_NOFOLLOW ?? 0;
    var O_NONBLOCK = C.O_NONBLOCK ?? 0;
    var FileStoreError = /* @__PURE__ */ (() => {
      class FileStoreError2 extends Error {
        constructor(reason, relPath) {
          super(`path ${JSON.stringify(relPath)} ${reason}`);
          this.name = "FileStoreError";
          this.reason = reason;
          this.relPath = relPath;
        }
      }
      FileStoreError2.ESCAPES_ROOT = "escapes the store root";
      FileStoreError2.IS_A_SYMLINK = "is a symlink";
      FileStoreError2.NOT_A_FILE = "is not a regular file";
      FileStoreError2.NOT_A_DIRECTORY = "is not a directory";
      FileStoreError2.NOT_UTF8 = "is not valid utf-8";
      FileStoreError2.MOVE_DESTINATION_EXISTS = "already exists";
      return FileStoreError2;
    })();
    exports2.FileStoreError = FileStoreError;
    async function openFileStore(root, opts) {
      return FileStore.open(root, opts);
    }
    function isPathLegal(p) {
      return p.startsWith("/") && !p.split("/").includes("..");
    }
    var FileStore = /* @__PURE__ */ (() => {
      class FileStore2 {
        /** @internal — use {@link FileStore.open} / {@link openFileStore}. */
        constructor(root, removedOnDispose, utf8Only = false) {
          this.hashes = /* @__PURE__ */ new Map();
          this.rootPath = root;
          this.removedOnDispose = removedOnDispose;
          this.decoder = utf8Only ? new TextDecoder("utf-8", { fatal: true }) : void 0;
        }
        /** Resolve `root`; creates nothing — only {@link createRoot} makes the folder. */
        static async open(root, opts) {
          if (!platformSupported()) {
            throw new Error("FileStore requires O_NOFOLLOW support on this platform");
          }
          let removedOnDispose = false;
          try {
            await fsp2.lstat(root);
          } catch (e) {
            if (e.code !== "ENOENT")
              throw e;
            removedOnDispose = true;
          }
          return new FileStore2(node_1.path.resolve(root), removedOnDispose, opts?.utf8 ?? false);
        }
        /** Create the root directory and any missing ancestors; already existing is fine. */
        async createRoot() {
          await makeDirAndAncestors(this.rootPath);
        }
        /** The resolved root, and what {@link dispose} will do to it. */
        root() {
          return { path: this.rootPath, removedOnDispose: this.removedOnDispose };
        }
        /**
         * Remove the root iff `open` created it; pre-existing roots are kept.
         *
         * Wired to `Symbol.asyncDispose` at runtime when the host provides it, so
         * `await using` works on engines with explicit resource management.
         */
        async dispose() {
          if (!this.removedOnDispose)
            return;
          await fsp2.rm(this.rootPath, { recursive: true, force: true });
        }
        /**
         * Write `data` (`string` UTF-8 or bytes) atomically to the file at `relPath`.
         *
         * Missing directories below the root are created; a missing root is not —
         * the write fails with `ENOENT`.
         */
        async put(relPath, data, opts) {
          const tail = relPath.replace(/\\/g, "/");
          if (tail.endsWith("/") || tail.endsWith("/.") || tail === "" || tail === ".") {
            throw new FileStoreError(FileStoreError.NOT_A_FILE, relPath);
          }
          const dest = this.resolveUnderRoot(relPath);
          const payload = typeof data === "string" ? (0, bytes_1.encodeUTF8)(data) : data;
          this.requireUtf8(relPath, payload);
          await makeDirsBelowRoot(this.rootPath, node_1.path.dirname(dest));
          await replaceViaTemp(dest, payload, opts?.executable ?? false);
        }
        /** The file's bytes; `null` when absent. */
        async get(relPath) {
          const dest = this.resolveUnderRoot(relPath);
          let handle2;
          try {
            handle2 = await openRegularFile(relPath, dest);
          } catch (e) {
            if (e.code === "ENOENT")
              return null;
            throw e;
          }
          let data;
          try {
            const buf = await handle2.readFile();
            data = new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
          } finally {
            await handle2.close();
          }
          this.requireUtf8(relPath, data);
          return data;
        }
        /** The relative path of every file under the directory `under`. */
        async ls(under = "/") {
          const base = this.resolveUnderRoot(under);
          return new Set((await filenamesInDir(this.rootPath, under, base)).map(([rel]) => rel));
        }
        /**
         * Every symlink under `under` — listings skip them and reads refuse them,
         * so a caller that must know they exist asks here.
         */
        async findSymlinks(under = "/") {
          const base = this.resolveUnderRoot(under);
          return symlinksInDir(this.rootPath, under, base);
        }
        /**
         * `{relPath: sha256Hex}` of every file under the directory `under`.
         *
         * Unchanged files — same size, mtime, and ctime since the last call —
         * reuse their recorded hash instead of being re-read.
         */
        async hashtree(under = "/") {
          const base = this.resolveUnderRoot(under);
          const walkStartNs = exports2._internals.nowNs();
          const out = /* @__PURE__ */ Object.create(null);
          for (const [rel, full] of await filenamesInDir(this.rootPath, under, base)) {
            const sha = await this.hashViaCache(rel, full, walkStartNs);
            if (sha !== null)
              out[rel] = sha;
          }
          return out;
        }
        /** One file's sha256; `null` when absent. Shares {@link hashtree}'s cache. */
        async hashFile(relPath) {
          const dest = this.resolveUnderRoot(relPath);
          let st;
          try {
            st = await fsp2.lstat(dest, { bigint: true });
          } catch (e) {
            if (e.code === "ENOENT")
              return null;
            throw e;
          }
          if (st.isSymbolicLink())
            throw new FileStoreError(FileStoreError.IS_A_SYMLINK, relPath);
          if (!st.isFile())
            throw new FileStoreError(FileStoreError.NOT_A_FILE, relPath);
          const rel = node_1.path.relative(this.rootPath, dest).split(node_1.path.sep).join("/");
          return this.hashViaCache(rel, dest, exports2._internals.nowNs());
        }
        /**
         * Rename `src` to `dst`; an existing `dst` is refused. The banned store
         * root as either end does nothing.
         */
        async move(src, dst) {
          const s = this.resolveUnderRoot(src);
          const d = this.resolveUnderRoot(dst);
          if (s === this.rootPath || d === this.rootPath)
            return;
          const dstExists = await fsp2.stat(d).then(() => true, () => false);
          if (dstExists)
            throw new FileStoreError(FileStoreError.MOVE_DESTINATION_EXISTS, dst);
          await makeDirsBelowRoot(this.rootPath, node_1.path.dirname(d));
          await fsp2.rename(s, d);
        }
        /** Delete a file or subtree; absent — and the banned store root — do nothing. */
        async remove(relPath) {
          const dest = this.resolveUnderRoot(relPath);
          if (dest === this.rootPath)
            return;
          let st;
          try {
            st = await fsp2.lstat(dest, { bigint: true });
          } catch (e) {
            if (e.code === "ENOENT")
              return;
            throw e;
          }
          if (st.isDirectory()) {
            await fsp2.rm(dest, { recursive: true, force: true });
          } else {
            try {
              await fsp2.unlink(dest);
            } catch (e) {
              if (e.code !== "ENOENT")
                throw e;
            }
          }
        }
        resolveUnderRoot(relPath) {
          const norm = relPath.replace(/\\/g, "/").replace(/^\/+/, "");
          const parts = norm.split("/").filter((p) => p !== "" && p !== ".");
          if (node_1.path.posix.isAbsolute(norm) || parts.includes("..")) {
            throw new FileStoreError(FileStoreError.ESCAPES_ROOT, relPath);
          }
          return parts.length === 0 ? this.rootPath : node_1.path.join(this.rootPath, ...parts);
        }
        requireUtf8(relPath, data) {
          if (!this.decoder)
            return;
          try {
            this.decoder.decode(data);
          } catch {
            throw new FileStoreError(FileStoreError.NOT_UTF8, relPath);
          }
        }
        async hashViaCache(rel, full, walkStartNs) {
          let st;
          try {
            st = await fsp2.lstat(full, { bigint: true });
          } catch (e) {
            if (e.code === "ENOENT")
              return null;
            throw e;
          }
          if (!st.isFile())
            return null;
          const cached = this.hashes.get(rel);
          let sha;
          if (cached !== void 0 && unchangedSinceHashed(cached, st)) {
            sha = cached.sha;
          } else {
            try {
              sha = await exports2._internals.hashFile(full);
            } catch (e) {
              const code = e.code;
              if (code === "ENOENT" || e instanceof FileStoreError)
                return null;
              if (code === "ELOOP" || code === "EMLINK")
                return null;
              throw e;
            }
          }
          if (oldEnoughToCache(st, walkStartNs)) {
            this.hashes.set(rel, { mtimeNs: st.mtimeNs, ctimeNs: st.ctimeNs, size: st.size, sha });
          }
          return sha;
        }
      }
      FileStore2.isPathLegal = isPathLegal;
      return FileStore2;
    })();
    exports2.FileStore = FileStore;
    function platformSupported() {
      return O_NOFOLLOW !== 0;
    }
    async function makeDirAndAncestors(dir) {
      const missing = [];
      let current = dir;
      for (; ; ) {
        try {
          await fsp2.stat(current);
          break;
        } catch (e) {
          const code = e.code;
          if (code !== "ENOENT" && code !== "ENOTDIR" && code !== "ELOOP")
            throw e;
        }
        missing.push(current);
        const parent = node_1.path.dirname(current);
        if (parent === current)
          break;
        current = parent;
      }
      for (const directory of missing.reverse()) {
        try {
          await fsp2.mkdir(directory, { mode: OWNER_ONLY_DIR_MODE });
        } catch (e) {
          if (e.code !== "EEXIST")
            throw e;
        }
      }
    }
    async function makeDirsBelowRoot(root, dir) {
      const below = node_1.path.relative(root, dir);
      if (below === "")
        return;
      let current = root;
      for (const part of below.split(node_1.path.sep)) {
        current = node_1.path.join(current, part);
        try {
          await fsp2.mkdir(current, { mode: OWNER_ONLY_DIR_MODE });
        } catch (e) {
          if (e.code !== "EEXIST")
            throw e;
        }
      }
    }
    async function replaceViaTemp(dest, data, isExecutable) {
      const mode = isExecutable ? OWNER_ONLY_EXEC_MODE : OWNER_ONLY_FILE_MODE;
      const tmp = node_1.path.join(node_1.path.dirname(dest), `.fs-${node_1.crypto.randomBytes(8).toString("hex")}.tmp`);
      let handle2;
      try {
        handle2 = await fsp2.open(tmp, C.O_WRONLY | C.O_CREAT | C.O_EXCL | O_NOFOLLOW, mode);
        await handle2.writeFile(data);
        await handle2.close();
        handle2 = void 0;
        await fsp2.rename(tmp, dest);
      } catch (err) {
        if (handle2)
          await handle2.close().catch(() => {
          });
        await fsp2.unlink(tmp).catch(() => {
        });
        throw err;
      }
    }
    async function openRegularFile(relPath, dest) {
      let handle2;
      try {
        handle2 = await fsp2.open(dest, C.O_RDONLY | O_NOFOLLOW | O_NONBLOCK);
      } catch (e) {
        const code = e.code;
        if (code === "ELOOP" || code === "EMLINK") {
          throw new FileStoreError(FileStoreError.IS_A_SYMLINK, relPath);
        }
        throw e;
      }
      try {
        const st = await handle2.stat();
        if (!st.isFile())
          throw new FileStoreError(FileStoreError.NOT_A_FILE, relPath);
      } catch (e) {
        await handle2.close().catch(() => {
        });
        throw e;
      }
      return handle2;
    }
    async function hashFile(full) {
      const digest = node_1.crypto.createHash("sha256");
      const handle2 = await openRegularFile(node_1.path.basename(full), full);
      const buf = new Uint8Array(1024 * 1024);
      try {
        for (; ; ) {
          const { bytesRead } = await handle2.read(buf, 0, buf.length);
          if (bytesRead === 0)
            break;
          digest.update(buf.subarray(0, bytesRead));
        }
      } finally {
        await handle2.close();
      }
      return digest.digest("hex");
    }
    async function filenamesInDir(root, under, base) {
      if (!await requireDir(under, base))
        return [];
      const out = [];
      await walk(base, (full, entry) => {
        if (entry.isFile())
          out.push([node_1.path.relative(root, full).split(node_1.path.sep).join("/"), full]);
      });
      out.sort();
      return out;
    }
    async function symlinksInDir(root, under, base) {
      const relOf = (full) => node_1.path.relative(root, full).split(node_1.path.sep).join("/");
      let st;
      try {
        st = await fsp2.lstat(base, { bigint: true });
      } catch (e) {
        const code = e.code;
        if (code === "ENOENT" || code === "ENOTDIR")
          return /* @__PURE__ */ new Set();
        throw e;
      }
      if (st.isSymbolicLink())
        return /* @__PURE__ */ new Set([relOf(base)]);
      if (!st.isDirectory())
        throw new FileStoreError(FileStoreError.NOT_A_DIRECTORY, under);
      const out = /* @__PURE__ */ new Set();
      await walk(base, (full, entry) => {
        if (entry.isSymbolicLink())
          out.add(relOf(full));
      });
      return out;
    }
    async function requireDir(under, base) {
      let st;
      try {
        st = await fsp2.lstat(base, { bigint: true });
      } catch (e) {
        const code = e.code;
        if (code === "ENOENT" || code === "ENOTDIR")
          return false;
        throw e;
      }
      if (!st.isDirectory())
        throw new FileStoreError(FileStoreError.NOT_A_DIRECTORY, under);
      return true;
    }
    async function walk(base, visit) {
      const stack = [base];
      while (stack.length) {
        const dir = stack.pop();
        let entries;
        try {
          entries = await fsp2.readdir(dir, { withFileTypes: true });
        } catch (e) {
          if (e.code === "ENOENT")
            continue;
          throw e;
        }
        for (const entry of entries) {
          const full = node_1.path.join(dir, entry.name);
          visit(full, entry);
          if (entry.isDirectory() && !entry.isSymbolicLink())
            stack.push(full);
        }
      }
    }
    function unchangedSinceHashed(cached, st) {
      return st.mtimeNs === cached.mtimeNs && st.ctimeNs === cached.ctimeNs && st.size === cached.size;
    }
    function oldEnoughToCache(st, walkStartNs) {
      const newestNs = st.mtimeNs > st.ctimeNs ? st.mtimeNs : st.ctimeNs;
      return newestNs < walkStartNs - exports2._internals.timestampTrustMarginNs;
    }
    var TIMESTAMP_TRUST_MARGIN_NS = 2000000000n;
    exports2._internals = {
      hashFile,
      timestampTrustMarginNs: TIMESTAMP_TRUST_MARGIN_NS,
      nowNs: () => BigInt(Date.now()) * 1000000n
    };
    exports2.LocalFileStore = FileStore;
    var asyncDispose = Symbol.asyncDispose;
    if (asyncDispose) {
      Object.defineProperty(FileStore.prototype, asyncDispose, {
        value: FileStore.prototype.dispose,
        configurable: true,
        writable: true
      });
    }
  }
});

// node_modules/@anthropic-ai/sdk/tools/agent-toolset/memories.js
var require_memories = __commonJS({
  "node_modules/@anthropic-ai/sdk/tools/agent-toolset/memories.js"(exports2) {
    "use strict";
    var _SessionMemoryStores_instances;
    var _SessionMemoryStores_client;
    var _SessionMemoryStores_workdir;
    var _SessionMemoryStores_syncIntervalMs;
    var _SessionMemoryStores_syncDeletions;
    var _SessionMemoryStores_log;
    var _SessionMemoryStores_lastSyncAt;
    var _SessionMemoryStores_finished;
    var _SessionMemoryStores_stores;
    var _SessionMemoryStores_storeRoot;
    var _SessionMemoryStores_scanMarker;
    var _SessionMemoryStores_syncStore;
    var _SessionMemoryStores_flushStore;
    var _SessionMemoryStores_recover;
    var _SessionMemoryStores_stampAndPull;
    var _SessionMemoryStores_syncPath;
    var _SessionMemoryStores_removeLocal;
    var _SessionMemoryStores_write;
    var _SessionMemoryStores_pullAll;
    var _SessionMemoryStores_uploadAll;
    var _SessionMemoryStores_listMemories;
    var _SessionMemoryStores_upload;
    var _SessionMemoryStores_corroboratedDelete;
    var _SessionMemoryStores_deleteRemote;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SessionMemoryStores = exports2.SessionMemoryError = exports2.UPLOAD_CONCURRENCY = exports2.DELETE_CORROBORATION_MS = exports2.MARKER_PATH = exports2.MEMORY_FLUSH_TIMEOUT_MS = exports2.MIN_MEMORY_SYNC_INTERVAL_MS = exports2.DEFAULT_MEMORY_SYNC_INTERVAL_MS = void 0;
    var tslib_1 = require_tslib();
    var node_1 = require_node();
    var error_1 = require_error();
    var log_1 = require_log();
    var bytes_1 = require_bytes();
    var backoff_1 = require_backoff();
    var file_store_1 = require_file_store();
    var sync_interval_1 = require_sync_interval();
    var sync_interval_2 = require_sync_interval();
    Object.defineProperty(exports2, "DEFAULT_MEMORY_SYNC_INTERVAL_MS", { enumerable: true, get: function() {
      return sync_interval_2.DEFAULT_MEMORY_SYNC_INTERVAL_MS;
    } });
    Object.defineProperty(exports2, "MIN_MEMORY_SYNC_INTERVAL_MS", { enumerable: true, get: function() {
      return sync_interval_2.MIN_MEMORY_SYNC_INTERVAL_MS;
    } });
    exports2.MEMORY_FLUSH_TIMEOUT_MS = 3e4;
    exports2.MARKER_PATH = ".anthropic-memory-store";
    var MARKER_VERSION = 1;
    function markerSha(memoryStoreId) {
      return node_1.crypto.createHash("sha256").update(`version ${MARKER_VERSION}
${memoryStoreId}`, "utf-8").digest("hex");
    }
    exports2.DELETE_CORROBORATION_MS = 3e4;
    var LIST_PAGE_SIZE = 100;
    var FULL_LIST_PAGE_SIZE = 20;
    var FETCH_CONCURRENCY = 16;
    exports2.UPLOAD_CONCURRENCY = 32;
    var DELETE_CAP_FLOOR = 8;
    var DELETE_CAP_CEILING = 50;
    var SessionMemoryError = class extends error_1.AnthropicError {
      constructor(message, cause) {
        super(message);
        this.name = "SessionMemoryError";
        if (cause !== void 0)
          this.cause = cause;
      }
    };
    exports2.SessionMemoryError = SessionMemoryError;
    var DeletePass = class {
      constructor(mode, cap, waiveWindow) {
        this.mode = mode;
        this.cap = cap;
        this.waiveWindow = waiveWindow;
        this.attempted = 0;
        this.capped = 0;
        this.suppressed = 0;
      }
      takeSlot() {
        if (this.attempted >= this.cap) {
          this.capped++;
          return false;
        }
        this.attempted++;
        return true;
      }
    };
    var SessionMemoryStores = class {
      constructor(client, opts) {
        _SessionMemoryStores_instances.add(this);
        _SessionMemoryStores_client.set(this, void 0);
        _SessionMemoryStores_workdir.set(this, void 0);
        _SessionMemoryStores_syncIntervalMs.set(this, void 0);
        _SessionMemoryStores_syncDeletions.set(this, void 0);
        _SessionMemoryStores_log.set(this, void 0);
        _SessionMemoryStores_lastSyncAt.set(this, void 0);
        _SessionMemoryStores_finished.set(this, false);
        _SessionMemoryStores_stores.set(this, []);
        tslib_1.__classPrivateFieldSet(this, _SessionMemoryStores_client, client, "f");
        tslib_1.__classPrivateFieldSet(this, _SessionMemoryStores_workdir, opts.workdir, "f");
        tslib_1.__classPrivateFieldSet(this, _SessionMemoryStores_syncIntervalMs, opts.syncIntervalMs ?? sync_interval_1.DEFAULT_MEMORY_SYNC_INTERVAL_MS, "f");
        (0, sync_interval_1.checkMemorySyncInterval)(tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_syncIntervalMs, "f"), "syncIntervalMs");
        tslib_1.__classPrivateFieldSet(this, _SessionMemoryStores_syncDeletions, opts.syncDeletions ?? "enabled", "f");
        tslib_1.__classPrivateFieldSet(this, _SessionMemoryStores_log, (0, log_1.loggerFor)(client), "f");
        tslib_1.__classPrivateFieldSet(this, _SessionMemoryStores_lastSyncAt, Date.now(), "f");
      }
      /**
       * Every attached store's root directory.
       *
       * The worker lists these as the file tools' allowed roots so a store
       * mounted outside the workdir stays reachable.
       */
      get roots() {
        return tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_stores, "f").map((s) => s.files.root().path);
      }
      /**
       * Root directories of stores attached read-only.
       *
       * The file tools consult this to refuse writes into read-only stores.
       */
      get readOnlyRoots() {
        return tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_stores, "f").filter((s) => s.readOnly).map((s) => s.files.root().path);
      }
      /**
       * Download every attached store's memories to disk.
       *
       * `session` arrives already fetched — one snapshot shared with the skills
       * download, so the two cannot disagree about the resources.
       */
      async download(session) {
        for (const resource of session.resources) {
          if (resource.type !== "memory_store")
            continue;
          const root = tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_storeRoot).call(this, resource);
          let store;
          try {
            store = {
              memoryStoreId: resource.memory_store_id,
              // utf8: a binary file is refused at put/get, not mid-sync.
              files: await file_store_1.LocalFileStore.open(root, { utf8: true }),
              readOnly: resource.access === "read_only",
              baseline: /* @__PURE__ */ new Map(),
              refusedShas: /* @__PURE__ */ new Map(),
              pendingDeletes: /* @__PURE__ */ new Map()
            };
            if (!store.files.root().removedOnDispose) {
              throw new SessionMemoryError(`something already exists at the memory store's path: ${root} (memory_store_id=${resource.memory_store_id}); it must not exist when the session starts`);
            }
            try {
              await store.files.createRoot();
            } catch (e) {
              if (!isErrno(e))
                throw e;
              throw new SessionMemoryError(`cannot create the memory store's folder: ${root} (memory_store_id=${resource.memory_store_id}): ${e}; the worker host must make this mount path writable`, e);
            }
            await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_stampAndPull).call(this, store);
            tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").info("downloaded memories", {
              count: store.baseline.size,
              memory_store_id: store.memoryStoreId,
              dest: store.files.root().path
            });
            tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_stores, "f").push(store);
          } catch (e) {
            if (store)
              await store.files.dispose().catch(() => {
              });
            if (e instanceof SessionMemoryError)
              throw e;
            throw new SessionMemoryError(`failed to download memory store memory_store_id=${resource.memory_store_id}: ${e}`, e);
          }
        }
        tslib_1.__classPrivateFieldSet(this, _SessionMemoryStores_lastSyncAt, Date.now(), "f");
      }
      /**
       * The session's last sync — skips the delete wait, so calling it twice
       * would undo the protection; it throws instead.
       */
      async finish() {
        if (tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_finished, "f")) {
          throw new error_1.AnthropicError("finish() was already called: it is the session's last sync and runs once");
        }
        tslib_1.__classPrivateFieldSet(this, _SessionMemoryStores_finished, true, "f");
        await this.syncAll(true);
      }
      /** @internal — reconcile every store once; the tests' deterministic driver */
      async syncAll(final) {
        await Promise.all(tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_stores, "f").map((store) => tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_syncStore).call(this, store, final)));
        tslib_1.__classPrivateFieldSet(this, _SessionMemoryStores_lastSyncAt, Date.now(), "f");
      }
      /** Sync when `syncIntervalMs` has elapsed since the last one. Never throws. */
      async syncIfDue() {
        if (Date.now() - tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_lastSyncAt, "f") < tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_syncIntervalMs, "f"))
          return;
        await this.syncAll(false);
      }
      /**
       * Upload new and changed files; send no deletes and pull nothing.
       *
       * The push-only rescue pass for a session ending on an error or
       * cancel — best-effort, bounded by the caller: once `signal` aborts no
       * further upload starts, each store cut off part-way logs how many
       * changed files it had not finished uploading, and this resolves without
       * waiting for requests already in flight. Each store uploads up to
       * {@link UPLOAD_CONCURRENCY} files at a time. Skips read-only stores,
       * refused files, files the server already holds, and folders that fail
       * the marker check. Never throws.
       */
      async flushWrites(signal) {
        await Promise.all(tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_stores, "f").map((store) => tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_flushStore).call(this, store, signal)));
      }
      /**
       * Remove every store directory that {@link SessionMemoryStores.download}
       * created. Pre-existing directories are left alone — that is
       * {@link FileStore.dispose}'s own rule. A folder that fails the marker
       * check is kept too — sync left it as found, so must dispose.
       */
      async dispose() {
        for (const store of tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_stores, "f")) {
          const root = store.files.root();
          try {
            const scan = await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_scanMarker).call(this, store);
            if (!scan.markerOk && Object.keys(scan.files).length > 0) {
              tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn(`${scan.distrustReason}; leaving the memory store folder on disk`, {
                root: root.path,
                memory_store_id: store.memoryStoreId
              });
              continue;
            }
            await store.files.dispose();
          } catch (e) {
            if (!(e instanceof file_store_1.FileStoreError) && !isErrno(e))
              throw e;
            tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("failed to remove the memory store folder", {
              root: store.files.root().path,
              memory_store_id: store.memoryStoreId,
              error: String(e)
            });
            continue;
          }
          if (root.removedOnDispose) {
            tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").info("removed memory store dir", {
              dest: root.path,
              memory_store_id: store.memoryStoreId
            });
          }
        }
      }
    };
    exports2.SessionMemoryStores = SessionMemoryStores;
    _SessionMemoryStores_client = /* @__PURE__ */ new WeakMap(), _SessionMemoryStores_workdir = /* @__PURE__ */ new WeakMap(), _SessionMemoryStores_syncIntervalMs = /* @__PURE__ */ new WeakMap(), _SessionMemoryStores_syncDeletions = /* @__PURE__ */ new WeakMap(), _SessionMemoryStores_log = /* @__PURE__ */ new WeakMap(), _SessionMemoryStores_lastSyncAt = /* @__PURE__ */ new WeakMap(), _SessionMemoryStores_finished = /* @__PURE__ */ new WeakMap(), _SessionMemoryStores_stores = /* @__PURE__ */ new WeakMap(), _SessionMemoryStores_instances = /* @__PURE__ */ new WeakSet(), _SessionMemoryStores_storeRoot = function _SessionMemoryStores_storeRoot2(resource) {
      if (resource.mount_path) {
        if (!(0, file_store_1.isPathLegal)(resource.mount_path)) {
          throw new SessionMemoryError(`memory store mount_path is not a clean absolute path: ${JSON.stringify(resource.mount_path)} (memory_store_id=${resource.memory_store_id})`);
        }
        return resource.mount_path;
      }
      return node_1.path.join(tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_workdir, "f"), "memory", resource.name || resource.memory_store_id);
    }, _SessionMemoryStores_scanMarker = async function _SessionMemoryStores_scanMarker2(store) {
      const local = await store.files.hashtree();
      const marker = local[exports2.MARKER_PATH];
      delete local[exports2.MARKER_PATH];
      if (marker === markerSha(store.memoryStoreId)) {
        return { files: local, markerOk: true, distrustReason: null };
      }
      return {
        files: local,
        markerOk: false,
        distrustReason: marker !== void 0 ? "the marker file does not match this store" : "the marker file is gone"
      };
    }, _SessionMemoryStores_syncStore = async function _SessionMemoryStores_syncStore2(store, final) {
      try {
        const scan = await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_scanMarker).call(this, store);
        const local = scan.files;
        if (!scan.markerOk) {
          if (Object.keys(local).length > 0) {
            tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn(`${scan.distrustReason}; leaving the memory store folder as found and not syncing`, {
              root: store.files.root().path,
              memory_store_id: store.memoryStoreId
            });
            return;
          }
          await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_recover).call(this, store, "the folder or its marker is gone");
          return;
        }
        if (Object.keys(local).length === 0 && store.baseline.size > 1) {
          await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_recover).call(this, store, "every memory file is gone at once");
          return;
        }
        const remote = /* @__PURE__ */ new Map();
        for await (const [rel, item] of tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_listMemories).call(this, store.memoryStoreId)) {
          remote.set(rel, item);
        }
        const deletes = new DeletePass(tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_syncDeletions, "f"), Math.max(DELETE_CAP_FLOOR, Math.min(DELETE_CAP_CEILING, Math.floor(store.baseline.size / 4))), final);
        const pulls = [];
        const baseline = /* @__PURE__ */ new Map();
        const paths = [.../* @__PURE__ */ new Set([...remote.keys(), ...Object.keys(local), ...store.baseline.keys()])].sort();
        for (const rel of paths) {
          const remoteItem = remote.get(rel);
          const localSha = local[rel];
          const baseSha = store.baseline.get(rel);
          let sha;
          if (localSha === void 0 && baseSha !== void 0 && remoteItem !== void 0 && remoteItem.content_sha256 === baseSha && !store.readOnly) {
            sha = await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_corroboratedDelete).call(this, store, rel, remoteItem, baseSha, deletes);
          } else {
            sha = await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_syncPath).call(this, store, rel, remoteItem, localSha, pulls);
          }
          if (sha !== void 0)
            baseline.set(rel, sha);
        }
        store.baseline = baseline;
        await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_pullAll).call(this, store, pulls);
        if (deletes.suppressed > 0) {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").debug("remote deletes are disabled; locally deleted memories stay on the server", {
            count: deletes.suppressed,
            memory_store_id: store.memoryStoreId
          });
        }
        if (deletes.capped > 0) {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn(`delete cap reached: ${deletes.mode === "log_only" ? "would send" : "sent"} ${deletes.attempted} deletes, held ${deletes.capped} for later syncs`, { memory_store_id: store.memoryStoreId });
        }
      } catch (e) {
        tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("memory sync failed", { memory_store_id: store.memoryStoreId, error: String(e) });
      }
    }, _SessionMemoryStores_flushStore = async function _SessionMemoryStores_flushStore2(store, signal) {
      const dirty = /* @__PURE__ */ new Map();
      const unsent = /* @__PURE__ */ new Set();
      const push = async () => {
        if (store.readOnly)
          return;
        const scan = await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_scanMarker).call(this, store);
        if (!scan.markerOk) {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn(`${scan.distrustReason}; not uploading anything from the memory store folder`, {
            root: store.files.root().path,
            memory_store_id: store.memoryStoreId
          });
          return;
        }
        for (const [rel, sha] of Object.entries(scan.files)) {
          if (sha !== store.baseline.get(rel) && store.refusedShas.get(rel) !== sha) {
            dirty.set(rel, sha);
            unsent.add(rel);
          }
        }
        if (dirty.size === 0 || signal?.aborted)
          return;
        const remote = /* @__PURE__ */ new Map();
        for await (const [rel, item] of tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_listMemories).call(this, store.memoryStoreId)) {
          if (signal?.aborted)
            return;
          remote.set(rel, item);
        }
        const uploads = [];
        for (const rel of [...dirty.keys()].sort()) {
          const localSha = dirty.get(rel);
          const baseSha = store.baseline.get(rel);
          const existing = remote.get(rel);
          if (existing !== void 0 && existing.content_sha256 === localSha) {
            store.baseline.set(rel, existing.content_sha256);
            unsent.delete(rel);
            continue;
          }
          if (existing !== void 0 && existing.content_sha256 !== baseSha) {
            tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("memory changed both locally and remotely; the flush leaves the remote version", {
              path: rel,
              memory_store_id: store.memoryStoreId
            });
            unsent.delete(rel);
            continue;
          }
          uploads.push([rel, localSha, existing]);
        }
        await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_uploadAll).call(this, store, uploads, unsent, signal);
      };
      try {
        await settledOrAborted(push(), signal);
        if (signal?.aborted && unsent.size > 0) {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn(`memory flush cut off part-way; ${unsent.size} of ${dirty.size} changed files had not finished uploading`, { memory_store_id: store.memoryStoreId });
        }
      } catch (e) {
        tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("memory flush failed", { memory_store_id: store.memoryStoreId, error: String(e) });
      }
    }, _SessionMemoryStores_recover = /** Rebuild a destroyed folder from the server; sends no deletes, no uploads. */
    async function _SessionMemoryStores_recover2(store, reason) {
      tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn(`${reason}; re-downloading the memory store folder instead of syncing`, {
        root: store.files.root().path,
        memory_store_id: store.memoryStoreId
      });
      await store.files.createRoot();
      await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_stampAndPull).call(this, store);
    }, _SessionMemoryStores_stampAndPull = /**
     * Write the marker, then pull every remote memory. Baseline is cleared
     * first so a failed write never leaves an entry whose file is not on disk.
     * Every memory is needed here, so the listing carries the content — pages
     * cost far fewer round-trips than a request per memory.
     */
    async function _SessionMemoryStores_stampAndPull2(store) {
      store.baseline = /* @__PURE__ */ new Map();
      store.pendingDeletes.clear();
      await store.files.put(exports2.MARKER_PATH, `version ${MARKER_VERSION}
${store.memoryStoreId}`);
      for await (const [rel, item] of tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_listMemories).call(this, store.memoryStoreId, "full")) {
        if (await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_write).call(this, store, rel, item.content ?? "")) {
          store.baseline.set(rel, item.content_sha256);
        }
      }
    }, _SessionMemoryStores_syncPath = /**
     * Reconcile one path. Returns the sha to record in the baseline, or
     * `undefined` to drop the path from it.
     *
     * `pulls` is an output: when the remote version should be written to disk,
     * this appends `[rel, remote]` to it instead of writing — `rel` is the
     * file to write, `remote` the listed memory whose content `#pullAll` will
     * fetch and write there.
     */
    async function _SessionMemoryStores_syncPath2(store, rel, remote, localSha, pulls) {
      const baseSha = store.baseline.get(rel);
      if (localSha !== void 0) {
        store.pendingDeletes.delete(rel);
      }
      if (!remote) {
        if (localSha === void 0) {
          store.pendingDeletes.delete(rel);
          return void 0;
        }
        if (baseSha !== void 0) {
          if (localSha === baseSha) {
            const fresh = await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_removeLocal).call(this, store, rel, baseSha);
            if (fresh === void 0)
              return void 0;
            if (fresh === baseSha)
              return baseSha;
            localSha = fresh;
          }
          if (store.readOnly) {
            tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("memory deleted remotely but edited locally; keeping the file, which a read-only store cannot push", { path: rel, memory_store_id: store.memoryStoreId });
          } else if (store.refusedShas.get(rel) !== localSha) {
            tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").info("memory deleted remotely but edited locally; re-creating it from the file", {
              path: rel,
              memory_store_id: store.memoryStoreId
            });
          }
        }
        if (store.readOnly)
          return void 0;
        if (store.refusedShas.get(rel) === localSha)
          return void 0;
        return await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_upload).call(this, store, rel, localSha, void 0);
      }
      const remoteSha = remote.content_sha256;
      const remoteChanged = remoteSha !== baseSha;
      const locallyEdited = localSha !== void 0 && localSha !== baseSha && localSha !== remoteSha;
      const localChanged = !store.readOnly && locallyEdited;
      if (localSha === void 0 && baseSha !== void 0) {
        if (remoteChanged) {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("memory deleted locally but changed remotely; restoring the remote version", {
            path: rel,
            memory_store_id: store.memoryStoreId
          });
          store.pendingDeletes.delete(rel);
          pulls.push([rel, remote]);
        }
        return baseSha;
      }
      if (remoteChanged) {
        if (localSha === remoteSha)
          return remoteSha;
        if (locallyEdited) {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("memory changed both locally and remotely; keeping the remote version", {
            path: rel,
            memory_store_id: store.memoryStoreId
          });
        }
        pulls.push([rel, remote]);
        return baseSha;
      }
      if (localChanged) {
        if (store.refusedShas.get(rel) === localSha)
          return remoteSha;
        return await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_upload).call(this, store, rel, localSha, remote) ?? remoteSha;
      }
      return remoteSha;
    }, _SessionMemoryStores_removeLocal = /**
     * Remove the file for a memory the server no longer has, if it still holds
     * `expectSha`. Returns `undefined` when the file is gone from disk,
     * `expectSha` when it must stay in the baseline (I/O error), or the file's
     * fresh sha when it was edited since the scan.
     */
    async function _SessionMemoryStores_removeLocal2(store, rel, expectSha) {
      let freshSha;
      try {
        freshSha = await store.files.hashFile(rel);
      } catch (e) {
        if (!(e instanceof file_store_1.FileStoreError) && !isErrno(e))
          throw e;
        return expectSha;
      }
      if (freshSha === null)
        return void 0;
      if (freshSha !== expectSha)
        return freshSha;
      try {
        await store.files.remove(rel);
      } catch (e) {
        if (!(e instanceof file_store_1.FileStoreError) && !isErrno(e))
          throw e;
        tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("failed to remove memory deleted remotely", {
          path: rel,
          memory_store_id: store.memoryStoreId,
          error: String(e)
        });
        return expectSha;
      }
      return void 0;
    }, _SessionMemoryStores_write = /**
     * Write a memory's content to disk; `false` (and a warning) on failure.
     *
     * A `..` component in the wire path reaches here as {@link FileStoreError} —
     * that is the escape guard.
     */
    async function _SessionMemoryStores_write2(store, rel, content) {
      try {
        await store.files.put(rel, content);
      } catch (e) {
        if (!(e instanceof file_store_1.FileStoreError) && !isErrno(e))
          throw e;
        tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("failed to write memory", {
          path: rel,
          memory_store_id: store.memoryStoreId,
          error: String(e)
        });
        return false;
      }
      return true;
    }, _SessionMemoryStores_pullAll = /**
     * Fetch and write the given memories, {@link FETCH_CONCURRENCY} at a time.
     *
     * The sync's content pass: the listing carried no content, so each memory
     * is fetched individually and written as it arrives. On success the path's
     * baseline advances; on a failed fetch or write the old entry stays and the
     * next sync retries. A 404 means the memory was deleted after the listing —
     * the next sync reconciles it.
     */
    async function _SessionMemoryStores_pullAll2(store, pulls) {
      if (pulls.length === 0)
        return;
      const pullOne = async (rel, listed) => {
        let item;
        try {
          item = await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_client, "f").beta.memoryStores.memories.retrieve(listed.id, {
            memory_store_id: store.memoryStoreId,
            view: "full"
          });
        } catch (e) {
          if ((0, backoff_1.isStatus)(e, 404))
            return;
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("failed to fetch memory content", {
            path: rel,
            memory_store_id: store.memoryStoreId,
            error: String(e)
          });
          return;
        }
        if (await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_write).call(this, store, rel, item.content ?? "")) {
          store.baseline.set(rel, item.content_sha256);
        }
      };
      const queue = pulls[Symbol.iterator]();
      const worker = async () => {
        for (const [rel, listed] of queue)
          await pullOne(rel, listed);
      };
      await Promise.all(Array.from({ length: Math.min(FETCH_CONCURRENCY, pulls.length) }, worker));
    }, _SessionMemoryStores_uploadAll = /**
     * Upload the given files, {@link UPLOAD_CONCURRENCY} at a time, taking each
     * path off `unsent` as its upload returns. No upload starts once `signal`
     * aborts; the ones already in flight run to completion.
     */
    async function _SessionMemoryStores_uploadAll2(store, uploads, unsent, signal) {
      const queue = uploads[Symbol.iterator]();
      const worker = async () => {
        for (const [rel, localSha, existing] of queue) {
          if (signal?.aborted)
            return;
          const sha = await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_upload).call(this, store, rel, localSha, existing);
          unsent.delete(rel);
          if (sha !== void 0)
            store.baseline.set(rel, sha);
        }
      };
      await Promise.all(Array.from({ length: Math.min(exports2.UPLOAD_CONCURRENCY, uploads.length) }, worker));
    }, _SessionMemoryStores_listMemories = /**
     * The store's memories keyed by relative path (the wire path's leading `/`
     * stripped — `#upload` re-prefixes it) — `basic` view (shas, no content) at
     * {@link LIST_PAGE_SIZE} per page unless the caller needs `full` pages.
     * `memory_prefix` rollups and the reserved marker path are skipped.
     */
    async function* _SessionMemoryStores_listMemories2(memoryStoreId, view = "basic") {
      const limit = view === "basic" ? LIST_PAGE_SIZE : FULL_LIST_PAGE_SIZE;
      for await (const item of tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_client, "f").beta.memoryStores.memories.list(memoryStoreId, { view, limit })) {
        if (item.type !== "memory")
          continue;
        const rel = item.path.replace(/^\/+/, "");
        if (rel === exports2.MARKER_PATH) {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("the server listed the reserved marker path; skipping", {
            path: item.path,
            memory_store_id: memoryStoreId
          });
          continue;
        }
        yield [rel, item];
      }
    }, _SessionMemoryStores_upload = /**
     * Push one local file; `undefined` keeps the old baseline so the next pass retries.
     *
     * A refusal the server would repeat (400/413, the utf-8 gate) enters
     * `refusedShas`: warned once, retried only after the file changes.
     */
    async function _SessionMemoryStores_upload2(store, rel, localSha, existing) {
      try {
        const data = await store.files.get(rel);
        if (data === null)
          return void 0;
        const content = (0, bytes_1.decodeUTF8)(data);
        const item = existing ? await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_client, "f").beta.memoryStores.memories.update(existing.id, {
          memory_store_id: store.memoryStoreId,
          content,
          precondition: { type: "content_sha256", content_sha256: existing.content_sha256 }
        }) : await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_client, "f").beta.memoryStores.memories.create(store.memoryStoreId, {
          path: "/" + rel,
          content
        });
        store.refusedShas.delete(rel);
        return item.content_sha256;
      } catch (e) {
        if (existing && (0, backoff_1.isStatus)(e, 404)) {
          return await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_upload2).call(this, store, rel, localSha, void 0);
        }
        const permanent = e instanceof file_store_1.FileStoreError || (0, backoff_1.isStatus)(e, 400) || (0, backoff_1.isStatus)(e, 413);
        if (existing && (0, backoff_1.isStatus)(e, 409)) {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("memory changed both locally and remotely; the upload was refused and the local edit loses", {
            path: rel,
            memory_store_id: store.memoryStoreId
          });
        } else if (permanent && localSha !== void 0) {
          store.refusedShas.set(rel, localSha);
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("the server rejected this memory file, so it stays un-synced until its content changes", { path: rel, memory_store_id: store.memoryStoreId, rejection: String(e) });
        } else {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("failed to upload memory", {
            path: rel,
            memory_store_id: store.memoryStoreId,
            error: String(e)
          });
        }
        return void 0;
      }
    }, _SessionMemoryStores_corroboratedDelete = /** Send the server delete only after the wait, the cap, and a fresh re-check all clear. */
    async function _SessionMemoryStores_corroboratedDelete2(store, rel, remote, baseSha, deletes) {
      if (deletes.mode === "disabled") {
        deletes.suppressed++;
        return baseSha;
      }
      let firstAbsent = store.pendingDeletes.get(rel);
      if (firstAbsent === void 0) {
        firstAbsent = Date.now();
        store.pendingDeletes.set(rel, firstAbsent);
      }
      if (!deletes.waiveWindow && Date.now() - firstAbsent < exports2.DELETE_CORROBORATION_MS) {
        return baseSha;
      }
      let markerOk;
      let stillAbsent;
      try {
        markerOk = await store.files.hashFile(exports2.MARKER_PATH) === markerSha(store.memoryStoreId);
        stillAbsent = await store.files.hashFile(rel) === null;
      } catch (e) {
        if (!(e instanceof file_store_1.FileStoreError) && !isErrno(e))
          throw e;
        markerOk = stillAbsent = false;
      }
      if (!markerOk)
        return baseSha;
      if (!stillAbsent) {
        store.pendingDeletes.delete(rel);
        return baseSha;
      }
      if (!deletes.takeSlot())
        return baseSha;
      if (deletes.mode === "log_only") {
        tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").info("log-only: sync would delete this memory on the server", {
          path: rel,
          memory_store_id: store.memoryStoreId
        });
        return baseSha;
      }
      const sha = await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_instances, "m", _SessionMemoryStores_deleteRemote).call(this, store, rel, remote, baseSha);
      if (sha === void 0) {
        store.pendingDeletes.delete(rel);
      }
      return sha;
    }, _SessionMemoryStores_deleteRemote = async function _SessionMemoryStores_deleteRemote2(store, rel, remote, baseSha) {
      try {
        await tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_client, "f").beta.memoryStores.memories.delete(remote.id, {
          memory_store_id: store.memoryStoreId,
          expected_content_sha256: baseSha
        });
      } catch (e) {
        if ((0, backoff_1.isStatus)(e, 404))
          return void 0;
        if ((0, backoff_1.isStatus)(e, 409) || (0, backoff_1.isStatus)(e, 412)) {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("memory deleted locally but changed remotely; keeping the remote version", {
            path: rel,
            memory_store_id: store.memoryStoreId
          });
        } else {
          tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").warn("failed to delete memory", {
            path: rel,
            memory_store_id: store.memoryStoreId,
            error: String(e)
          });
        }
        return baseSha;
      }
      tslib_1.__classPrivateFieldGet(this, _SessionMemoryStores_log, "f").info("propagated local deletion", { path: rel, memory_store_id: store.memoryStoreId });
      return void 0;
    };
    function isErrno(e) {
      return typeof e === "object" && e !== null && typeof e.code === "string";
    }
    async function settledOrAborted(p, signal) {
      if (!signal) {
        await p;
        return;
      }
      let onAbort;
      const aborted = new Promise((resolve) => {
        onAbort = resolve;
        if (signal.aborted)
          resolve();
      });
      signal.addEventListener("abort", onAbort, { once: true });
      try {
        await Promise.race([p, aborted]);
      } finally {
        signal.removeEventListener("abort", onAbort);
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/tools/agent-toolset/node.js
var require_node2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/tools/agent-toolset/node.js"(exports2) {
    "use strict";
    var _BashSession_instances;
    var _BashSession_proc;
    var _BashSession_buf;
    var _BashSession_truncated;
    var _BashSession_closed;
    var _BashSession_waiting;
    var _BashSession_append;
    var _LineRangeCollector_instances;
    var _LineRangeCollector_filePath;
    var _LineRangeCollector_startLine;
    var _LineRangeCollector_endLine;
    var _LineRangeCollector_start;
    var _LineRangeCollector_end;
    var _LineRangeCollector_limit;
    var _LineRangeCollector_line;
    var _LineRangeCollector_collected;
    var _LineRangeCollector_collectedBytes;
    var _LineRangeCollector_collect;
    var _LineRangeCollector_overLimitError;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BashSession = exports2.BashTimeoutError = exports2.MARKER_PATH = exports2.MEMORY_FLUSH_TIMEOUT_MS = exports2.MIN_MEMORY_SYNC_INTERVAL_MS = exports2.DEFAULT_MEMORY_SYNC_INTERVAL_MS = exports2.SessionMemoryError = exports2.SessionMemoryStores = exports2.extractSkillArchive = exports2.setupSkills = void 0;
    exports2.betaAgentToolset20260401 = betaAgentToolset20260401;
    exports2.resolvePath = resolvePath;
    exports2.betaBashTool = betaBashTool;
    exports2.betaReadTool = betaReadTool;
    exports2.betaWriteTool = betaWriteTool;
    exports2.betaEditTool = betaEditTool;
    exports2.betaGlobTool = betaGlobTool;
    exports2.betaGrepTool = betaGrepTool;
    var tslib_1 = require_tslib();
    var fs2 = tslib_1.__importStar(require("node:fs/promises"));
    var fssync = tslib_1.__importStar(require("node:fs"));
    var path2 = tslib_1.__importStar(require("node:path"));
    var cp = tslib_1.__importStar(require("node:child_process"));
    var crypto2 = tslib_1.__importStar(require("node:crypto"));
    var readline = tslib_1.__importStar(require("node:readline"));
    var error_1 = require_error();
    var ToolError_1 = require_ToolError();
    var json_schema_1 = require_json_schema();
    var promise_1 = require_promise();
    var fs_util_1 = require_fs_util();
    var skills_1 = require_skills();
    Object.defineProperty(exports2, "setupSkills", { enumerable: true, get: function() {
      return skills_1.setupSkills;
    } });
    Object.defineProperty(exports2, "extractSkillArchive", { enumerable: true, get: function() {
      return skills_1.extractSkillArchive;
    } });
    var memories_1 = require_memories();
    Object.defineProperty(exports2, "SessionMemoryStores", { enumerable: true, get: function() {
      return memories_1.SessionMemoryStores;
    } });
    Object.defineProperty(exports2, "SessionMemoryError", { enumerable: true, get: function() {
      return memories_1.SessionMemoryError;
    } });
    Object.defineProperty(exports2, "DEFAULT_MEMORY_SYNC_INTERVAL_MS", { enumerable: true, get: function() {
      return memories_1.DEFAULT_MEMORY_SYNC_INTERVAL_MS;
    } });
    Object.defineProperty(exports2, "MIN_MEMORY_SYNC_INTERVAL_MS", { enumerable: true, get: function() {
      return memories_1.MIN_MEMORY_SYNC_INTERVAL_MS;
    } });
    Object.defineProperty(exports2, "MEMORY_FLUSH_TIMEOUT_MS", { enumerable: true, get: function() {
      return memories_1.MEMORY_FLUSH_TIMEOUT_MS;
    } });
    Object.defineProperty(exports2, "MARKER_PATH", { enumerable: true, get: function() {
      return memories_1.MARKER_PATH;
    } });
    var BASH_OUTPUT_LIMIT = 100 * 1024;
    var BASH_DEFAULT_TIMEOUT_MS = 12e4;
    var DEFAULT_MAX_FILE_BYTES = 256 * 1024;
    var READ_STREAM_CHUNK_BYTES = 64 * 1024;
    var NEWLINE = Buffer.from("\n");
    var GREP_OUTPUT_LIMIT = 100 * 1024;
    var GREP_MAX_LINE_LENGTH = 2e3;
    var GLOB_RESULT_LIMIT = 200;
    var BashTimeoutError = class extends error_1.AnthropicError {
      constructor(timeoutMs) {
        super(`bash command timed out after ${timeoutMs}ms`);
        this.name = "BashTimeoutError";
        this.timeoutMs = timeoutMs;
      }
    };
    exports2.BashTimeoutError = BashTimeoutError;
    var ANSI_RE = /\x1b\[[0-9;?]*[ -/]*[@-~]/g;
    var fsGlob = fs2.glob;
    function resolveMaxBytes(configured) {
      return configured === void 0 ? DEFAULT_MAX_FILE_BYTES : configured;
    }
    function rejectUnrestrictedPaths(value) {
      if (value === void 0)
        return;
      throw new error_1.AnthropicError("The `unrestrictedPaths` option you passed to the agent toolset (AgentToolContext) is no longer supported. The toolset's file tools (read, write, edit, glob, grep) are now always confined to the working directory plus the directories listed in `allowedRoots`. Remove `unrestrictedPaths` from your context; to let the file tools reach any other directory, add it to `allowedRoots`.");
    }
    function betaAgentToolset20260401(ctx) {
      return [
        betaBashTool(ctx),
        betaReadTool(ctx),
        betaWriteTool(ctx),
        betaEditTool(ctx),
        betaGlobTool(ctx),
        betaGrepTool(ctx)
      ];
    }
    async function resolvePath(ctx, p) {
      rejectUnrestrictedPaths(ctx.unrestrictedPaths);
      return (0, fs_util_1.confineToRoot)(ctx.workdir, p, { allowedRoots: ctx.allowedRoots ?? [] });
    }
    function readOnlyRootFor(ctx, target) {
      return (0, fs_util_1.containingRoot)(ctx.readOnlyRoots ?? [], target);
    }
    function scrubbedShellEnv() {
      const env = {};
      for (const [key, value] of Object.entries(process.env)) {
        if (key.startsWith("ANTHROPIC_"))
          continue;
        env[key] = value;
      }
      return env;
    }
    var BashSession = /* @__PURE__ */ (() => {
      class BashSession2 {
        constructor(dir, env = scrubbedShellEnv()) {
          _BashSession_instances.add(this);
          _BashSession_proc.set(this, void 0);
          _BashSession_buf.set(this, "");
          _BashSession_truncated.set(this, false);
          _BashSession_closed.set(this, false);
          _BashSession_waiting.set(this, null);
          tslib_1.__classPrivateFieldSet(this, _BashSession_proc, cp.spawn("/bin/bash", ["--noprofile", "--norc"], {
            cwd: dir,
            // `env` is the full base environment (the scrubbed process env by
            // default, or the verbatim replacement from `AgentToolContext.env`).
            // PS1/PS2/TERM are shell-control settings BashSession always applies so
            // the pipe-based sentinel exec parsing works — not part of the
            // user-facing environment.
            env: { ...env, PS1: "", PS2: "", TERM: "dumb" },
            stdio: ["pipe", "pipe", "pipe"],
            detached: true
          }), "f");
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stdout.setEncoding("utf8");
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stderr.setEncoding("utf8");
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stdout.on("data", (d) => tslib_1.__classPrivateFieldGet(this, _BashSession_instances, "m", _BashSession_append).call(this, d));
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stderr.on("data", (d) => tslib_1.__classPrivateFieldGet(this, _BashSession_instances, "m", _BashSession_append).call(this, d));
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").once("close", () => {
            tslib_1.__classPrivateFieldSet(this, _BashSession_closed, true, "f");
            const w = tslib_1.__classPrivateFieldGet(this, _BashSession_waiting, "f");
            tslib_1.__classPrivateFieldSet(this, _BashSession_waiting, null, "f");
            w?.resolve();
          });
        }
        /** Whether the underlying shell process has exited. */
        get closed() {
          return tslib_1.__classPrivateFieldGet(this, _BashSession_closed, "f");
        }
        async exec(command, opts = {}) {
          if (tslib_1.__classPrivateFieldGet(this, _BashSession_closed, "f")) {
            throw new error_1.AnthropicError("bash session terminated");
          }
          const timeoutMs = opts.timeoutMs ?? BASH_DEFAULT_TIMEOUT_MS;
          const signal = opts.signal;
          signal?.throwIfAborted();
          tslib_1.__classPrivateFieldSet(this, _BashSession_buf, "", "f");
          tslib_1.__classPrivateFieldSet(this, _BashSession_truncated, false, "f");
          const sentinel = `__ANT_CMD_${crypto2.randomUUID()}_DONE__`;
          const sentinelSplit = `${sentinel.slice(0, 8)}''${sentinel.slice(8)}`;
          const wrapped = `{ ${command}
} </dev/null 2>&1; printf '\\n${sentinelSplit}%d\\n' $?
`;
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stdin.write(wrapped);
          if (tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").indexOf(sentinel) < 0) {
            const { promise: sentinelSeen, resolve } = (0, promise_1.promiseWithResolvers)();
            tslib_1.__classPrivateFieldSet(this, _BashSession_waiting, { sentinel, resolve }, "f");
            let timer;
            let onAbort;
            try {
              await Promise.race([
                sentinelSeen,
                new Promise((_, reject) => {
                  timer = setTimeout(() => reject(new BashTimeoutError(timeoutMs)), timeoutMs);
                }),
                new Promise((_, reject) => {
                  if (!signal)
                    return;
                  onAbort = () => reject(signal.reason);
                  signal.addEventListener("abort", onAbort, { once: true });
                })
              ]);
            } finally {
              if (timer)
                clearTimeout(timer);
              if (onAbort && signal)
                signal.removeEventListener("abort", onAbort);
              tslib_1.__classPrivateFieldSet(this, _BashSession_waiting, null, "f");
            }
          }
          const idx = tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").indexOf(sentinel);
          if (idx < 0) {
            throw new error_1.AnthropicError("bash session terminated");
          }
          const tail = tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").slice(idx + sentinel.length);
          const m = tail.match(/^(-?\d+)/);
          const exitCode = m ? parseInt(m[1], 10) : -1;
          let out = tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").slice(0, idx).replace(ANSI_RE, "").replace(/\n+$/, "");
          if (tslib_1.__classPrivateFieldGet(this, _BashSession_truncated, "f")) {
            out = `[output truncated]
${out}`;
          }
          return { output: out, exitCode };
        }
        close() {
          if (tslib_1.__classPrivateFieldGet(this, _BashSession_closed, "f"))
            return;
          tslib_1.__classPrivateFieldSet(this, _BashSession_closed, true, "f");
          const w = tslib_1.__classPrivateFieldGet(this, _BashSession_waiting, "f");
          tslib_1.__classPrivateFieldSet(this, _BashSession_waiting, null, "f");
          w?.resolve();
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stdout.destroy();
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stderr.destroy();
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stdin.destroy();
          try {
            process.kill(-tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").pid, "SIGKILL");
          } catch {
            tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").kill("SIGKILL");
          }
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").unref();
        }
      }
      _BashSession_proc = /* @__PURE__ */ new WeakMap(), _BashSession_buf = /* @__PURE__ */ new WeakMap(), _BashSession_truncated = /* @__PURE__ */ new WeakMap(), _BashSession_closed = /* @__PURE__ */ new WeakMap(), _BashSession_waiting = /* @__PURE__ */ new WeakMap(), _BashSession_instances = /* @__PURE__ */ new WeakSet(), _BashSession_append = function _BashSession_append2(d) {
        tslib_1.__classPrivateFieldSet(this, _BashSession_buf, tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f") + d, "f");
        if (tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").length > BASH_OUTPUT_LIMIT) {
          tslib_1.__classPrivateFieldSet(this, _BashSession_buf, tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").slice(tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").length - BASH_OUTPUT_LIMIT), "f");
          tslib_1.__classPrivateFieldSet(this, _BashSession_truncated, true, "f");
        }
        if (tslib_1.__classPrivateFieldGet(this, _BashSession_waiting, "f") && tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").indexOf(tslib_1.__classPrivateFieldGet(this, _BashSession_waiting, "f").sentinel) >= 0) {
          const w = tslib_1.__classPrivateFieldGet(this, _BashSession_waiting, "f");
          tslib_1.__classPrivateFieldSet(this, _BashSession_waiting, null, "f");
          w.resolve();
        }
      };
      return BashSession2;
    })();
    exports2.BashSession = BashSession;
    function betaBashTool(ctx) {
      rejectUnrestrictedPaths(ctx.unrestrictedPaths);
      let session;
      let tail = Promise.resolve();
      return (0, json_schema_1.betaTool)({
        name: "bash",
        description: "Run a bash command in a persistent shell. State (cwd, env vars) persists across calls.",
        inputSchema: {
          type: "object",
          properties: {
            command: { type: "string", description: "The command to run" },
            restart: { type: "boolean", description: "Restart the persistent shell before running" },
            timeout_ms: { type: "integer", description: "Per-call timeout in milliseconds" }
          }
        },
        run: async ({ command, restart, timeout_ms }, context) => {
          const prev = tail;
          const gate = (0, promise_1.promiseWithResolvers)();
          tail = gate.promise;
          try {
            await prev;
          } catch {
          }
          try {
            if (restart) {
              session?.close();
              session = void 0;
            }
            if (!command) {
              if (restart)
                return "bash session restarted";
              throw new ToolError_1.ToolError("bash: command is required");
            }
            session ?? (session = new BashSession(ctx.workdir, ctx.env));
            try {
              const { output, exitCode } = await session.exec(command, {
                timeoutMs: timeout_ms ?? BASH_DEFAULT_TIMEOUT_MS,
                signal: context?.signal
              });
              if (exitCode !== 0)
                throw new ToolError_1.ToolError(output || `exit ${exitCode}`);
              return output;
            } catch (e) {
              if (e instanceof ToolError_1.ToolError)
                throw e;
              session.close();
              session = void 0;
              throw new ToolError_1.ToolError(`bash: ${e instanceof Error ? e.message : String(e)}`);
            }
          } finally {
            gate.resolve();
          }
        },
        close: () => {
          session?.close();
          session = void 0;
        }
      });
    }
    function betaReadTool(ctx) {
      rejectUnrestrictedPaths(ctx.unrestrictedPaths);
      return (0, json_schema_1.betaTool)({
        name: "read",
        description: "Read a UTF-8 text file relative to the workdir.",
        inputSchema: {
          type: "object",
          properties: {
            file_path: { type: "string" },
            view_range: {
              type: "array",
              items: { type: "integer" },
              description: "[start_line, end_line] 1-indexed inclusive"
            }
          },
          required: ["file_path"]
        },
        run: async ({ file_path, view_range }) => {
          if (!file_path)
            throw new ToolError_1.ToolError("read: file_path is required");
          const abs = await resolvePath(ctx, file_path);
          if (view_range?.length && view_range.length !== 2) {
            throw new ToolError_1.ToolError("read: view_range must be [start_line, end_line]");
          }
          let data;
          try {
            const st = await fs2.stat(abs);
            if (!st.isFile()) {
              throw new ToolError_1.ToolError(`read: ${file_path} is not a regular file`);
            }
            const limit = resolveMaxBytes(ctx.maxFileBytes);
            if (limit !== null && st.size > limit) {
              if (!view_range?.length) {
                throw new ToolError_1.ToolError(`read: ${file_path} is ${st.size} bytes, exceeds ${limit}-byte limit. Use the view_range parameter to read specific line ranges, e.g. view_range: [1, 500].`);
              }
              const [startLine2, endLine2] = view_range;
              return await readRangeStreaming(abs, file_path, startLine2, endLine2, limit);
            }
            data = await fs2.readFile(abs, "utf8");
          } catch (e) {
            if (e instanceof ToolError_1.ToolError)
              throw e;
            throw new ToolError_1.ToolError(`read: ${(0, fs_util_1.fsErrorMessage)(e, file_path)}`);
          }
          if (!view_range?.length)
            return data;
          const [startLine, endLine] = view_range;
          const lines = data.split("\n");
          const start = Math.max(0, startLine - 1);
          const end = endLine > 0 ? endLine : lines.length;
          return lines.slice(start, end).join("\n");
        }
      });
    }
    async function readRangeStreaming(abs, filePath, startLine, endLine, limit) {
      const lines = new LineRangeCollector(filePath, startLine, endLine, limit);
      if (lines.rangeIsEmpty())
        return "";
      const stream = fssync.createReadStream(abs, { highWaterMark: READ_STREAM_CHUNK_BYTES });
      try {
        for await (const chunk of stream) {
          lines.collectFrom(chunk);
          if (lines.rangeIsCollected())
            break;
        }
      } finally {
        stream.destroy();
      }
      return lines.text();
    }
    var LineRangeCollector = class {
      constructor(filePath, startLine, endLine, limit) {
        _LineRangeCollector_instances.add(this);
        _LineRangeCollector_filePath.set(this, void 0);
        _LineRangeCollector_startLine.set(this, void 0);
        _LineRangeCollector_endLine.set(this, void 0);
        _LineRangeCollector_start.set(this, void 0);
        _LineRangeCollector_end.set(this, void 0);
        _LineRangeCollector_limit.set(this, void 0);
        _LineRangeCollector_line.set(this, 0);
        _LineRangeCollector_collected.set(this, []);
        _LineRangeCollector_collectedBytes.set(this, 0);
        tslib_1.__classPrivateFieldSet(this, _LineRangeCollector_filePath, filePath, "f");
        tslib_1.__classPrivateFieldSet(this, _LineRangeCollector_startLine, startLine, "f");
        tslib_1.__classPrivateFieldSet(this, _LineRangeCollector_endLine, endLine, "f");
        tslib_1.__classPrivateFieldSet(this, _LineRangeCollector_start, Math.max(0, startLine - 1), "f");
        tslib_1.__classPrivateFieldSet(this, _LineRangeCollector_end, endLine > 0 ? endLine : Infinity, "f");
        tslib_1.__classPrivateFieldSet(this, _LineRangeCollector_limit, limit, "f");
      }
      rangeIsEmpty() {
        return tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_end, "f") <= tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_start, "f");
      }
      rangeIsCollected() {
        return tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_line, "f") >= tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_end, "f");
      }
      collectFrom(chunk) {
        var _a;
        let lineStart = 0;
        while (lineStart < chunk.length && !this.rangeIsCollected()) {
          const newline = chunk.indexOf(10, lineStart);
          const lineEnd = newline < 0 ? chunk.length : newline;
          if (tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_line, "f") >= tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_start, "f")) {
            tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_instances, "m", _LineRangeCollector_collect).call(this, chunk.subarray(lineStart, lineEnd), newline >= 0);
          }
          if (newline < 0)
            break;
          tslib_1.__classPrivateFieldSet(this, _LineRangeCollector_line, (_a = tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_line, "f"), _a++, _a), "f");
          lineStart = newline + 1;
        }
      }
      text() {
        return Buffer.concat(tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_collected, "f"), tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_collectedBytes, "f")).toString("utf8");
      }
    };
    _LineRangeCollector_filePath = /* @__PURE__ */ new WeakMap(), _LineRangeCollector_startLine = /* @__PURE__ */ new WeakMap(), _LineRangeCollector_endLine = /* @__PURE__ */ new WeakMap(), _LineRangeCollector_start = /* @__PURE__ */ new WeakMap(), _LineRangeCollector_end = /* @__PURE__ */ new WeakMap(), _LineRangeCollector_limit = /* @__PURE__ */ new WeakMap(), _LineRangeCollector_line = /* @__PURE__ */ new WeakMap(), _LineRangeCollector_collected = /* @__PURE__ */ new WeakMap(), _LineRangeCollector_collectedBytes = /* @__PURE__ */ new WeakMap(), _LineRangeCollector_instances = /* @__PURE__ */ new WeakSet(), _LineRangeCollector_collect = function _LineRangeCollector_collect2(lineBytes, newlineTerminated) {
      tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_collected, "f").push(lineBytes);
      tslib_1.__classPrivateFieldSet(this, _LineRangeCollector_collectedBytes, tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_collectedBytes, "f") + lineBytes.length, "f");
      if (newlineTerminated && tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_line, "f") + 1 < tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_end, "f")) {
        tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_collected, "f").push(NEWLINE);
        tslib_1.__classPrivateFieldSet(this, _LineRangeCollector_collectedBytes, tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_collectedBytes, "f") + NEWLINE.length, "f");
      }
      if (tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_collectedBytes, "f") > tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_limit, "f"))
        throw tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_instances, "m", _LineRangeCollector_overLimitError).call(this);
    }, _LineRangeCollector_overLimitError = function _LineRangeCollector_overLimitError2() {
      if (tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_end, "f") - tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_start, "f") === 1) {
        return new ToolError_1.ToolError(`read: line ${tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_start, "f") + 1} of ${tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_filePath, "f")} alone exceeds ${tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_limit, "f")}-byte limit. The read tool cannot return part of a line, so view_range cannot narrow this further.`);
      }
      return new ToolError_1.ToolError(`read: view_range [${tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_startLine, "f")}, ${tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_endLine, "f")}] of ${tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_filePath, "f")} exceeds ${tslib_1.__classPrivateFieldGet(this, _LineRangeCollector_limit, "f")}-byte limit. Narrow the view_range to read a smaller portion.`);
    };
    function betaWriteTool(ctx) {
      rejectUnrestrictedPaths(ctx.unrestrictedPaths);
      return (0, json_schema_1.betaTool)({
        name: "write",
        description: "Write a UTF-8 text file relative to the workdir, creating parent directories as needed.",
        inputSchema: {
          type: "object",
          properties: { file_path: { type: "string" }, content: { type: "string" } },
          required: ["file_path", "content"]
        },
        run: async ({ file_path, content }) => {
          if (!file_path)
            throw new ToolError_1.ToolError("write: file_path is required");
          const abs = await resolvePath(ctx, file_path);
          const ro = await readOnlyRootFor(ctx, abs);
          if (ro !== void 0) {
            throw new ToolError_1.ToolError(`write: ${file_path} is inside read-only directory ${ro}`);
          }
          try {
            await fs2.mkdir(path2.dirname(abs), { recursive: true, mode: fs_util_1.DIR_CREATE_MODE });
            await (0, fs_util_1.atomicWriteFile)(abs, content ?? "");
          } catch (e) {
            throw new ToolError_1.ToolError(`write: ${(0, fs_util_1.fsErrorMessage)(e, file_path)}`);
          }
          return `wrote ${Buffer.byteLength(content ?? "")} bytes to ${file_path}`;
        }
      });
    }
    function betaEditTool(ctx) {
      rejectUnrestrictedPaths(ctx.unrestrictedPaths);
      return (0, json_schema_1.betaTool)({
        name: "edit",
        description: "Replace old_string with new_string in a file. old_string must be unique unless replace_all.",
        inputSchema: {
          type: "object",
          properties: {
            file_path: { type: "string" },
            old_string: { type: "string" },
            new_string: { type: "string" },
            replace_all: { type: "boolean" }
          },
          required: ["file_path", "old_string", "new_string"]
        },
        run: async ({ file_path, old_string, new_string, replace_all }) => {
          if (!file_path)
            throw new ToolError_1.ToolError("edit: file_path is required");
          if (!old_string)
            throw new ToolError_1.ToolError("edit: old_string is required");
          const abs = await resolvePath(ctx, file_path);
          const ro = await readOnlyRootFor(ctx, abs);
          if (ro !== void 0) {
            throw new ToolError_1.ToolError(`edit: ${file_path} is inside read-only directory ${ro}`);
          }
          let data;
          try {
            const st = await fs2.stat(abs);
            if (!st.isFile()) {
              throw new ToolError_1.ToolError(`edit: ${file_path} is not a regular file`);
            }
            const limit = resolveMaxBytes(ctx.maxFileBytes);
            if (limit !== null && st.size > limit) {
              throw new ToolError_1.ToolError(`edit: ${file_path} is ${st.size} bytes, exceeds ${limit}-byte limit. The edit tool loads the whole file and cannot modify a file this large.`);
            }
            data = await fs2.readFile(abs, "utf8");
          } catch (e) {
            if (e instanceof ToolError_1.ToolError)
              throw e;
            throw new ToolError_1.ToolError(`edit: ${(0, fs_util_1.fsErrorMessage)(e, file_path)}`);
          }
          const count = data.split(old_string).length - 1;
          if (count === 0)
            throw new ToolError_1.ToolError(`edit: old_string not found in ${file_path}`);
          let updated;
          if (replace_all) {
            updated = data.split(old_string).join(new_string);
          } else {
            if (count > 1)
              throw new ToolError_1.ToolError(`edit: old_string appears ${count} times in ${file_path} (must be unique)`);
            updated = data.replace(old_string, () => new_string);
          }
          try {
            await (0, fs_util_1.atomicWriteFile)(abs, updated);
          } catch (e) {
            throw new ToolError_1.ToolError(`edit: write: ${(0, fs_util_1.fsErrorMessage)(e, file_path)}`);
          }
          return `edited ${file_path} (${replace_all ? count : 1} replacement(s))`;
        }
      });
    }
    function patternCanAscend(pattern) {
      return pattern.split(/[\\/{},]/).includes("..");
    }
    function betaGlobTool(ctx) {
      rejectUnrestrictedPaths(ctx.unrestrictedPaths);
      return (0, json_schema_1.betaTool)({
        name: "glob",
        description: "Match files under the workdir against a glob pattern. Results are mtime-sorted, newest first.",
        inputSchema: {
          type: "object",
          properties: {
            pattern: { type: "string" },
            path: { type: "string", description: "Directory to search in. Defaults to the workdir." }
          },
          required: ["pattern"]
        },
        run: async ({ pattern, path: searchPath }) => {
          if (!pattern)
            throw new ToolError_1.ToolError("glob: pattern is required");
          if (path2.isAbsolute(pattern)) {
            throw new ToolError_1.ToolError("glob: absolute pattern not permitted; pass a relative pattern (and optionally path)");
          }
          if (patternCanAscend(pattern)) {
            throw new ToolError_1.ToolError('glob: ".." is not permitted in the pattern');
          }
          const root = searchPath ? await resolvePath(ctx, searchPath) : path2.resolve(ctx.workdir);
          const realRoot = searchPath ? root : await (0, fs_util_1.canonicalize)(root);
          const matches = [];
          let remaining = WALK_MAX_ENTRIES;
          try {
            for await (const entry of fsGlob(pattern, {
              cwd: root,
              withFileTypes: true,
              exclude: (d) => d.name === ".git" || d.name === "node_modules"
            })) {
              if (remaining-- <= 0)
                break;
              if (!entry.isFile())
                continue;
              const full = path2.join(entry.parentPath, entry.name);
              let real;
              try {
                real = await fs2.realpath(full);
              } catch {
                continue;
              }
              if (!(0, fs_util_1.isWithin)(realRoot, real))
                continue;
              let mtime = 0;
              try {
                mtime = (await fs2.stat(full)).mtimeMs;
              } catch {
              }
              matches.push({ path: full, mtime });
            }
          } catch (e) {
            throw new ToolError_1.ToolError(`glob: ${e instanceof Error ? e.message : String(e)}`);
          }
          if (matches.length === 0)
            return "no matches";
          matches.sort((a, b) => b.mtime - a.mtime);
          return matches.slice(0, GLOB_RESULT_LIMIT).map((m) => m.path).join("\n");
        }
      });
    }
    function betaGrepTool(ctx) {
      rejectUnrestrictedPaths(ctx.unrestrictedPaths);
      return (0, json_schema_1.betaTool)({
        name: "grep",
        description: "Search file contents for a regex. Uses ripgrep if available, otherwise a built-in walker.",
        inputSchema: {
          type: "object",
          properties: { pattern: { type: "string" }, path: { type: "string" } },
          required: ["pattern"]
        },
        run: async ({ pattern, path: p }, context) => {
          if (!pattern)
            throw new ToolError_1.ToolError("grep: pattern is required");
          let searchPath = path2.resolve(ctx.workdir);
          if (p)
            searchPath = await resolvePath(ctx, p);
          const rg = await findRg();
          return rg ? runRipgrep(rg, pattern, searchPath, context?.signal) : runWalkGrep(pattern, searchPath, context?.signal);
        }
      });
    }
    function runRipgrep(rg, pattern, searchPath, signal) {
      return new Promise((resolve, reject) => {
        const proc = cp.spawn(rg, ["-n", "--no-heading", "-e", pattern, "--", searchPath], {
          ...signal ? { signal } : {}
        });
        let out = "";
        let errOut = "";
        let truncated = false;
        proc.stdout.on("data", (d) => {
          if (truncated)
            return;
          out += d;
          if (out.length > GREP_OUTPUT_LIMIT) {
            truncated = true;
            out = out.slice(0, GREP_OUTPUT_LIMIT);
            proc.kill("SIGKILL");
          }
        });
        proc.stderr.on("data", (d) => errOut += d);
        proc.on("close", (code) => {
          if (signal?.aborted)
            return reject(new ToolError_1.ToolError("grep: aborted"));
          if (truncated)
            return resolve(out + `
[output truncated at ${GREP_OUTPUT_LIMIT} bytes]`);
          if (code === 0)
            return resolve(out);
          if (code === 1)
            return resolve("no matches");
          reject(new ToolError_1.ToolError(`grep: rg failed: ${errOut || `exit ${code}`}`));
        });
        proc.on("error", (e) => {
          if (signal?.aborted)
            return reject(new ToolError_1.ToolError("grep: aborted"));
          reject(new ToolError_1.ToolError(`grep: rg failed: ${e.message}`));
        });
      });
    }
    async function runWalkGrep(pattern, root, signal) {
      let re;
      try {
        re = new RegExp(pattern);
      } catch (e) {
        throw new ToolError_1.ToolError(`grep: invalid regex: ${e instanceof Error ? e.message : String(e)}`);
      }
      const hits = [];
      let budget = GREP_OUTPUT_LIMIT;
      const push = (line) => {
        budget -= line.length + 1;
        if (budget < 0) {
          hits.push(`[output truncated at ${GREP_OUTPUT_LIMIT} bytes]`);
          return false;
        }
        hits.push(line);
        return true;
      };
      const stat = await fs2.stat(root).catch(() => null);
      if (stat?.isFile()) {
        await grepFile(root, re, push);
      } else {
        await walk(root, "", (rel) => grepFile(path2.join(root, rel), re, push), signal);
      }
      if (signal?.aborted)
        throw new ToolError_1.ToolError("grep: aborted");
      if (hits.length === 0)
        return "no matches";
      return hits.join("\n");
    }
    async function grepFile(file, re, push) {
      const stream = fssync.createReadStream(file, { encoding: "utf8" });
      const rl = readline.createInterface({ input: stream, crlfDelay: Infinity });
      let i = 0;
      try {
        for await (const line of rl) {
          i++;
          if (line.length > GREP_MAX_LINE_LENGTH)
            continue;
          if (re.test(line) && !push(`${file}:${i}:${line}`))
            return false;
        }
      } catch {
      } finally {
        stream.destroy();
      }
      return true;
    }
    var WALK_MAX_DEPTH = 40;
    var WALK_MAX_ENTRIES = 5e4;
    async function walk(root, rel, fn, signal) {
      let remaining = WALK_MAX_ENTRIES;
      async function inner(rel2, depth) {
        if (depth > WALK_MAX_DEPTH)
          return true;
        if (signal?.aborted)
          return false;
        let entries;
        try {
          entries = await fs2.readdir(path2.join(root, rel2), { withFileTypes: true });
        } catch {
          return true;
        }
        for (const e of entries) {
          if (e.name === ".git" || e.name === "node_modules")
            continue;
          if (remaining-- <= 0)
            return false;
          if (signal?.aborted)
            return false;
          const childRel = rel2 ? path2.join(rel2, e.name) : e.name;
          if (e.isDirectory()) {
            if (!await inner(childRel, depth + 1))
              return false;
          } else if (e.isFile()) {
            if (await fn(childRel) === false)
              return false;
          }
        }
        return true;
      }
      await inner(rel, 0);
    }
    async function findRg() {
      const dirs = (process.env["PATH"] ?? "").split(path2.delimiter);
      for (const d of dirs) {
        const candidate = path2.join(d, "rg");
        try {
          await fs2.access(candidate, fssync.constants.X_OK);
          return candidate;
        } catch {
        }
      }
      return null;
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/environments/worker.js
var require_worker = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/environments/worker.js"(exports2) {
    "use strict";
    var _EnvironmentWorker_instances;
    var _EnvironmentWorker_signal;
    var _EnvironmentWorker_handleItem;
    var _Lease_ctrl;
    var _Lease_endReason;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EnvironmentWorker = void 0;
    exports2.sessionsTokenFromSecret = sessionsTokenFromSecret;
    var tslib_1 = require_tslib();
    var error_1 = require_error();
    var log_1 = require_log();
    var base64_1 = require_base64();
    var bytes_1 = require_bytes();
    var env_1 = require_env();
    var sleep_1 = require_sleep();
    var backoff_1 = require_backoff();
    var abort_1 = require_abort();
    var values_1 = require_values();
    var headers_1 = require_headers();
    var SessionToolRunner_1 = require_SessionToolRunner();
    var poller_1 = require_poller();
    var helper_client_1 = require_helper_client();
    var sync_interval_1 = require_sync_interval();
    var HEARTBEAT_DEFAULT_MS = 3e4;
    var HEARTBEAT_TTL_DEFAULT_MS = 9e4;
    var NO_HEARTBEAT_SENTINEL = "NO_HEARTBEAT";
    function hasMemoryStore(session) {
      return session.resources.some((r) => r.type === "memory_store");
    }
    function sessionsTokenFromSecret(secret) {
      if (!secret)
        return null;
      let parsed;
      try {
        const normalized = secret.replace(/-/g, "+").replace(/_/g, "/");
        const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
        parsed = JSON.parse((0, bytes_1.decodeUTF8)((0, base64_1.fromBase64)(padded)));
      } catch {
        return null;
      }
      if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed))
        return null;
      const token = parsed.sessions_token;
      return typeof token === "string" && token !== "" ? token : null;
    }
    var EnvironmentWorker = /* @__PURE__ */ (() => {
      class EnvironmentWorker2 {
        constructor(opts) {
          _EnvironmentWorker_instances.add(this);
          _EnvironmentWorker_signal.set(this, void 0);
          if (opts.unrestrictedPaths !== void 0) {
            throw new error_1.AnthropicError("The `unrestrictedPaths` option you passed to EnvironmentWorker (or client.beta.environments.work.worker()) is no longer supported. The worker's file tools (read, write, edit, glob, grep) are now always confined to `workdir` plus the session's memory folders. Remove `unrestrictedPaths` from your options; to let the file tools reach any other directory, add it to `AgentToolContext.allowedRoots` from a `tools` factory.");
          }
          this.client = opts.client;
          this.environmentId = opts.environmentId;
          this.environmentKey = opts.environmentKey;
          this.tools = opts.tools;
          this.workdir = opts.workdir ?? process.cwd();
          this.maxFileBytes = opts.maxFileBytes;
          this.maxIdleMs = opts.maxIdleMs;
          if (opts.memorySyncIntervalMs != null) {
            (0, sync_interval_1.checkMemorySyncInterval)(opts.memorySyncIntervalMs, "memorySyncIntervalMs");
          }
          this.memorySyncIntervalMs = opts.memorySyncIntervalMs;
          this.memorySyncDeletions = opts.memorySyncDeletions ?? "enabled";
          this.workerId = opts.workerId;
          this.requestOptions = opts.requestOptions;
          tslib_1.__classPrivateFieldSet(this, _EnvironmentWorker_signal, opts.signal, "f");
        }
        /**
         * Poll the environment and service each claimed session until the supplied
         * signal (or the one passed to the constructor) aborts. Throws if
         * `environmentId` / `environmentKey` were not provided to the constructor.
         */
        async run(signal) {
          const { environmentId, environmentKey } = this;
          if (environmentId === void 0 || environmentKey === void 0) {
            throw new error_1.AnthropicError("EnvironmentWorker.run: environmentId and environmentKey are required to poll for work");
          }
          const externalSignal = signal ?? tslib_1.__classPrivateFieldGet(this, _EnvironmentWorker_signal, "f");
          const poller = new poller_1.WorkPoller({
            client: this.client,
            environmentId,
            environmentKey,
            ...this.workerId !== void 0 ? { workerId: this.workerId } : {},
            ...externalSignal ? { signal: externalSignal } : {},
            ...this.requestOptions !== void 0 ? { requestOptions: this.requestOptions } : {},
            // The per-item handler stops or releases every work item on exit; let it
            // be the single owner of `work.stop` rather than double-posting from the
            // poller.
            autoStop: false
          });
          for await (const work of poller) {
            try {
              await tslib_1.__classPrivateFieldGet(this, _EnvironmentWorker_instances, "m", _EnvironmentWorker_handleItem).call(this, work, environmentKey, poller.signal);
            } catch (e) {
              if (poller.signal?.aborted)
                throw e;
              (0, log_1.loggerFor)(this.client).error("work item failed", { work_id: work.id, error: String(e) });
            }
          }
        }
        /**
         * Service a single, already-claimed work item without the poll loop: build the
         * per-session {@link AgentToolContext} (workdir from this worker's options),
         * download the session agent's skills (`setupSkills`), run a
         * {@link SessionToolRunner} for the session while heartbeating the work-item
         * lease, and force-stop the work item on exit (whether the runner finishes
         * normally, throws, or the control plane signals shutdown). The one
         * exception is a lost lease: the item then belongs to the queue or another
         * worker and is left alone.
         *
         * Use this when something else does the claiming — e.g. a `worker poll
         * --on-work` script that hands an already-claimed item to a fresh process. The
         * work id / environment id / session id each fall back to `ANTHROPIC_WORK_ID` /
         * `ANTHROPIC_ENVIRONMENT_ID` / `ANTHROPIC_SESSION_ID` (the env vars that
         * command sets) when not passed; the environment key resolves from this
         * option, then the worker's own `environmentKey`, then
         * `ANTHROPIC_ENVIRONMENT_KEY`, and is needed only when the work item's
         * `secret` yields no sessions token — a host that receives only the
         * per-item secret runs without ever holding the key. With no arguments
         * inside that command it just works. Throws a clear error naming the first
         * required value still missing after resolution, and — rather than ever
         * running unauthenticated — when neither a sessions token nor an
         * environment key resolved. Throws `SessionMemoryError` when the
         * session has memory stores attached but they cannot be mounted — the work
         * item carried no sessions token (unless `memorySyncIntervalMs` turned
         * memory off), or a store failed to download.
         *
         * `workSecret` is the work item's per-item `secret` payload from the poll
         * response, falling back to `ANTHROPIC_WORK_SECRET`; unlike the others it is
         * optional — when present, the sessions token extracted from it is preferred
         * as the Bearer credential for this item's heartbeat / force-stop / session
         * calls; when absent (or undecodable) those calls use the environment key.
         */
        async handleItem(opts) {
          const workId = opts?.workId ?? (0, env_1.readEnv)("ANTHROPIC_WORK_ID");
          const environmentId = opts?.environmentId ?? (0, env_1.readEnv)("ANTHROPIC_ENVIRONMENT_ID");
          const sessionId = opts?.sessionId ?? (0, env_1.readEnv)("ANTHROPIC_SESSION_ID");
          const environmentKey = (opts?.environmentKey ?? this.environmentKey ?? (0, env_1.readEnv)("ANTHROPIC_ENVIRONMENT_KEY")) || void 0;
          const workSecret = opts?.workSecret || (0, env_1.readEnv)("ANTHROPIC_WORK_SECRET") || null;
          if (!workId) {
            throw new error_1.AnthropicError("handleItem: workId is required \u2014 pass it or set ANTHROPIC_WORK_ID");
          }
          if (!environmentId) {
            throw new error_1.AnthropicError("handleItem: environmentId is required \u2014 pass it or set ANTHROPIC_ENVIRONMENT_ID");
          }
          if (!sessionId) {
            throw new error_1.AnthropicError("handleItem: sessionId is required \u2014 pass it or set ANTHROPIC_SESSION_ID");
          }
          if (!environmentKey && !workSecret) {
            throw new error_1.AnthropicError("handleItem: environmentKey is required when there is no work secret \u2014 pass it, construct the worker with it, or set ANTHROPIC_ENVIRONMENT_KEY");
          }
          const work = {
            id: workId,
            environment_id: environmentId,
            secret: workSecret,
            data: { type: "session", id: sessionId }
          };
          await tslib_1.__classPrivateFieldGet(this, _EnvironmentWorker_instances, "m", _EnvironmentWorker_handleItem).call(this, work, environmentKey, opts?.signal ?? tslib_1.__classPrivateFieldGet(this, _EnvironmentWorker_signal, "f"));
        }
      }
      _EnvironmentWorker_signal = /* @__PURE__ */ new WeakMap(), _EnvironmentWorker_instances = /* @__PURE__ */ new WeakSet(), _EnvironmentWorker_handleItem = /**
       * The per-item body shared by {@link EnvironmentWorker.run}'s poll loop and
       * {@link EnvironmentWorker.handleItem}: run a {@link SessionToolRunner} for the
       * work item's session while heartbeating its lease, force-stopping on exit
       * unless the lease was lost. Non-session work items are ignored.
       *
       * When the poll response carried a per-item `secret` (a short-lived payload
       * scoped to this work item), the sessions token extracted from it is
       * preferred over `environmentKey` as the Bearer credential for those
       * per-item calls; a missing/undecodable secret falls back to
       * `environmentKey` unchanged.
       */
      async function _EnvironmentWorker_handleItem2(work, environmentKey, externalSignal) {
        const log = (0, log_1.loggerFor)(this.client);
        const sessionsToken = sessionsTokenFromSecret(work.secret);
        const itemCredential = sessionsToken ?? environmentKey;
        if (itemCredential === void 0) {
          throw new error_1.AnthropicError("handleItem: the work item carried a secret payload but no sessions token could be extracted, and there is no environment key to fall back to; the poller must issue a secret whose payload carries `sessions_token`, or provide the environment key (pass it, construct the worker with it, or set ANTHROPIC_ENVIRONMENT_KEY)");
        }
        if (work.secret && sessionsToken === null) {
          log.warn("work item carried a secret payload but no sessions token could be extracted; falling back to the environment key", { work_id: work.id });
        }
        const sessionClient = (0, helper_client_1.copyClientForHelper)(this.client, {
          authToken: itemCredential,
          helper: "environments-worker"
        });
        const sessionId = work.data.id;
        const ctrl = new AbortController();
        const detachExternal = (0, abort_1.linkAbort)(externalSignal, ctrl);
        const lease = new Lease(ctrl);
        const agentToolset = await Promise.resolve().then(() => tslib_1.__importStar(require_node2()));
        let leaseTtlMs;
        let runner;
        const heartbeatPromise = heartbeatLoop(sessionClient, work, lease, log, this.requestOptions, (ttlMs) => {
          leaseTtlMs = ttlMs;
          runner?._setSendRetryWindow(ttlMs);
        }).catch((e) => {
          if (!ctrl.signal.aborted)
            log.error("heartbeat loop failed", { work_id: work.id, error: String(e) });
          ctrl.abort();
        });
        let cleanupSkills = async () => {
        };
        let stores;
        let cleanEnd = false;
        try {
          if (work.data.type !== "session") {
            log.debug("skipping non-session work item", { work_id: work.id, type: work.data.type });
            return;
          }
          const session = await sessionClient.beta.sessions.retrieve(sessionId);
          if (sessionsToken === null && this.memorySyncIntervalMs !== null && hasMemoryStore(session)) {
            throw new agentToolset.SessionMemoryError(`cannot mount the session's memories: the work item carried no sessions token (work_id=${work.id}, session_id=${sessionId}); the memory endpoints reject the environment key, so the poller must issue a per-item \`secret\` carrying \`sessions_token\`, or set \`memorySyncIntervalMs: null\` to run without memory`);
          }
          const ctx = {
            workdir: this.workdir,
            // The scoped sub-client, not the parent: the skill download
            // `setupSkills` performs for this session rides the same per-item
            // credential as every other per-item call.
            client: sessionClient,
            session,
            ...this.maxFileBytes !== void 0 ? { maxFileBytes: this.maxFileBytes } : {}
          };
          try {
            cleanupSkills = await agentToolset.setupSkills(ctx);
          } catch (e) {
            log.warn("skill setup failed", { session_id: sessionId, work_id: work.id, error: String(e) });
          }
          if (sessionsToken !== null && this.memorySyncIntervalMs !== null) {
            stores = new agentToolset.SessionMemoryStores(sessionClient, {
              workdir: this.workdir,
              ...this.memorySyncIntervalMs !== void 0 ? { syncIntervalMs: this.memorySyncIntervalMs } : {},
              syncDeletions: this.memorySyncDeletions
            });
            await stores.download(session);
            ctx.allowedRoots = stores.roots;
            ctx.readOnlyRoots = stores.readOnlyRoots;
          } else {
            log.debug("memory stores disabled for this item", { work_id: work.id });
          }
          const tools = typeof this.tools === "function" ? this.tools(ctx) : this.tools ?? agentToolset.betaAgentToolset20260401(ctx);
          runner = new SessionToolRunner_1.SessionToolRunner(sessionId, {
            client: sessionClient,
            tools,
            ...this.maxIdleMs !== void 0 ? { maxIdleMs: this.maxIdleMs } : {},
            ...this.requestOptions !== void 0 ? { requestOptions: this.requestOptions } : {},
            signal: ctrl.signal
          });
          if (leaseTtlMs !== void 0)
            runner._setSendRetryWindow(leaseTtlMs);
          for await (const _ of runner) {
            if (stores)
              await stores.syncIfDue();
          }
          cleanEnd = !ctrl.signal.aborted;
        } finally {
          try {
            await cleanupSkills().catch((e) => {
              log.warn("skill cleanup failed", { session_id: sessionId, work_id: work.id, error: String(e) });
            });
          } finally {
            if (stores) {
              const boundMs = agentToolset.MEMORY_FLUSH_TIMEOUT_MS;
              if (cleanEnd) {
                const finishCutOff = await withTimeout(stores.finish(), boundMs);
                if (finishCutOff) {
                  log.warn(`final memory sync cut off after ${boundMs}ms; the flush that follows still uploads changed files`, { session_id: sessionId, work_id: work.id });
                }
              }
              const flushBound = new AbortController();
              const flushCutOff = await withTimeout(stores.flushWrites(flushBound.signal), boundMs);
              if (flushCutOff) {
                flushBound.abort();
                log.warn(`memory flush cut off after ${boundMs}ms; changed files it had not uploaded yet are not saved`, { session_id: sessionId, work_id: work.id });
              }
              await stores.dispose().catch((e) => {
                log.warn("memory store cleanup failed", {
                  session_id: sessionId,
                  work_id: work.id,
                  error: String(e)
                });
              });
            }
          }
          lease.finish("runner_done");
          detachExternal();
          await heartbeatPromise;
          if (lease.lost) {
            log.info("lease lost; released without stopping it", { session_id: sessionId, work_id: work.id });
          } else {
            await forceStop(sessionClient, work, log, this.requestOptions);
          }
        }
      };
      return EnvironmentWorker2;
    })();
    exports2.EnvironmentWorker = EnvironmentWorker;
    async function withTimeout(p, ms) {
      let timer;
      try {
        return await Promise.race([
          p.then(() => false, () => false),
          new Promise((resolve) => {
            timer = setTimeout(() => resolve(true), ms);
          })
        ]);
      } finally {
        if (timer !== void 0)
          clearTimeout(timer);
      }
    }
    async function forceStop(client, work, log, requestOptions) {
      try {
        await client.beta.environments.work.stop(
          work.id,
          { environment_id: work.environment_id, force: true },
          // Caller's headers pass through; the helper-tag header is on the scoped
          // sub-client's default_headers via copyClientForHelper, so no per-call
          // re-stamping needed.
          { ...requestOptions, headers: (0, headers_1.buildHeaders)([requestOptions?.headers]) }
        );
      } catch (e) {
        if (!(0, backoff_1.isStatus)(e, 409)) {
          log.error("force-stop on exit failed", { work_id: work.id, error: String(e) });
        }
      }
    }
    var Lease = /* @__PURE__ */ (() => {
      class Lease2 {
        constructor(ctrl) {
          _Lease_ctrl.set(this, void 0);
          _Lease_endReason.set(this, void 0);
          tslib_1.__classPrivateFieldSet(this, _Lease_ctrl, ctrl, "f");
        }
        get signal() {
          return tslib_1.__classPrivateFieldGet(this, _Lease_ctrl, "f").signal;
        }
        finish(reason) {
          tslib_1.__classPrivateFieldSet(this, _Lease_endReason, tslib_1.__classPrivateFieldGet(this, _Lease_endReason, "f") ?? reason, "f");
          tslib_1.__classPrivateFieldGet(this, _Lease_ctrl, "f").abort();
        }
        /** True once the item belongs to the queue or another worker. */
        get lost() {
          return tslib_1.__classPrivateFieldGet(this, _Lease_endReason, "f") === "lease_lost" || tslib_1.__classPrivateFieldGet(this, _Lease_endReason, "f") === "assumed_lost";
        }
      }
      _Lease_ctrl = /* @__PURE__ */ new WeakMap(), _Lease_endReason = /* @__PURE__ */ new WeakMap();
      return Lease2;
    })();
    function serverLeaseState(e) {
      let node = e instanceof error_1.APIError ? e.error : void 0;
      for (const key of ["error", "details", "current_state"]) {
        if (!(0, values_1.isObj)(node))
          return {};
        node = node[key];
      }
      return (0, values_1.isObj)(node) ? node : {};
    }
    async function heartbeatLoop(client, work, lease, logger, requestOptions, onLeaseTtl) {
      let intervalMs = HEARTBEAT_DEFAULT_MS;
      let ttlMs = HEARTBEAT_TTL_DEFAULT_MS;
      let lastSuccessMs = Date.now();
      let last = NO_HEARTBEAT_SENTINEL;
      const beat = async () => {
        const beatCtrl = new AbortController();
        const detach = (0, abort_1.linkAbort)(lease.signal, beatCtrl);
        const cutoff = setTimeout(() => beatCtrl.abort(), intervalMs);
        try {
          const resp = await client.beta.environments.work.heartbeat(work.id, { environment_id: work.environment_id, expected_last_heartbeat: last }, { ...requestOptions, headers: (0, headers_1.buildHeaders)([requestOptions?.headers]), signal: beatCtrl.signal });
          lastSuccessMs = Date.now();
          last = resp.last_heartbeat;
          if (resp.ttl_seconds > 0) {
            ttlMs = resp.ttl_seconds * 1e3;
            intervalMs = Math.max(1e3, Math.min(ttlMs / 2, HEARTBEAT_DEFAULT_MS));
            onLeaseTtl?.(ttlMs);
          }
          if (resp.state === "stopping" || resp.state === "stopped") {
            logger.info("heartbeat signals shutdown", { work_id: work.id, state: resp.state });
            lease.finish("control_plane_stop");
          }
          if (!resp.lease_extended) {
            logger.warn("lease not extended, shutting down", { work_id: work.id });
            lease.finish("control_plane_stop");
          }
        } catch (e) {
          lease.signal.throwIfAborted();
          if ((0, backoff_1.isStatus)(e, 412)) {
            const server = serverLeaseState(e);
            logger.error("lease lost: heartbeat precondition failed", {
              work_id: work.id,
              server_state: server["state"],
              server_ttl_seconds: server["ttl_seconds"],
              server_last_heartbeat: server["last_heartbeat"]
            });
            lease.finish("lease_lost");
            return;
          }
          if ((0, backoff_1.isFatal4xx)(e)) {
            logger.error("permanent heartbeat failure", { work_id: work.id, error: String(e) });
            lease.finish("heartbeat_rejected");
            throw e;
          }
          if (Date.now() - lastSuccessMs > ttlMs) {
            logger.error("lease assumed lost: no successful heartbeat in ttl", {
              work_id: work.id,
              ttl_ms: ttlMs,
              error: String(e)
            });
            lease.finish("assumed_lost");
            return;
          }
          logger.warn("transient heartbeat failure", { work_id: work.id, error: String(e) });
        } finally {
          clearTimeout(cutoff);
          detach();
        }
      };
      await beat();
      while (!lease.signal.aborted) {
        await (0, sleep_1.sleep)(intervalMs, lease.signal);
        lease.signal.throwIfAborted();
        await beat();
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/environments/work.js
var require_work = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/environments/work.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EnvironmentWorker = exports2.WorkPoller = exports2.Work = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var poller_1 = require_poller();
    var worker_1 = require_worker();
    var Work = /* @__PURE__ */ (() => {
      class Work2 extends resource_1.APIResource {
        /**
         * Note: these endpoints are called automatically by the pre-built environment
         * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
         * sandbox environments. They are included here as a reference; you do not need to
         * invoke them directly.
         *
         * Retrieve detailed information about a specific work item.
         *
         * @example
         * ```ts
         * const betaSelfHostedWork =
         *   await client.beta.environments.work.retrieve('work_id', {
         *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   });
         * ```
         */
        retrieve(workID, params, options) {
          const { environment_id, betas, workspace_id } = params;
          return this._client.get((0, path_1.path)`/v1/environments/${environment_id}/work/${workID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Note: these endpoints are called automatically by the pre-built environment
         * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
         * sandbox environments. They are included here as a reference; you do not need to
         * invoke them directly.
         *
         * Update work item metadata with merge semantics.
         *
         * @example
         * ```ts
         * const betaSelfHostedWork =
         *   await client.beta.environments.work.update('work_id', {
         *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *     metadata: { foo: 'string' },
         *   });
         * ```
         */
        update(workID, params, options) {
          const { environment_id, betas, workspace_id, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/environments/${environment_id}/work/${workID}?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Note: these endpoints are called automatically by the pre-built environment
         * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
         * sandbox environments. They are included here as a reference; you do not need to
         * invoke them directly.
         *
         * List work items in an environment.
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaSelfHostedWork of client.beta.environments.work.list(
         *   'env_011CZkZ9X2dpNyB7HsEFoRfW',
         * )) {
         *   // ...
         * }
         * ```
         */
        list(environmentID, params = {}, options) {
          const { betas, ...query } = params ?? {};
          return this._client.getAPIList((0, path_1.path)`/v1/environments/${environmentID}/work?beta=true`, pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
              options?.headers
            ])
          });
        }
        /**
         * Note: these endpoints are called automatically by the pre-built environment
         * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
         * sandbox environments. They are included here as a reference; you do not need to
         * invoke them directly.
         *
         * Acknowledge receipt of a work item, transitioning it from 'queued' to 'starting'
         * and removing it from the queue.
         *
         * @example
         * ```ts
         * const betaSelfHostedWork =
         *   await client.beta.environments.work.ack('work_id', {
         *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   });
         * ```
         */
        ack(workID, params, options) {
          const { environment_id, betas } = params;
          return this._client.post((0, path_1.path)`/v1/environments/${environment_id}/work/${workID}/ack?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
              options?.headers
            ])
          });
        }
        /**
         * Note: these endpoints are called automatically by the pre-built environment
         * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
         * sandbox environments. They are included here as a reference; you do not need to
         * invoke them directly.
         *
         * Record a heartbeat for a work item to maintain the lease.
         *
         * @example
         * ```ts
         * const betaSelfHostedWorkHeartbeatResponse =
         *   await client.beta.environments.work.heartbeat('work_id', {
         *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   });
         * ```
         */
        heartbeat(workID, params, options) {
          const { environment_id, desired_ttl_seconds, expected_last_heartbeat, betas } = params;
          return this._client.post((0, path_1.path)`/v1/environments/${environment_id}/work/${workID}/heartbeat?beta=true`, {
            query: { desired_ttl_seconds, expected_last_heartbeat },
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
              options?.headers
            ])
          });
        }
        /**
         * Note: these endpoints are called automatically by the pre-built environment
         * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
         * sandbox environments. They are included here as a reference; you do not need to
         * invoke them directly.
         *
         * Long poll for work items in the queue.
         *
         * @example
         * ```ts
         * const betaSelfHostedWork =
         *   await client.beta.environments.work.poll(
         *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   );
         * ```
         */
        poll(environmentID, params = {}, options) {
          const { betas, "Anthropic-Worker-ID": anthropicWorkerID, ...query } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/environments/${environmentID}/work/poll?beta=true`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...anthropicWorkerID != null ? { "Anthropic-Worker-ID": anthropicWorkerID } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Get statistics about the work queue for an environment.
         *
         * @example
         * ```ts
         * const betaSelfHostedWorkQueueStats =
         *   await client.beta.environments.work.stats(
         *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   );
         * ```
         */
        stats(environmentID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/environments/${environmentID}/work/stats?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Note: these endpoints are called automatically by the pre-built environment
         * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
         * sandbox environments. They are included here as a reference; you do not need to
         * invoke them directly.
         *
         * Stop a work item, initiating graceful or forced shutdown.
         *
         * @example
         * ```ts
         * const betaSelfHostedWork =
         *   await client.beta.environments.work.stop('work_id', {
         *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   });
         * ```
         */
        stop(workID, params, options) {
          const { environment_id, betas, workspace_id, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/environments/${environment_id}/work/${workID}/stop?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Continuously claim work from a self-hosted environment, ack each item,
         * and yield it. Posts `stop` automatically when the consumer's loop body
         * returns or when iteration ends.
         *
         * @example
         * ```ts
         * for await (const work of client.beta.environments.work.poller({
         *   environmentId,
         *   environmentKey,
         * })) {
         *   if (work.data.type !== 'session') continue;
         *   // ...service the work...
         * }
         * ```
         */
        poller(opts) {
          return new poller_1.WorkPoller({ ...opts, client: this._client });
        }
        worker(opts) {
          return new worker_1.EnvironmentWorker({ ...opts, client: this._client });
        }
      }
      Work2.WorkPoller = poller_1.WorkPoller;
      Work2.EnvironmentWorker = worker_1.EnvironmentWorker;
      return Work2;
    })();
    exports2.Work = Work;
    var poller_2 = require_poller();
    Object.defineProperty(exports2, "WorkPoller", { enumerable: true, get: function() {
      return poller_2.WorkPoller;
    } });
    var worker_2 = require_worker();
    Object.defineProperty(exports2, "EnvironmentWorker", { enumerable: true, get: function() {
      return worker_2.EnvironmentWorker;
    } });
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/environments/environments.js
var require_environments = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/environments/environments.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Environments = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var WorkAPI = tslib_1.__importStar(require_work());
    var work_1 = require_work();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Environments = /* @__PURE__ */ (() => {
      class Environments2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.work = new WorkAPI.Work(this._client);
        }
        /**
         * Create a new environment with the specified configuration.
         *
         * @example
         * ```ts
         * const betaEnvironment =
         *   await client.beta.environments.create({
         *     name: 'python-data-analysis',
         *   });
         * ```
         */
        create(params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post("/v1/environments?beta=true", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Retrieve a specific environment by ID.
         *
         * @example
         * ```ts
         * const betaEnvironment =
         *   await client.beta.environments.retrieve(
         *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   );
         * ```
         */
        retrieve(environmentID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/environments/${environmentID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Update an existing environment's configuration.
         *
         * @example
         * ```ts
         * const betaEnvironment =
         *   await client.beta.environments.update(
         *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   );
         * ```
         */
        update(environmentID, params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/environments/${environmentID}?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * List environments with pagination support.
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaEnvironment of client.beta.environments.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.getAPIList("/v1/environments?beta=true", pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Delete an environment by ID. Returns a confirmation of the deletion.
         *
         * @example
         * ```ts
         * const betaEnvironmentDeleteResponse =
         *   await client.beta.environments.delete(
         *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   );
         * ```
         */
        delete(environmentID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.delete((0, path_1.path)`/v1/environments/${environmentID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Archive an environment by ID. Archived environments cannot be used to create new
         * sessions.
         *
         * @example
         * ```ts
         * const betaEnvironment =
         *   await client.beta.environments.archive(
         *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   );
         * ```
         */
        archive(environmentID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.post((0, path_1.path)`/v1/environments/${environmentID}/archive?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
      }
      Environments2.Work = work_1.Work;
      return Environments2;
    })();
    exports2.Environments = Environments;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memories.js
var require_memories2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memories.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Memories = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Memories = class extends resource_1.APIResource {
      /**
       * Create a memory
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemory =
       *   await client.beta.memoryStores.memories.create(
       *     'memory_store_id',
       *     { content: 'content', path: 'xx' },
       *   );
       * ```
       */
      create(memoryStoreID, params, options) {
        const { view, betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/memory_stores/${memoryStoreID}/memories?beta=true`, {
          query: { view },
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Retrieve a memory
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemory =
       *   await client.beta.memoryStores.memories.retrieve(
       *     'memory_id',
       *     { memory_store_id: 'memory_store_id' },
       *   );
       * ```
       */
      retrieve(memoryID, params, options) {
        const { memory_store_id, betas, workspace_id, ...query } = params;
        return this._client.get((0, path_1.path)`/v1/memory_stores/${memory_store_id}/memories/${memoryID}?beta=true`, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Update a memory
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemory =
       *   await client.beta.memoryStores.memories.update(
       *     'memory_id',
       *     { memory_store_id: 'memory_store_id' },
       *   );
       * ```
       */
      update(memoryID, params, options) {
        const { memory_store_id, view, betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/memory_stores/${memory_store_id}/memories/${memoryID}?beta=true`, {
          query: { view },
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List memories
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsMemoryListItem of client.beta.memoryStores.memories.list(
       *   'memory_store_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(memoryStoreID, params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/memory_stores/${memoryStoreID}/memories?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Delete a memory
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeletedMemory =
       *   await client.beta.memoryStores.memories.delete(
       *     'memory_id',
       *     { memory_store_id: 'memory_store_id' },
       *   );
       * ```
       */
      delete(memoryID, params, options) {
        const { memory_store_id, expected_content_sha256, betas, workspace_id } = params;
        return this._client.delete((0, path_1.path)`/v1/memory_stores/${memory_store_id}/memories/${memoryID}?beta=true`, {
          query: { expected_content_sha256 },
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.Memories = Memories;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memory-versions.js
var require_memory_versions = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memory-versions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MemoryVersions = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var MemoryVersions = class extends resource_1.APIResource {
      /**
       * Retrieve a memory version
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemoryVersion =
       *   await client.beta.memoryStores.memoryVersions.retrieve(
       *     'memory_version_id',
       *     { memory_store_id: 'memory_store_id' },
       *   );
       * ```
       */
      retrieve(memoryVersionID, params, options) {
        const { memory_store_id, betas, workspace_id, ...query } = params;
        return this._client.get((0, path_1.path)`/v1/memory_stores/${memory_store_id}/memory_versions/${memoryVersionID}?beta=true`, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List memory versions
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsMemoryVersion of client.beta.memoryStores.memoryVersions.list(
       *   'memory_store_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(memoryStoreID, params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/memory_stores/${memoryStoreID}/memory_versions?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Redact a memory version
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemoryVersion =
       *   await client.beta.memoryStores.memoryVersions.redact(
       *     'memory_version_id',
       *     { memory_store_id: 'memory_store_id' },
       *   );
       * ```
       */
      redact(memoryVersionID, params, options) {
        const { memory_store_id, betas, workspace_id } = params;
        return this._client.post((0, path_1.path)`/v1/memory_stores/${memory_store_id}/memory_versions/${memoryVersionID}/redact?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.MemoryVersions = MemoryVersions;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memory-stores.js
var require_memory_stores = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memory-stores.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MemoryStores = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var MemoriesAPI = tslib_1.__importStar(require_memories2());
    var memories_1 = require_memories2();
    var MemoryVersionsAPI = tslib_1.__importStar(require_memory_versions());
    var memory_versions_1 = require_memory_versions();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var MemoryStores = /* @__PURE__ */ (() => {
      class MemoryStores2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.memories = new MemoriesAPI.Memories(this._client);
          this.memoryVersions = new MemoryVersionsAPI.MemoryVersions(this._client);
        }
        /**
         * Create a memory store
         *
         * @example
         * ```ts
         * const betaManagedAgentsMemoryStore =
         *   await client.beta.memoryStores.create({ name: 'x' });
         * ```
         */
        create(params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post("/v1/memory_stores?beta=true", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Retrieve a memory store
         *
         * @example
         * ```ts
         * const betaManagedAgentsMemoryStore =
         *   await client.beta.memoryStores.retrieve(
         *     'memory_store_id',
         *   );
         * ```
         */
        retrieve(memoryStoreID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/memory_stores/${memoryStoreID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Update a memory store
         *
         * @example
         * ```ts
         * const betaManagedAgentsMemoryStore =
         *   await client.beta.memoryStores.update('memory_store_id');
         * ```
         */
        update(memoryStoreID, params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/memory_stores/${memoryStoreID}?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * List memory stores
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaManagedAgentsMemoryStore of client.beta.memoryStores.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.getAPIList("/v1/memory_stores?beta=true", pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Delete a memory store
         *
         * @example
         * ```ts
         * const betaManagedAgentsDeletedMemoryStore =
         *   await client.beta.memoryStores.delete('memory_store_id');
         * ```
         */
        delete(memoryStoreID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.delete((0, path_1.path)`/v1/memory_stores/${memoryStoreID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Archive a memory store
         *
         * @example
         * ```ts
         * const betaManagedAgentsMemoryStore =
         *   await client.beta.memoryStores.archive('memory_store_id');
         * ```
         */
        archive(memoryStoreID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.post((0, path_1.path)`/v1/memory_stores/${memoryStoreID}/archive?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "agent-memory-2026-07-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
      }
      MemoryStores2.Memories = memories_1.Memories;
      MemoryStores2.MemoryVersions = memory_versions_1.MemoryVersions;
      return MemoryStores2;
    })();
    exports2.MemoryStores = MemoryStores;
  }
});

// node_modules/@anthropic-ai/sdk/error.js
var require_error2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/error.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_error(), exports2);
  }
});

// node_modules/@anthropic-ai/sdk/internal/decoders/jsonl.js
var require_jsonl = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/decoders/jsonl.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.JSONLDecoder = void 0;
    var error_1 = require_error();
    var shims_1 = require_shims();
    var line_1 = require_line();
    var JSONLDecoder = /* @__PURE__ */ (() => {
      class JSONLDecoder2 {
        constructor(iterator, controller) {
          this.iterator = iterator;
          this.controller = controller;
        }
        async *decoder() {
          const lineDecoder = new line_1.LineDecoder();
          for await (const chunk of this.iterator) {
            for (const line of lineDecoder.decode(chunk)) {
              yield JSON.parse(line);
            }
          }
          for (const line of lineDecoder.flush()) {
            yield JSON.parse(line);
          }
        }
        [Symbol.asyncIterator]() {
          return this.decoder();
        }
        static fromResponse(response, controller) {
          if (!response.body) {
            controller.abort();
            if (typeof globalThis.navigator !== "undefined" && globalThis.navigator.product === "ReactNative") {
              throw new error_1.AnthropicError(`The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api`);
            }
            throw new error_1.AnthropicError(`Attempted to iterate over a response with no body`);
          }
          return new JSONLDecoder2((0, shims_1.ReadableStreamToAsyncIterable)(response.body), controller);
        }
      }
      return JSONLDecoder2;
    })();
    exports2.JSONLDecoder = JSONLDecoder;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/messages/batches.js
var require_batches = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/messages/batches.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Batches = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var jsonl_1 = require_jsonl();
    var error_1 = require_error2();
    var path_1 = require_path();
    var Batches = class extends resource_1.APIResource {
      /**
       * Send a batch of Message creation requests.
       *
       * The Message Batches API can be used to process multiple Messages API requests at
       * once. Once a Message Batch is created, it begins processing immediately. Batches
       * can take up to 24 hours to complete.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const betaMessageBatch =
       *   await client.beta.messages.batches.create({
       *     requests: [
       *       {
       *         custom_id: 'my-custom-id-1',
       *         params: {
       *           max_tokens: 1024,
       *           messages: [
       *             { content: 'Hello, world', role: 'user' },
       *           ],
       *           model: 'claude-opus-5',
       *         },
       *       },
       *     ],
       *   });
       * ```
       */
      create(params, options) {
        const { betas, user_profile_id, workspace_id, ...body } = params;
        return this._client.post("/v1/messages/batches?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
              ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * This endpoint is idempotent and can be used to poll for Message Batch
       * completion. To access the results of a Message Batch, make a request to the
       * `results_url` field in the response.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const betaMessageBatch =
       *   await client.beta.messages.batches.retrieve(
       *     'message_batch_id',
       *   );
       * ```
       */
      retrieve(messageBatchID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/messages/batches/${messageBatchID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List all Message Batches within a Workspace. Most recently created batches are
       * returned first.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaMessageBatch of client.beta.messages.batches.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList("/v1/messages/batches?beta=true", pagination_1.Page, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Delete a Message Batch.
       *
       * Message Batches can only be deleted once they've finished processing. If you'd
       * like to delete an in-progress batch, you must first cancel it.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const betaDeletedMessageBatch =
       *   await client.beta.messages.batches.delete(
       *     'message_batch_id',
       *   );
       * ```
       */
      delete(messageBatchID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/messages/batches/${messageBatchID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Batches may be canceled any time before processing ends. Once cancellation is
       * initiated, the batch enters a `canceling` state, at which time the system may
       * complete any in-progress, non-interruptible requests before finalizing
       * cancellation.
       *
       * The number of canceled requests is specified in `request_counts`. To determine
       * which requests were canceled, check the individual results within the batch.
       * Note that cancellation may not result in any canceled requests if they were
       * non-interruptible.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const betaMessageBatch =
       *   await client.beta.messages.batches.cancel(
       *     'message_batch_id',
       *   );
       * ```
       */
      cancel(messageBatchID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/messages/batches/${messageBatchID}/cancel?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Streams the results of a Message Batch as a `.jsonl` file.
       *
       * Each line in the file is a JSON object containing the result of a single request
       * in the Message Batch. Results are not guaranteed to be in the same order as
       * requests. Use the `custom_id` field to match results to requests.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const betaMessageBatchIndividualResponse =
       *   await client.beta.messages.batches.results(
       *     'message_batch_id',
       *   );
       * ```
       */
      async results(messageBatchID, params = {}, options) {
        const batch = await this.retrieve(messageBatchID, params, options);
        if (!batch.results_url) {
          throw new error_1.AnthropicError(`No batch \`results_url\`; Has it finished processing? ${batch.processing_status} - ${batch.id}`);
        }
        const { betas, workspace_id } = params ?? {};
        return this._client.get(batch.results_url, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
              Accept: "application/binary",
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ]),
          stream: true,
          __binaryResponse: true
        })._thenUnwrap((_, props) => jsonl_1.JSONLDecoder.fromResponse(props.response, props.controller));
      }
    };
    exports2.Batches = Batches;
  }
});

// node_modules/@anthropic-ai/sdk/internal/constants.js
var require_constants = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MODEL_NONSTREAMING_TOKENS = void 0;
    exports2.MODEL_NONSTREAMING_TOKENS = {
      "claude-opus-4@20250514": 8192,
      "anthropic.claude-opus-4-1-20250805-v1:0": 8192,
      "claude-opus-4-1@20250805": 8192
    };
  }
});

// node_modules/@anthropic-ai/sdk/lib/beta-parser.js
var require_beta_parser = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/beta-parser.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.maybeParseBetaMessage = maybeParseBetaMessage;
    exports2.parseBetaMessage = parseBetaMessage;
    var error_1 = require_error();
    function getOutputFormat(params) {
      return params?.output_format ?? params?.output_config?.format;
    }
    function maybeParseBetaMessage(message, params, opts) {
      const outputFormat = getOutputFormat(params);
      if (!params || !("parse" in (outputFormat ?? {}))) {
        return {
          ...message,
          content: message.content.map((block) => {
            if (block.type === "text") {
              const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
                value: null,
                enumerable: false
              });
              return Object.defineProperty(parsedBlock, "parsed", {
                get() {
                  opts.logger.warn("The `parsed` property on `text` blocks is deprecated, please use `parsed_output` instead.");
                  return null;
                },
                enumerable: false
              });
            }
            return block;
          }),
          parsed_output: null
        };
      }
      return parseBetaMessage(message, params, opts);
    }
    function parseBetaMessage(message, params, opts) {
      let firstParsedOutput = null;
      const content = message.content.map((block) => {
        if (block.type === "text") {
          const parsedOutput = parseBetaOutputFormat(params, block.text);
          if (firstParsedOutput === null) {
            firstParsedOutput = parsedOutput;
          }
          const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
            value: parsedOutput,
            enumerable: false
          });
          return Object.defineProperty(parsedBlock, "parsed", {
            get() {
              opts.logger.warn("The `parsed` property on `text` blocks is deprecated, please use `parsed_output` instead.");
              return parsedOutput;
            },
            enumerable: false
          });
        }
        return block;
      });
      return {
        ...message,
        content,
        parsed_output: firstParsedOutput
      };
    }
    function parseBetaOutputFormat(params, content) {
      const outputFormat = getOutputFormat(params);
      if (outputFormat?.type !== "json_schema") {
        return null;
      }
      try {
        if ("parse" in outputFormat) {
          return outputFormat.parse(content);
        }
        return JSON.parse(content);
      } catch (error) {
        throw new error_1.AnthropicError(`Failed to parse structured output: ${error}`);
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/streaming.js
var require_streaming2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/streaming.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_streaming(), exports2);
  }
});

// node_modules/@anthropic-ai/sdk/_vendor/partial-json-parser/parser.js
var require_parser = __commonJS({
  "node_modules/@anthropic-ai/sdk/_vendor/partial-json-parser/parser.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.partialParse = void 0;
    var tokenize = (input) => {
      let current = 0;
      let tokens = [];
      while (current < input.length) {
        let char = input[current];
        if (char === "\\") {
          current++;
          continue;
        }
        if (char === "{") {
          tokens.push({
            type: "brace",
            value: "{"
          });
          current++;
          continue;
        }
        if (char === "}") {
          tokens.push({
            type: "brace",
            value: "}"
          });
          current++;
          continue;
        }
        if (char === "[") {
          tokens.push({
            type: "paren",
            value: "["
          });
          current++;
          continue;
        }
        if (char === "]") {
          tokens.push({
            type: "paren",
            value: "]"
          });
          current++;
          continue;
        }
        if (char === ":") {
          tokens.push({
            type: "separator",
            value: ":"
          });
          current++;
          continue;
        }
        if (char === ",") {
          tokens.push({
            type: "delimiter",
            value: ","
          });
          current++;
          continue;
        }
        if (char === '"') {
          let value = "";
          let danglingQuote = false;
          char = input[++current];
          while (char !== '"') {
            if (current === input.length) {
              danglingQuote = true;
              break;
            }
            if (char === "\\") {
              current++;
              if (current === input.length) {
                danglingQuote = true;
                break;
              }
              value += char + input[current];
              char = input[++current];
            } else {
              value += char;
              char = input[++current];
            }
          }
          char = input[++current];
          if (!danglingQuote) {
            tokens.push({
              type: "string",
              value
            });
          }
          continue;
        }
        let WHITESPACE = /\s/;
        if (char && WHITESPACE.test(char)) {
          current++;
          continue;
        }
        let NUMBERS = /[0-9]/;
        if (char && NUMBERS.test(char) || char === "-" || char === ".") {
          let value = "";
          if (char === "-") {
            value += char;
            char = input[++current];
          }
          while (char && (NUMBERS.test(char) || char === "." || // exponent marker, e.g. `1e10` or `1.5E-9`
          char === "e" || char === "E" || // exponent sign, only valid immediately after the exponent marker
          (char === "-" || char === "+") && (value[value.length - 1] === "e" || value[value.length - 1] === "E"))) {
            value += char;
            char = input[++current];
          }
          tokens.push({
            type: "number",
            value
          });
          continue;
        }
        let LETTERS = /[a-z]/i;
        if (char && LETTERS.test(char)) {
          let value = "";
          while (char && LETTERS.test(char)) {
            if (current === input.length) {
              break;
            }
            value += char;
            char = input[++current];
          }
          if (value == "true" || value == "false" || value === "null") {
            tokens.push({
              type: "name",
              value
            });
          } else {
            current++;
            continue;
          }
          continue;
        }
        current++;
      }
      return tokens;
    };
    var strip = (tokens) => {
      if (tokens.length === 0) {
        return tokens;
      }
      let lastToken = tokens[tokens.length - 1];
      switch (lastToken.type) {
        case "separator":
          tokens = tokens.slice(0, tokens.length - 1);
          return strip(tokens);
          break;
        case "number":
          let lastCharacterOfLastToken = lastToken.value[lastToken.value.length - 1];
          if (lastCharacterOfLastToken === "." || lastCharacterOfLastToken === "-" || lastCharacterOfLastToken === "+" || lastCharacterOfLastToken === "e" || lastCharacterOfLastToken === "E") {
            tokens = tokens.slice(0, tokens.length - 1);
            return strip(tokens);
          }
        case "string":
          let tokenBeforeTheLastToken = tokens[tokens.length - 2];
          if (tokenBeforeTheLastToken?.type === "delimiter") {
            tokens = tokens.slice(0, tokens.length - 1);
            return strip(tokens);
          } else if (tokenBeforeTheLastToken?.type === "brace" && tokenBeforeTheLastToken.value === "{") {
            tokens = tokens.slice(0, tokens.length - 1);
            return strip(tokens);
          }
          break;
        case "delimiter":
          tokens = tokens.slice(0, tokens.length - 1);
          return strip(tokens);
          break;
      }
      return tokens;
    };
    var unstrip = (tokens) => {
      let tail = [];
      tokens.map((token) => {
        if (token.type === "brace") {
          if (token.value === "{") {
            tail.push("}");
          } else {
            tail.splice(tail.lastIndexOf("}"), 1);
          }
        }
        if (token.type === "paren") {
          if (token.value === "[") {
            tail.push("]");
          } else {
            tail.splice(tail.lastIndexOf("]"), 1);
          }
        }
      });
      if (tail.length > 0) {
        tail.reverse().map((item) => {
          if (item === "}") {
            tokens.push({
              type: "brace",
              value: "}"
            });
          } else if (item === "]") {
            tokens.push({
              type: "paren",
              value: "]"
            });
          }
        });
      }
      return tokens;
    };
    var generate = (tokens) => {
      let output = "";
      tokens.map((token) => {
        switch (token.type) {
          case "string":
            output += '"' + token.value + '"';
            break;
          default:
            output += token.value;
            break;
        }
      });
      return output;
    };
    var partialParse = (input) => JSON.parse(generate(unstrip(strip(tokenize(input)))));
    exports2.partialParse = partialParse;
  }
});

// node_modules/@anthropic-ai/sdk/internal/message-stream-utils.js
var require_message_stream_utils = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/message-stream-utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.JSON_BUF_PROPERTY = void 0;
    exports2.withLazyInput = withLazyInput;
    var parser_1 = require_parser();
    exports2.JSON_BUF_PROPERTY = "__json_buf";
    function withLazyInput(prev, jsonBuf) {
      const next = {};
      for (const key of Object.keys(prev)) {
        if (key !== "input")
          next[key] = prev[key];
      }
      Object.defineProperty(next, exports2.JSON_BUF_PROPERTY, { value: jsonBuf, enumerable: false, writable: true });
      let input;
      let parsed = false;
      Object.defineProperty(next, "input", {
        enumerable: true,
        configurable: true,
        get() {
          if (!parsed) {
            input = jsonBuf ? (0, parser_1.partialParse)(jsonBuf) : {};
            parsed = true;
          }
          return input;
        }
      });
      return next;
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/BetaMessageStream.js
var require_BetaMessageStream = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/BetaMessageStream.js"(exports2) {
    "use strict";
    var _BetaMessageStream_instances;
    var _BetaMessageStream_currentMessageSnapshot;
    var _BetaMessageStream_params;
    var _BetaMessageStream_connectedPromise;
    var _BetaMessageStream_resolveConnectedPromise;
    var _BetaMessageStream_rejectConnectedPromise;
    var _BetaMessageStream_endPromise;
    var _BetaMessageStream_resolveEndPromise;
    var _BetaMessageStream_rejectEndPromise;
    var _BetaMessageStream_listeners;
    var _BetaMessageStream_ended;
    var _BetaMessageStream_errored;
    var _BetaMessageStream_aborted;
    var _BetaMessageStream_catchingPromiseCreated;
    var _BetaMessageStream_response;
    var _BetaMessageStream_request_id;
    var _BetaMessageStream_workspace_id;
    var _BetaMessageStream_logger;
    var _BetaMessageStream_getFinalMessage;
    var _BetaMessageStream_getFinalText;
    var _BetaMessageStream_handleError;
    var _BetaMessageStream_beginRequest;
    var _BetaMessageStream_addStreamEvent;
    var _BetaMessageStream_endRequest;
    var _BetaMessageStream_accumulateMessage;
    var _BetaMessageStream_toolInputParseError;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BetaMessageStream = void 0;
    var tslib_1 = require_tslib();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var error_1 = require_error2();
    var errors_1 = require_errors();
    var values_1 = require_values();
    var streaming_1 = require_streaming2();
    var beta_parser_1 = require_beta_parser();
    var message_stream_utils_1 = require_message_stream_utils();
    function tracksToolInput(content) {
      return content.type === "tool_use" || content.type === "server_tool_use" || content.type === "mcp_tool_use";
    }
    var BetaMessageStream = /* @__PURE__ */ (() => {
      class BetaMessageStream2 {
        constructor(params, opts) {
          _BetaMessageStream_instances.add(this);
          this.messages = [];
          this.receivedMessages = [];
          _BetaMessageStream_currentMessageSnapshot.set(this, void 0);
          _BetaMessageStream_params.set(this, null);
          this.controller = new AbortController();
          _BetaMessageStream_connectedPromise.set(this, void 0);
          _BetaMessageStream_resolveConnectedPromise.set(this, () => {
          });
          _BetaMessageStream_rejectConnectedPromise.set(this, () => {
          });
          _BetaMessageStream_endPromise.set(this, void 0);
          _BetaMessageStream_resolveEndPromise.set(this, () => {
          });
          _BetaMessageStream_rejectEndPromise.set(this, () => {
          });
          _BetaMessageStream_listeners.set(this, {});
          _BetaMessageStream_ended.set(this, false);
          _BetaMessageStream_errored.set(this, false);
          _BetaMessageStream_aborted.set(this, false);
          _BetaMessageStream_catchingPromiseCreated.set(this, false);
          _BetaMessageStream_response.set(this, void 0);
          _BetaMessageStream_request_id.set(this, void 0);
          _BetaMessageStream_workspace_id.set(this, void 0);
          _BetaMessageStream_logger.set(this, void 0);
          _BetaMessageStream_handleError.set(this, (error) => {
            tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_errored, true, "f");
            if ((0, errors_1.isAbortError)(error)) {
              error = new error_1.APIUserAbortError();
            }
            if (error instanceof error_1.APIUserAbortError) {
              tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_aborted, true, "f");
              return this._emit("abort", error);
            }
            if (error instanceof error_1.AnthropicError) {
              return this._emit("error", error);
            }
            if (error instanceof Error) {
              const anthropicError = new error_1.AnthropicError(error.message);
              anthropicError.cause = error;
              return this._emit("error", anthropicError);
            }
            return this._emit("error", new error_1.AnthropicError(String(error)));
          });
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_connectedPromise, new Promise((resolve, reject) => {
            tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_resolveConnectedPromise, resolve, "f");
            tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_rejectConnectedPromise, reject, "f");
          }), "f");
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_endPromise, new Promise((resolve, reject) => {
            tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_resolveEndPromise, resolve, "f");
            tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_rejectEndPromise, reject, "f");
          }), "f");
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_connectedPromise, "f").catch(() => {
          });
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_endPromise, "f").catch(() => {
          });
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_params, params, "f");
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_logger, opts?.logger ?? console, "f");
        }
        get response() {
          return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_response, "f");
        }
        get request_id() {
          return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_request_id, "f");
        }
        get workspace_id() {
          return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_workspace_id, "f");
        }
        /**
         * Returns the `MessageStream` data, the raw `Response` instance and the ID of the request,
         * returned vie the `request-id` header which is useful for debugging requests and resporting
         * issues to Anthropic.
         *
         * This is the same as the `APIPromise.withResponse()` method.
         *
         * This method will raise an error if you created the stream using `MessageStream.fromReadableStream`
         * as no `Response` is available.
         */
        async withResponse() {
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_catchingPromiseCreated, true, "f");
          const response = await tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_connectedPromise, "f");
          if (!response) {
            throw new Error("Could not resolve a `Response` object");
          }
          return {
            data: this,
            response,
            request_id: response.headers.get("request-id"),
            workspace_id: response.headers.get("anthropic-workspace-id")
          };
        }
        /**
         * Intended for use on the frontend, consuming a stream produced with
         * `.toReadableStream()` on the backend.
         *
         * Note that messages sent to the model do not appear in `.on('message')`
         * in this context.
         */
        static fromReadableStream(stream) {
          const runner = new BetaMessageStream2(null);
          runner._run(() => runner._fromReadableStream(stream));
          return runner;
        }
        static createMessage(messages, params, options, { logger } = {}) {
          const runner = new BetaMessageStream2(params, { logger });
          for (const message of params.messages) {
            runner._addMessageParam(message);
          }
          tslib_1.__classPrivateFieldSet(runner, _BetaMessageStream_params, { ...params, stream: true }, "f");
          runner._run(() => runner._createMessage(messages, { ...params, stream: true }, { ...options, headers: { ...options?.headers, [stainless_helper_header_1.STAINLESS_HELPER_METHOD_HEADER]: "stream" } }));
          return runner;
        }
        _run(executor) {
          executor().then(() => {
            this._emitFinal();
            this._emit("end");
          }, tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_handleError, "f"));
        }
        _addMessageParam(message) {
          this.messages.push(message);
        }
        _addMessage(message, emit = true) {
          this.receivedMessages.push(message);
          if (emit) {
            this._emit("message", message);
          }
        }
        async _createMessage(messages, params, options) {
          const signal = options?.signal;
          let abortHandler;
          if (signal) {
            if (signal.aborted)
              this.controller.abort();
            abortHandler = this.controller.abort.bind(this.controller);
            signal.addEventListener("abort", abortHandler);
          }
          try {
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_beginRequest).call(this);
            const { response, data: stream } = await messages.create({ ...params, stream: true }, { ...options, signal: this.controller.signal }).withResponse();
            this._connected(response);
            for await (const event of stream) {
              tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_addStreamEvent).call(this, event);
            }
            if (stream.controller.signal?.aborted) {
              throw new error_1.APIUserAbortError();
            }
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_endRequest).call(this);
          } finally {
            if (signal && abortHandler) {
              signal.removeEventListener("abort", abortHandler);
            }
          }
        }
        _connected(response) {
          if (this.ended)
            return;
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_response, response, "f");
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_request_id, response?.headers.get("request-id"), "f");
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_workspace_id, response?.headers.get("anthropic-workspace-id"), "f");
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_resolveConnectedPromise, "f").call(this, response);
          this._emit("connect");
        }
        get ended() {
          return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_ended, "f");
        }
        get errored() {
          return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_errored, "f");
        }
        get aborted() {
          return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_aborted, "f");
        }
        abort() {
          this.controller.abort();
        }
        /**
         * Adds the listener function to the end of the listeners array for the event.
         * No checks are made to see if the listener has already been added. Multiple calls passing
         * the same combination of event and listener will result in the listener being added, and
         * called, multiple times.
         * @returns this MessageStream, so that calls can be chained
         */
        on(event, listener) {
          const listeners = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] || (tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] = []);
          listeners.push({ listener });
          return this;
        }
        /**
         * Removes the specified listener from the listener array for the event.
         * off() will remove, at most, one instance of a listener from the listener array. If any single
         * listener has been added multiple times to the listener array for the specified event, then
         * off() must be called multiple times to remove each instance.
         * @returns this MessageStream, so that calls can be chained
         */
        off(event, listener) {
          const listeners = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event];
          if (!listeners)
            return this;
          const index = listeners.findIndex((l) => l.listener === listener);
          if (index >= 0)
            listeners.splice(index, 1);
          return this;
        }
        /**
         * Adds a one-time listener function for the event. The next time the event is triggered,
         * this listener is removed and then invoked.
         * @returns this MessageStream, so that calls can be chained
         */
        once(event, listener) {
          const listeners = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] || (tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] = []);
          listeners.push({ listener, once: true });
          return this;
        }
        /**
         * This is similar to `.once()`, but returns a Promise that resolves the next time
         * the event is triggered, instead of calling a listener callback.
         * @returns a Promise that resolves the next time given event is triggered,
         * or rejects if an error is emitted.  (If you request the 'error' event,
         * returns a promise that resolves with the error).
         *
         * Example:
         *
         *   const message = await stream.emitted('message') // rejects if the stream errors
         */
        emitted(event) {
          return new Promise((resolve, reject) => {
            tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_catchingPromiseCreated, true, "f");
            if (event !== "error")
              this.once("error", reject);
            this.once(event, resolve);
          });
        }
        async done() {
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_catchingPromiseCreated, true, "f");
          await tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_endPromise, "f");
        }
        get currentMessage() {
          return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_currentMessageSnapshot, "f");
        }
        /**
         * @returns a promise that resolves with the the final assistant Message response,
         * or rejects if an error occurred or the stream ended prematurely without producing a Message.
         * If structured outputs were used, this will be a ParsedMessage with a `parsed` field.
         */
        async finalMessage() {
          await this.done();
          return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_getFinalMessage).call(this);
        }
        /**
         * @returns a promise that resolves with the the final assistant Message's text response, concatenated
         * together if there are more than one text blocks.
         * Rejects if an error occurred or the stream ended prematurely without producing a Message.
         */
        async finalText() {
          await this.done();
          return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_getFinalText).call(this);
        }
        _emit(event, ...args) {
          if (tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_ended, "f"))
            return;
          if (event === "end") {
            tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_ended, true, "f");
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_resolveEndPromise, "f").call(this);
          }
          const listeners = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event];
          if (listeners) {
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
            listeners.forEach(({ listener }) => listener(...args));
          }
          if (event === "abort") {
            const error = args[0];
            if (!tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
              Promise.reject(error);
            }
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_rejectConnectedPromise, "f").call(this, error);
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_rejectEndPromise, "f").call(this, error);
            this._emit("end");
            return;
          }
          if (event === "error") {
            const error = args[0];
            if (!tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
              Promise.reject(error);
            }
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_rejectConnectedPromise, "f").call(this, error);
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_rejectEndPromise, "f").call(this, error);
            this._emit("end");
          }
        }
        _emitFinal() {
          const finalMessage = this.receivedMessages.at(-1);
          if (finalMessage) {
            this._emit("finalMessage", tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_getFinalMessage).call(this));
          }
        }
        async _fromReadableStream(readableStream, options) {
          const signal = options?.signal;
          let abortHandler;
          if (signal) {
            if (signal.aborted)
              this.controller.abort();
            abortHandler = this.controller.abort.bind(this.controller);
            signal.addEventListener("abort", abortHandler);
          }
          try {
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_beginRequest).call(this);
            this._connected(null);
            const stream = streaming_1.Stream.fromReadableStream(readableStream, this.controller);
            for await (const event of stream) {
              tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_addStreamEvent).call(this, event);
            }
            if (stream.controller.signal?.aborted) {
              throw new error_1.APIUserAbortError();
            }
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_endRequest).call(this);
          } finally {
            if (signal && abortHandler) {
              signal.removeEventListener("abort", abortHandler);
            }
          }
        }
        [(_BetaMessageStream_currentMessageSnapshot = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_params = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_connectedPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_resolveConnectedPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_rejectConnectedPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_endPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_resolveEndPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_rejectEndPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_listeners = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_ended = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_errored = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_aborted = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_catchingPromiseCreated = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_response = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_request_id = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_workspace_id = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_logger = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_handleError = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_instances = /* @__PURE__ */ new WeakSet(), _BetaMessageStream_getFinalMessage = function _BetaMessageStream_getFinalMessage2() {
          if (this.receivedMessages.length === 0) {
            throw new error_1.AnthropicError("stream ended without producing a Message with role=assistant");
          }
          return this.receivedMessages.at(-1);
        }, _BetaMessageStream_getFinalText = function _BetaMessageStream_getFinalText2() {
          if (this.receivedMessages.length === 0) {
            throw new error_1.AnthropicError("stream ended without producing a Message with role=assistant");
          }
          const textBlocks = this.receivedMessages.at(-1).content.filter((block) => block.type === "text").map((block) => block.text);
          if (textBlocks.length === 0) {
            throw new error_1.AnthropicError("stream ended without producing a content block with type=text");
          }
          return textBlocks.join(" ");
        }, _BetaMessageStream_beginRequest = function _BetaMessageStream_beginRequest2() {
          if (this.ended)
            return;
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_currentMessageSnapshot, void 0, "f");
        }, _BetaMessageStream_addStreamEvent = function _BetaMessageStream_addStreamEvent2(event) {
          if (this.ended)
            return;
          const messageSnapshot = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_accumulateMessage).call(this, event);
          this._emit("streamEvent", event, messageSnapshot);
          switch (event.type) {
            case "content_block_delta": {
              const content = messageSnapshot.content.at(-1);
              switch (event.delta.type) {
                case "text_delta": {
                  if (content.type === "text") {
                    this._emit("text", event.delta.text, content.text || "");
                  }
                  break;
                }
                case "citations_delta": {
                  if (content.type === "text") {
                    this._emit("citation", event.delta.citation, content.citations ?? []);
                  }
                  break;
                }
                case "input_json_delta": {
                  if (tracksToolInput(content) && tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f").inputJson?.length) {
                    let jsonSnapshot;
                    try {
                      jsonSnapshot = content.input;
                    } catch (err) {
                      tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_handleError, "f").call(this, tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_toolInputParseError).call(this, content, err));
                      break;
                    }
                    this._emit("inputJson", event.delta.partial_json, jsonSnapshot);
                  }
                  break;
                }
                case "thinking_delta": {
                  if (content.type === "thinking") {
                    this._emit("thinking", event.delta.thinking, content.thinking);
                  }
                  break;
                }
                case "signature_delta": {
                  if (content.type === "thinking") {
                    this._emit("signature", content.signature);
                  }
                  break;
                }
                case "compaction_delta": {
                  if (content.type === "compaction" && content.content) {
                    this._emit("compaction", content.content);
                  }
                  break;
                }
                default:
                  (0, values_1.checkNever)(event.delta);
              }
              break;
            }
            case "message_stop": {
              this._addMessageParam(messageSnapshot);
              this._addMessage((0, beta_parser_1.maybeParseBetaMessage)(messageSnapshot, tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_params, "f"), { logger: tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_logger, "f") }), true);
              break;
            }
            case "content_block_stop": {
              this._emit("contentBlock", messageSnapshot.content.at(-1));
              break;
            }
            case "message_start": {
              tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_currentMessageSnapshot, messageSnapshot, "f");
              break;
            }
            case "content_block_start":
            case "message_delta":
              break;
          }
        }, _BetaMessageStream_endRequest = function _BetaMessageStream_endRequest2() {
          if (this.ended) {
            throw new error_1.AnthropicError(`stream has ended, this shouldn't happen`);
          }
          const snapshot = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_currentMessageSnapshot, "f");
          if (!snapshot) {
            throw new error_1.AnthropicError(`request ended without sending any chunks`);
          }
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_currentMessageSnapshot, void 0, "f");
          return (0, beta_parser_1.maybeParseBetaMessage)(snapshot, tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_params, "f"), { logger: tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_logger, "f") });
        }, _BetaMessageStream_accumulateMessage = function _BetaMessageStream_accumulateMessage2(event) {
          let snapshot = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_currentMessageSnapshot, "f");
          if (event.type === "message_start") {
            if (snapshot) {
              throw new error_1.AnthropicError(`Unexpected event order, got ${event.type} before receiving "message_stop"`);
            }
            return event.message;
          }
          if (!snapshot) {
            throw new error_1.AnthropicError(`Unexpected event order, got ${event.type} before "message_start"`);
          }
          switch (event.type) {
            case "message_stop":
              return snapshot;
            case "message_delta":
              snapshot.stop_reason = event.delta.stop_reason;
              snapshot.stop_sequence = event.delta.stop_sequence;
              snapshot.stop_details = event.delta.stop_details;
              snapshot.usage.output_tokens = event.usage.output_tokens;
              if (event.delta.container != null) {
                snapshot.container = event.delta.container;
              }
              if (event.context_management != null) {
                snapshot.context_management = event.context_management;
              }
              if (event.input_transformations != null) {
                snapshot.input_transformations = event.input_transformations;
              }
              if (event.usage.input_tokens != null) {
                snapshot.usage.input_tokens = event.usage.input_tokens;
              }
              if (event.usage.cache_creation_input_tokens != null) {
                snapshot.usage.cache_creation_input_tokens = event.usage.cache_creation_input_tokens;
              }
              if (event.usage.cache_read_input_tokens != null) {
                snapshot.usage.cache_read_input_tokens = event.usage.cache_read_input_tokens;
              }
              if (event.usage.server_tool_use != null) {
                snapshot.usage.server_tool_use = event.usage.server_tool_use;
              }
              if (event.usage.iterations != null) {
                snapshot.usage.iterations = event.usage.iterations;
              }
              if (event.usage.fallback_credit != null) {
                snapshot.usage.fallback_credit = event.usage.fallback_credit;
              }
              if (event.usage.output_tokens_details != null) {
                snapshot.usage.output_tokens_details = event.usage.output_tokens_details;
              }
              return snapshot;
            case "content_block_start":
              snapshot.content.push(event.content_block);
              if (event.content_block.type === "fallback") {
                snapshot.model = event.content_block.to.model;
              }
              return snapshot;
            case "content_block_delta": {
              const snapshotContent = snapshot.content.at(event.index);
              switch (event.delta.type) {
                case "text_delta": {
                  if (snapshotContent?.type === "text") {
                    snapshot.content[event.index] = {
                      ...snapshotContent,
                      text: (snapshotContent.text || "") + event.delta.text
                    };
                  }
                  break;
                }
                case "citations_delta": {
                  if (snapshotContent?.type === "text") {
                    snapshot.content[event.index] = {
                      ...snapshotContent,
                      citations: [...snapshotContent.citations ?? [], event.delta.citation]
                    };
                  }
                  break;
                }
                case "input_json_delta": {
                  if (snapshotContent && tracksToolInput(snapshotContent)) {
                    const jsonBuf = (snapshotContent[message_stream_utils_1.JSON_BUF_PROPERTY] || "") + event.delta.partial_json;
                    snapshot.content[event.index] = (0, message_stream_utils_1.withLazyInput)(snapshotContent, jsonBuf);
                  }
                  break;
                }
                case "thinking_delta": {
                  if (snapshotContent?.type === "thinking") {
                    snapshot.content[event.index] = {
                      ...snapshotContent,
                      thinking: snapshotContent.thinking + event.delta.thinking
                    };
                  }
                  break;
                }
                case "signature_delta": {
                  if (snapshotContent?.type === "thinking") {
                    snapshot.content[event.index] = {
                      ...snapshotContent,
                      signature: event.delta.signature
                    };
                  }
                  break;
                }
                case "compaction_delta": {
                  if (snapshotContent?.type === "compaction") {
                    const block = { ...snapshotContent, content: event.delta.content };
                    if ("encrypted_content" in event.delta) {
                      block.encrypted_content = event.delta.encrypted_content;
                    }
                    snapshot.content[event.index] = block;
                  }
                  break;
                }
                default:
                  (0, values_1.checkNever)(event.delta);
              }
              return snapshot;
            }
            case "content_block_stop": {
              const snapshotContent = snapshot.content.at(event.index);
              if (snapshotContent && tracksToolInput(snapshotContent) && message_stream_utils_1.JSON_BUF_PROPERTY in snapshotContent) {
                let input;
                try {
                  input = snapshotContent.input;
                } catch (err) {
                  input = {};
                  tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_handleError, "f").call(this, tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_toolInputParseError).call(this, snapshotContent, err));
                }
                Object.defineProperty(snapshotContent, "input", {
                  value: input,
                  enumerable: true,
                  configurable: true,
                  writable: true
                });
              }
              return snapshot;
            }
          }
        }, _BetaMessageStream_toolInputParseError = function _BetaMessageStream_toolInputParseError2(block, err) {
          const jsonBuf = block[message_stream_utils_1.JSON_BUF_PROPERTY];
          return new error_1.AnthropicError(`Unable to parse tool parameter JSON from model. Please retry your request or adjust your prompt. Error: ${err}. JSON: ${jsonBuf}`);
        }, Symbol.asyncIterator)]() {
          const pushQueue = [];
          const readQueue = [];
          let done = false;
          this.on("streamEvent", (event) => {
            const reader = readQueue.shift();
            if (reader) {
              reader.resolve(event);
            } else {
              pushQueue.push(event);
            }
          });
          this.on("end", () => {
            done = true;
            for (const reader of readQueue) {
              reader.resolve(void 0);
            }
            readQueue.length = 0;
          });
          this.on("abort", (err) => {
            done = true;
            for (const reader of readQueue) {
              reader.reject(err);
            }
            readQueue.length = 0;
          });
          this.on("error", (err) => {
            done = true;
            for (const reader of readQueue) {
              reader.reject(err);
            }
            readQueue.length = 0;
          });
          return {
            next: async () => {
              if (!pushQueue.length) {
                if (done) {
                  return { value: void 0, done: true };
                }
                return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
              }
              const chunk = pushQueue.shift();
              return { value: chunk, done: false };
            },
            return: async () => {
              this.abort();
              return { value: void 0, done: true };
            }
          };
        }
        toReadableStream() {
          const stream = new streaming_1.Stream(this[Symbol.asyncIterator].bind(this), this.controller);
          return stream.toReadableStream();
        }
      }
      return BetaMessageStream2;
    })();
    exports2.BetaMessageStream = BetaMessageStream;
  }
});

// node_modules/@anthropic-ai/sdk/lib/tools/CompactionControl.js
var require_CompactionControl = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/tools/CompactionControl.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DEFAULT_SUMMARY_PROMPT = exports2.DEFAULT_TOKEN_THRESHOLD = void 0;
    exports2.DEFAULT_TOKEN_THRESHOLD = 1e5;
    exports2.DEFAULT_SUMMARY_PROMPT = `You have been working on the task described above but have not yet completed it. Write a continuation summary that will allow you (or another instance of yourself) to resume work efficiently in a future context window where the conversation history will be replaced with this summary. Your summary should be structured, concise, and actionable. Include:
1. Task Overview
The user's core request and success criteria
Any clarifications or constraints they specified
2. Current State
What has been completed so far
Files created, modified, or analyzed (with paths if relevant)
Key outputs or artifacts produced
3. Important Discoveries
Technical constraints or requirements uncovered
Decisions made and their rationale
Errors encountered and how they were resolved
What approaches were tried that didn't work (and why)
4. Next Steps
Specific actions needed to complete the task
Any blockers or open questions to resolve
Priority order if multiple steps remain
5. Context to Preserve
User preferences or style requirements
Domain-specific details that aren't obvious
Any promises made to the user
Be concise but complete\u2014err on the side of including information that would prevent duplicate work or repeated mistakes. Write in a way that enables immediate resumption of the task.
Wrap your summary in <summary></summary> tags.`;
  }
});

// node_modules/@anthropic-ai/sdk/lib/tools/BetaToolRunner.js
var require_BetaToolRunner = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/tools/BetaToolRunner.js"(exports2) {
    "use strict";
    var _BetaToolRunner_instances;
    var _BetaToolRunner_consumed;
    var _BetaToolRunner_mutated;
    var _BetaToolRunner_state;
    var _BetaToolRunner_options;
    var _BetaToolRunner_message;
    var _BetaToolRunner_stream;
    var _BetaToolRunner_toolResponse;
    var _BetaToolRunner_completion;
    var _BetaToolRunner_iterationCount;
    var _BetaToolRunner_compaction;
    var _BetaToolRunner_lastStopReason;
    var _BetaToolRunner_toolOverrides;
    var _BetaToolRunner_pendingToolChanges;
    var _BetaToolRunner_checkAndCompact;
    var _BetaToolRunner_send;
    var _BetaToolRunner_compact;
    var _BetaToolRunner_runnableTools;
    var _BetaToolRunner_availableToolNames;
    var _BetaToolRunner_recordRemovalsFromHistory;
    var _BetaToolRunner_compactAfterFinalTurn;
    var _BetaToolRunner_generateToolResponse;
    var _BetaToolRunner_flushPendingToolChanges;
    var _BetaToolRunner_pendingToolChangesMessage;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BetaToolRunner = void 0;
    var tslib_1 = require_tslib();
    var ToolError_1 = require_ToolError();
    var error_1 = require_error();
    var headers_1 = require_headers();
    var promise_1 = require_promise();
    var values_1 = require_values();
    var log_1 = require_log();
    var CompactionControl_1 = require_CompactionControl();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var BetaToolRunner = /* @__PURE__ */ (() => {
      class BetaToolRunner2 {
        constructor(client, params, options) {
          _BetaToolRunner_instances.add(this);
          this.client = client;
          _BetaToolRunner_consumed.set(this, false);
          _BetaToolRunner_mutated.set(this, false);
          _BetaToolRunner_state.set(this, void 0);
          _BetaToolRunner_options.set(this, void 0);
          _BetaToolRunner_message.set(this, void 0);
          _BetaToolRunner_stream.set(this, void 0);
          _BetaToolRunner_toolResponse.set(this, void 0);
          _BetaToolRunner_completion.set(this, void 0);
          _BetaToolRunner_iterationCount.set(this, 0);
          _BetaToolRunner_compaction.set(this, { status: "idle" });
          _BetaToolRunner_lastStopReason.set(this, null);
          _BetaToolRunner_toolOverrides.set(this, /* @__PURE__ */ new Map());
          _BetaToolRunner_pendingToolChanges.set(this, []);
          rejectCompactionParam(params);
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_state, {
            params: {
              // You can't clone the entire params since there are functions as handlers.
              // You also don't really need to clone params.messages, but it probably will prevent a foot gun
              // somewhere.
              ...params,
              // Not structuredClone(): it throws on a function, and a runnable tool written by value into a
              // `tool_addition` block has `run`. A JSON copy is the messages as they are sent, which drops it.
              messages: JSON.parse(JSON.stringify(params.messages))
            }
          }, "f");
          const collected = (0, stainless_helper_header_1.collectStainlessHelpers)(params.tools, params.messages);
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_options, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              (0, stainless_helper_header_1.helperHeader)("BetaToolRunner"),
              collected.length ? { [stainless_helper_header_1.STAINLESS_HELPER_HEADER]: collected.join(", ") } : void 0,
              options?.headers
            ])
          }, "f");
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_completion, (0, promise_1.promiseWithResolvers)(), "f");
          if (params.compactionControl?.enabled) {
            console.warn('Anthropic: The `compactionControl` parameter is deprecated and will be removed in a future version. Use server-side compaction instead by passing `edits: [{ type: "compact_20260112" }]` in the params passed to `toolRunner()`. See https://platform.claude.com/docs/en/build-with-claude/compaction');
          }
        }
        async *[(_BetaToolRunner_consumed = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_mutated = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_state = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_options = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_message = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_stream = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_toolResponse = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_completion = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_iterationCount = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_compaction = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_lastStopReason = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_toolOverrides = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_pendingToolChanges = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_instances = /* @__PURE__ */ new WeakSet(), _BetaToolRunner_checkAndCompact = async function _BetaToolRunner_checkAndCompact2() {
          const compactionControl = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.compactionControl;
          if (!compactionControl || !compactionControl.enabled) {
            return false;
          }
          let tokensUsed = 0;
          if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f") !== void 0) {
            try {
              const message = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f");
              const totalInputTokens = message.usage.input_tokens + (message.usage.cache_creation_input_tokens ?? 0) + (message.usage.cache_read_input_tokens ?? 0);
              tokensUsed = totalInputTokens + message.usage.output_tokens;
            } catch {
              return false;
            }
          }
          const threshold = compactionControl.contextTokenThreshold ?? CompactionControl_1.DEFAULT_TOKEN_THRESHOLD;
          if (tokensUsed < threshold) {
            return false;
          }
          const model = compactionControl.model ?? tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.model;
          const summaryPrompt = compactionControl.summaryPrompt ?? CompactionControl_1.DEFAULT_SUMMARY_PROMPT;
          const messages = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages;
          if (messages[messages.length - 1].role === "assistant") {
            const lastMessage = messages[messages.length - 1];
            if (Array.isArray(lastMessage.content)) {
              const nonToolBlocks = lastMessage.content.filter((block) => block.type !== "tool_use");
              if (nonToolBlocks.length === 0) {
                messages.pop();
              } else {
                lastMessage.content = nonToolBlocks;
              }
            }
          }
          const response = await this.client.beta.messages.create({
            model,
            messages: [
              ...messages,
              {
                role: "user",
                content: [
                  {
                    type: "text",
                    text: summaryPrompt
                  }
                ]
              }
            ],
            max_tokens: tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.max_tokens
          }, {
            signal: tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f").signal,
            headers: (0, headers_1.buildHeaders)([tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f").headers, (0, stainless_helper_header_1.helperHeader)("compaction")])
          });
          if (response.content[0]?.type !== "text") {
            throw new error_1.AnthropicError("Expected text response for compaction");
          }
          tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_recordRemovalsFromHistory).call(this);
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_lastStopReason, null, "f");
          tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages = [
            {
              role: "user",
              content: asContentParam(response.content)
            }
          ];
          return true;
        }, Symbol.asyncIterator)]() {
          var _a;
          if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_consumed, "f")) {
            throw new error_1.AnthropicError("Cannot iterate over a consumed stream");
          }
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_consumed, true, "f");
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_mutated, true, "f");
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
          try {
            while (true) {
              try {
                if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.max_iterations && tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_iterationCount, "f") >= tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.max_iterations) {
                  break;
                }
                tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_flushPendingToolChanges).call(this);
                if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").status === "scheduled" && determineNextStepFromStopReason(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_lastStopReason, "f")) !== "resume") {
                  yield* tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_compact).call(this, tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").config);
                  continue;
                }
                tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_mutated, false, "f");
                tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
                tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_iterationCount, (_a = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_iterationCount, "f"), _a++, _a), "f");
                tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_message, void 0, "f");
                const { max_iterations, compactionControl, ...params } = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params;
                yield* tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_send).call(this, params);
                const isCompacted = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_checkAndCompact).call(this);
                if (!isCompacted) {
                  if (!tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_mutated, "f")) {
                    const message = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f");
                    const nextStep = determineNextStepFromStopReason(message.stop_reason);
                    tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_lastStopReason, message.stop_reason, "f");
                    tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.push({
                      role: message.role,
                      content: asContentParam(message.content)
                    });
                    const { container } = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params;
                    if (message.container) {
                      if (container == null) {
                        tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.container = message.container.id;
                      } else if (typeof container === "object" && container.id == null) {
                        tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.container = { ...container, id: message.container.id };
                      }
                    }
                    if (nextStep === "stop") {
                      yield* tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_compactAfterFinalTurn).call(this);
                      break;
                    }
                    if (nextStep === "resume") {
                      continue;
                    }
                  } else {
                    tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_lastStopReason, null, "f");
                  }
                  const toolMessage = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_generateToolResponse).call(this, tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.at(-1));
                  if (toolMessage) {
                    tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.push(toolMessage);
                  } else if (!tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_mutated, "f")) {
                    yield* tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_compactAfterFinalTurn).call(this);
                    break;
                  }
                }
              } finally {
                tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_stream, "f")?.abort();
                tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_stream, void 0, "f");
              }
            }
            if (!tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f")) {
              throw new error_1.AnthropicError("ToolRunner concluded without a message from the server");
            }
            tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_completion, "f").resolve(await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f"));
          } catch (error) {
            tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_consumed, false, "f");
            tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_completion, "f").promise.catch(() => {
            });
            tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_completion, "f").reject(error);
            tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_completion, (0, promise_1.promiseWithResolvers)(), "f");
            throw error;
          }
        }
        setMessagesParams(paramsOrMutator) {
          const params = typeof paramsOrMutator === "function" ? paramsOrMutator(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params) : paramsOrMutator;
          rejectCompactionParam(params);
          if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").status !== "idle") {
            rejectCompactionEdit(params);
          }
          if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").status === "in_flight" && params.messages !== tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages) {
            throw new error_1.AnthropicError("Message params can't be changed while the conversation is being compacted, because the compaction response is about to replace them. Change them after this iteration instead.");
          }
          tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params = params;
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_mutated, true, "f");
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
        }
        setRequestOptions(optionsOrMutator) {
          if (typeof optionsOrMutator === "function") {
            tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_options, optionsOrMutator(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f")), "f");
          } else {
            tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_options, { ...tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f"), ...optionsOrMutator }, "f");
          }
        }
        /**
         * Get the tool response for the last message from the assistant.
         * Avoids redundant tool executions by caching results.
         *
         * @returns A promise that resolves to a BetaMessageParam containing tool results, or null if no tools need to be executed
         *
         * @example
         * const toolResponse = await runner.generateToolResponse();
         * if (toolResponse) {
         *   console.log('Tool results:', toolResponse.content);
         * }
         */
        async generateToolResponse(signal = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f").signal) {
          const message = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f") ?? this.params.messages.at(-1);
          if (!message) {
            return null;
          }
          return tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_generateToolResponse).call(this, message, signal);
        }
        /**
         * Wait for the async iterator to complete. This works even if the async iterator hasn't yet started, and
         * will wait for an instance to start and go to completion.
         *
         * @returns A promise that resolves to the final BetaMessage when the iterator completes
         *
         * @example
         * // Start consuming the iterator
         * for await (const message of runner) {
         *   console.log('Message:', message.content);
         * }
         *
         * // Meanwhile, wait for completion from another part of the code
         * const finalMessage = await runner.done();
         * console.log('Final response:', finalMessage.content);
         */
        done() {
          return tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_completion, "f").promise;
        }
        /**
         * Returns a promise indicating that the stream is done. Unlike .done(), this will eagerly read the stream:
         * * If the iterator has not been consumed, consume the entire iterator and return the final message from the
         * assistant.
         * * If the iterator has been consumed, waits for it to complete and returns the final message.
         *
         * @returns A promise that resolves to the final BetaMessage from the conversation
         * @throws {AnthropicError} If no messages were processed during the conversation
         *
         * @example
         * const finalMessage = await runner.runUntilDone();
         * console.log('Final response:', finalMessage.content);
         */
        async runUntilDone() {
          if (!tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_consumed, "f")) {
            for await (const _ of this) {
            }
          }
          return this.done();
        }
        /**
         * Get the current parameters being used by the ToolRunner.
         *
         * @returns A readonly view of the current ToolRunnerParams
         *
         * @example
         * const currentParams = runner.params;
         * console.log('Current model:', currentParams.model);
         * console.log('Message count:', currentParams.messages.length);
         */
        get params() {
          return tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params;
        }
        /**
         * Add one or more messages to the conversation history.
         *
         * @param messages - One or more BetaMessageParam objects to add to the conversation
         *
         * @example
         * runner.pushMessages(
         *   { role: 'user', content: 'Also, what about the weather in NYC?' }
         * );
         *
         * @example
         * // Adding multiple messages
         * runner.pushMessages(
         *   { role: 'user', content: 'What about NYC?' },
         *   { role: 'user', content: 'And Boston?' }
         * );
         */
        pushMessages(...messages) {
          this.setMessagesParams((params) => ({
            ...params,
            messages: [...params.messages, ...messages]
          }));
        }
        /**
         * Schedule a compaction of the conversation. Once the current turn has finished, including any tool
         * calls, the runner requests a summary and replaces the message history with the compaction response,
         * which is yielded like any other message. Requires the `compact-2026-09-04` beta.
         *
         * @param compaction - The config to send, as `messages.create()` takes it. Defaults to `{ type: 'summarize' }`
         *
         * @example
         * for await (const message of runner) {
         *   if (message.usage.input_tokens > 100_000) {
         *     runner.compactBeforeNextTurn();
         *   }
         * }
         */
        compactBeforeNextTurn(compaction) {
          if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").status === "in_flight") {
            return;
          }
          rejectCompactionEdit(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params);
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_compaction, { status: "scheduled", config: compaction ?? { type: "summarize" } }, "f");
        }
        /**
         * Give the model more tools without changing `params.tools`, which would miss the prompt cache.
         *
         * Each tool's whole definition is sent in a `tool_addition` block with the next request, and a
         * runnable tool replaces a runnable tool of the same name straight away, even for a call already in
         * the message being handled. A raw definition is only sent: the runner never runs it, and stops
         * running a tool of the same name. Requires the `inline-tools-2026-09-15` beta, which the runner does
         * not add for you.
         *
         * @param tools - Runnable tools (for example from `betaZodTool()`) or raw tool definitions
         *
         * @example
         * runner.addTools(queryDatabaseTool);
         */
        addTools(...tools) {
          for (const tool of tools) {
            if ("name" in tool) {
              tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_toolOverrides, "f").set(tool.name, "run" in tool ? tool : null);
            }
            tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_pendingToolChanges, "f").push({ type: "addition", tool });
          }
        }
        /**
         * Take tools away from the model without changing `params.tools`, which would miss the prompt cache.
         *
         * The tools stop being run straight away: a call to one of them, even one in the message being
         * handled, gets the same "not found" error result as a call to an unknown tool. The model is told
         * in a `tool_removal` block with the next request. Use {@link addTools} to bring a tool back.
         * Requires the `inline-tools-2026-09-15` beta, which the runner does not add for you.
         *
         * @param tools - The tools to remove, or their names
         *
         * @example
         * runner.removeTools('query_database');
         */
        removeTools(...tools) {
          for (const tool of tools) {
            const name = typeof tool === "string" ? tool : tool.name;
            tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_toolOverrides, "f").set(name, null);
            tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_pendingToolChanges, "f").push({ type: "removal", name });
          }
        }
        /**
         * Makes the ToolRunner directly awaitable, equivalent to calling .runUntilDone()
         * This allows using `await runner` instead of `await runner.runUntilDone()`
         */
        then(onfulfilled, onrejected) {
          return this.runUntilDone().then(onfulfilled, onrejected);
        }
      }
      _BetaToolRunner_send = /**
       * Sends one request and yields its message, or its stream when streaming. `#message` and `#stream` are set
       * before the yield, so they are there while the caller handles the item; the loop aborts the stream at the
       * end of the iteration.
       */
      async function* _BetaToolRunner_send2(params) {
        if (params.stream) {
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_stream, this.client.beta.messages.stream({ ...params }, tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f")), "f");
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_message, tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_stream, "f").finalMessage(), "f");
          tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f").catch(() => {
          });
          yield tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_stream, "f");
        } else {
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_message, this.client.beta.messages.create({ ...params, stream: false }, tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f")), "f");
          yield tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f");
        }
      }, _BetaToolRunner_compact = async function* _BetaToolRunner_compact2(compaction) {
        rejectCompactionEdit(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params);
        const { max_iterations, compactionControl, ...requestParams } = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params;
        const params = withoutCompactionIncompatibleParams(requestParams);
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_compaction, { status: "in_flight" }, "f");
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
        const lastMessage = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f");
        try {
          yield* tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_send).call(this, { ...params, compaction });
          const message = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f");
          if (message.content.some((block) => block.type === "compaction" && block.content)) {
            tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_recordRemovalsFromHistory).call(this);
            tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages = [{ role: message.role, content: message.content }];
          } else {
            (0, log_1.loggerFor)(this.client).warn("Compaction produced no summary; keeping the conversation as it is.");
            tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_message, lastMessage, "f");
          }
        } finally {
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_compaction, { status: "idle" }, "f");
        }
      }, _BetaToolRunner_runnableTools = function _BetaToolRunner_runnableTools2() {
        const runnable = /* @__PURE__ */ new Map();
        for (const tool of tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.tools) {
          if ("run" in tool) {
            runnable.set(tool.name, tool);
          }
        }
        for (const [name, tool] of tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_toolOverrides, "f")) {
          if (tool) {
            runnable.set(name, tool);
          } else {
            runnable.delete(name);
          }
        }
        return runnable;
      }, _BetaToolRunner_availableToolNames = function _BetaToolRunner_availableToolNames2() {
        const available = new Set(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_runnableTools).call(this).keys());
        for (const message of [...tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages, tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_pendingToolChangesMessage).call(this)]) {
          if (typeof message.content === "string") {
            continue;
          }
          for (const block of message.content) {
            if (message.role === "system") {
              applyToolChange(block, available);
            } else if (message.role === "assistant" && block.type === "compaction") {
              for (const change of block.tool_changes ?? []) {
                applyToolChange(change, available);
              }
            }
          }
        }
        return available;
      }, _BetaToolRunner_recordRemovalsFromHistory = function _BetaToolRunner_recordRemovalsFromHistory2() {
        const available = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_availableToolNames).call(this);
        for (const name of tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_runnableTools).call(this).keys()) {
          if (!available.has(name)) {
            tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_toolOverrides, "f").set(name, null);
          }
        }
      }, _BetaToolRunner_compactAfterFinalTurn = async function* _BetaToolRunner_compactAfterFinalTurn2() {
        if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").status !== "scheduled") {
          return;
        }
        const lastContent = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.at(-1)?.content;
        if (Array.isArray(lastContent) && lastContent.some((block) => block.type === "tool_use")) {
          (0, log_1.loggerFor)(this.client).warn("The pending compaction was skipped because the last turn ended with tool calls that were not run. Call `compactBeforeNextTurn()` again if you continue the conversation.");
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_compaction, { status: "idle" }, "f");
          return;
        }
        yield* tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_compact).call(this, tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_compaction, "f").config);
      }, _BetaToolRunner_generateToolResponse = async function _BetaToolRunner_generateToolResponse2(lastMessage, signal = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f").signal) {
        if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_toolResponse, "f") !== void 0) {
          return tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_toolResponse, "f");
        }
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_toolResponse, generateToolResponse(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_runnableTools).call(this), tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_availableToolNames).call(this), lastMessage, { ...tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f"), signal }), "f");
        return tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_toolResponse, "f");
      }, _BetaToolRunner_flushPendingToolChanges = function _BetaToolRunner_flushPendingToolChanges2() {
        if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_lastStopReason, "f") === "pause_turn" || tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_pendingToolChanges, "f").length === 0) {
          return;
        }
        tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.push(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_pendingToolChangesMessage).call(this));
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_pendingToolChanges, [], "f");
      }, _BetaToolRunner_pendingToolChangesMessage = function _BetaToolRunner_pendingToolChangesMessage2() {
        const content = [];
        for (const change of tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_pendingToolChanges, "f")) {
          if (change.type === "removal") {
            content.push({ type: "tool_removal", tool: { type: "tool_reference", name: change.name } });
            continue;
          }
          let definition = change.tool;
          if ("run" in change.tool) {
            const { run, parse, close, ...rest } = change.tool;
            definition = rest;
          }
          content.push({ type: "tool_addition", tool: { type: "tool_definition", definition } });
        }
        return { role: "system", content };
      };
      return BetaToolRunner2;
    })();
    exports2.BetaToolRunner = BetaToolRunner;
    function rejectCompactionParam(params) {
      if ("compaction" in params && params.compaction != null) {
        throw new error_1.AnthropicError("`compaction` cannot be set on a tool runner: every request in the loop would compact again. Call `runner.compactBeforeNextTurn()` when the conversation should be compacted instead.");
      }
    }
    function rejectCompactionEdit(params) {
      if (params.context_management?.edits?.some((edit) => edit.type.startsWith("compact_"))) {
        throw new error_1.AnthropicError("`compactBeforeNextTurn()` can't be used while `context_management` has a compaction edit, because the API doesn't accept a compaction block together with one. Remove the edit first.");
      }
    }
    function withoutCompactionIncompatibleParams(params) {
      const { context_management, stop_sequences, output_format, ...kept } = params;
      const withoutFormat = ({ format, ...outputConfig }) => outputConfig;
      if (kept.tool_choice?.type === "any" || kept.tool_choice?.type === "tool") {
        delete kept.tool_choice;
      }
      if (kept.output_config) {
        kept.output_config = withoutFormat(kept.output_config);
      }
      if (Array.isArray(kept.fallbacks)) {
        kept.fallbacks = kept.fallbacks.map((fallback) => fallback.output_config ? { ...fallback, output_config: withoutFormat(fallback.output_config) } : fallback);
      }
      return kept;
    }
    async function generateToolResponse(runnable, available, lastMessage, requestOptions) {
      if (!lastMessage || lastMessage.role !== "assistant" || !lastMessage.content || typeof lastMessage.content === "string") {
        return null;
      }
      const toolUseBlocks = lastMessage.content.filter((content) => content.type === "tool_use");
      if (toolUseBlocks.length === 0) {
        return null;
      }
      const toolResults = await Promise.all(toolUseBlocks.map(async (toolUse) => {
        const tool = available.has(toolUse.name) ? runnable.get(toolUse.name) : void 0;
        if (!tool) {
          return toolNotFoundResult(toolUse);
        }
        try {
          let input = toolUse.input;
          if ("parse" in tool && tool.parse) {
            input = tool.parse(input);
          }
          const result = await tool.run(input, {
            toolUse,
            toolUseBlock: toolUse,
            signal: requestOptions?.signal
          });
          return {
            type: "tool_result",
            tool_use_id: toolUse.id,
            content: result
          };
        } catch (error) {
          return {
            type: "tool_result",
            tool_use_id: toolUse.id,
            content: error instanceof ToolError_1.ToolError ? error.content : `Error: ${error instanceof Error ? error.message : String(error)}`,
            is_error: true
          };
        }
      }));
      return {
        role: "user",
        content: toolResults
      };
    }
    function asContentParam(content) {
      return content;
    }
    function toolNotFoundResult(toolUse) {
      return {
        type: "tool_result",
        tool_use_id: toolUse.id,
        content: `Error: Tool '${toolUse.name}' not found`,
        is_error: true
      };
    }
    function applyToolChange(block, available) {
      switch (block.type) {
        case "tool_removal":
        case "tool_addition":
          applyToolReference(block, available);
          break;
      }
    }
    function applyToolReference(block, available) {
      const name = changedToolName(block.tool);
      if (name === void 0)
        return;
      if (block.type === "tool_removal") {
        available.delete(name);
      } else {
        available.add(name);
      }
    }
    function changedToolName(tool) {
      switch (tool.type) {
        case "tool_reference":
          return tool.name;
        case "tool_definition":
          return "name" in tool.definition ? tool.definition.name : void 0;
        default:
          return void 0;
      }
    }
    function determineNextStepFromStopReason(stopReason) {
      if (stopReason === null)
        return "stop";
      switch (stopReason) {
        case "tool_use":
          return "run_tools";
        case "pause_turn":
        // pause_after_compaction hands the turn back before the model answers; sending it back
        // unchanged continues it.
        case "compaction":
          return "resume";
        case "end_turn":
        case "stop_sequence":
        case "max_tokens":
        case "model_context_window_exceeded":
        case "refusal":
          return "stop";
        default:
          (0, values_1.checkNever)(stopReason);
          return "stop";
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/messages/messages.js
var require_messages = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/messages/messages.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ToolError = exports2.BetaToolRunner = exports2.Messages = void 0;
    var tslib_1 = require_tslib();
    var error_1 = require_error2();
    var BatchesAPI = tslib_1.__importStar(require_batches());
    var resource_1 = require_resource();
    var constants_1 = require_constants();
    var headers_1 = require_headers();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var beta_parser_1 = require_beta_parser();
    var BetaMessageStream_1 = require_BetaMessageStream();
    var BetaToolRunner_1 = require_BetaToolRunner();
    var ToolError_1 = require_ToolError();
    var batches_1 = require_batches();
    var DEPRECATED_MODELS = {};
    var MODELS_TO_WARN_WITH_THINKING_ENABLED = ["claude-mythos-preview", "claude-opus-4-6"];
    var Messages = /* @__PURE__ */ (() => {
      class Messages2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.batches = new BatchesAPI.Batches(this._client);
        }
        create(params, options) {
          const modifiedParams = transformOutputFormat(params);
          const { betas, user_profile_id, workspace_id, ...body } = modifiedParams;
          if (body.model in DEPRECATED_MODELS) {
            console.warn(`The model '${body.model}' is deprecated and will reach end-of-life on ${DEPRECATED_MODELS[body.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`);
          }
          if (MODELS_TO_WARN_WITH_THINKING_ENABLED.includes(body.model) && body.thinking && body.thinking.type === "enabled") {
            console.warn(`Using Claude with ${body.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
          }
          let timeout = options?.timeout ?? this._client._options.timeout;
          if (!body.stream && timeout == null) {
            const maxNonstreamingTokens = constants_1.MODEL_NONSTREAMING_TOKENS[body.model] ?? void 0;
            timeout = this._client.calculateNonstreamingTimeout(body.max_tokens, maxNonstreamingTokens);
          }
          const helperHeader = (0, stainless_helper_header_1.stainlessHelperHeader)(body.tools, body.messages);
          return this._client.post("/v1/messages?beta=true", {
            body,
            timeout: timeout ?? 6e5,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
                ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              helperHeader,
              options?.headers
            ]),
            stream: modifiedParams.stream ?? false
          });
        }
        /**
         * Send a structured list of input messages with text and/or image content, along with an expected `output_format` and
         * the response will be automatically parsed and available in the `parsed_output` property of the message.
         *
         * @example
         * ```ts
         * const message = await client.beta.messages.parse({
         *   model: 'claude-3-5-sonnet-20241022',
         *   max_tokens: 1024,
         *   messages: [{ role: 'user', content: 'What is 2+2?' }],
         *   output_format: zodOutputFormat(z.object({ answer: z.number() }), 'math'),
         * });
         *
         * console.log(message.parsed_output?.answer); // 4
         * ```
         */
        parse(params, options) {
          options = {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { "anthropic-beta": [...params.betas ?? [], "structured-outputs-2025-12-15"].toString() },
              options?.headers
            ])
          };
          return this.create(params, options).then((message) => (0, beta_parser_1.parseBetaMessage)(message, params, { logger: this._client.logger ?? console }));
        }
        /**
         * Create a Message stream
         */
        stream(body, options) {
          return BetaMessageStream_1.BetaMessageStream.createMessage(this, body, options);
        }
        /**
         * Count the number of tokens in a Message.
         *
         * The Token Count API can be used to count the number of tokens in a Message,
         * including tools, images, and documents, without creating it.
         *
         * Learn more about token counting in our
         * [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)
         *
         * @example
         * ```ts
         * const betaMessageTokensCount =
         *   await client.beta.messages.countTokens({
         *     messages: [{ content: 'Hello, world', role: 'user' }],
         *     model: 'claude-opus-5',
         *   });
         * ```
         */
        countTokens(params, options) {
          const modifiedParams = transformOutputFormat(params);
          const { betas, user_profile_id, workspace_id, ...body } = modifiedParams;
          return this._client.post("/v1/messages/count_tokens?beta=true", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "token-counting-2024-11-01"].toString(),
                ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        toolRunner(body, options) {
          return new BetaToolRunner_1.BetaToolRunner(this._client, body, options);
        }
      }
      Messages2.Batches = batches_1.Batches;
      Messages2.BetaToolRunner = BetaToolRunner_1.BetaToolRunner;
      Messages2.ToolError = ToolError_1.ToolError;
      return Messages2;
    })();
    exports2.Messages = Messages;
    function transformOutputFormat(params) {
      if (!params.output_format) {
        return params;
      }
      if (params.output_config?.format) {
        throw new error_1.AnthropicError("Both output_format and output_config.format were provided. Please use only output_config.format (output_format is deprecated).");
      }
      const { output_format, ...rest } = params;
      return {
        ...rest,
        output_config: {
          ...params.output_config,
          format: output_format
        }
      };
    }
    var BetaToolRunner_2 = require_BetaToolRunner();
    Object.defineProperty(exports2, "BetaToolRunner", { enumerable: true, get: function() {
      return BetaToolRunner_2.BetaToolRunner;
    } });
    var ToolError_2 = require_ToolError();
    Object.defineProperty(exports2, "ToolError", { enumerable: true, get: function() {
      return ToolError_2.ToolError;
    } });
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/api-keys.js
var require_api_keys = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/api-keys.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.APIKeys = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var path_1 = require_path();
    var APIKeys = class extends resource_1.APIResource {
      /**
       * Get API Key
       *
       * @example
       * ```ts
       * const betaAPIKey =
       *   await client.beta.organization.apiKeys.retrieve(
       *     'api_key_id',
       *   );
       * ```
       */
      retrieve(apiKeyID, options) {
        return this._client.get((0, path_1.path)`/v1/organizations/api_keys/${apiKeyID}?beta=true`, options);
      }
      /**
       * Update API Key
       *
       * @example
       * ```ts
       * const betaAPIKey =
       *   await client.beta.organization.apiKeys.update(
       *     'api_key_id',
       *   );
       * ```
       */
      update(apiKeyID, body, options) {
        return this._client.post((0, path_1.path)`/v1/organizations/api_keys/${apiKeyID}?beta=true`, { body, ...options });
      }
      /**
       * List API Keys
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaAPIKey of client.beta.organization.apiKeys.list()) {
       *   // ...
       * }
       * ```
       */
      list(query = {}, options) {
        return this._client.getAPIList("/v1/organizations/api_keys?beta=true", pagination_1.Page, {
          query,
          ...options
        });
      }
    };
    exports2.APIKeys = APIKeys;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/compliance-settings.js
var require_compliance_settings = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/compliance-settings.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ComplianceSettings = void 0;
    var resource_1 = require_resource();
    var ComplianceSettings = class extends resource_1.APIResource {
      /**
       * Retrieve your organization's Compliance Settings.
       *
       * Compliance Settings is a singleton resource: there is exactly one per
       * organization, addressed without an identifier. The `state` field reflects
       * whether the Compliance API is enabled. An organization with a parent
       * organization reads the state inherited from the parent's configuration.
       *
       * @example
       * ```ts
       * const betaComplianceSettings =
       *   await client.beta.organization.complianceSettings.retrieve();
       * ```
       */
      retrieve(options) {
        return this._client.get("/v1/organizations/compliance_settings?beta=true", options);
      }
      /**
       * Update your organization's Compliance Settings.
       *
       * Setting `state` to `enabled` turns on the Compliance API and begins capturing
       * organization activity events. Setting it to `disabled` turns both off. `state`
       * reflects whether the Compliance API is enabled.
       *
       * A request that sets `state` to its current value succeeds and leaves the
       * resource unchanged. A `disabled` request stays in effect until a later `enabled`
       * request or the organization's next provisioning action that enables Access
       * Transparency: enabling Access Transparency also enables the Compliance API,
       * which serves its activity events, so such provisioning (including re-runs)
       * re-enables the Compliance API even after a `disabled` request. Automated
       * provisioning never disables compliance settings.
       *
       * @example
       * ```ts
       * const betaComplianceSettings =
       *   await client.beta.organization.complianceSettings.update({
       *     state: { type: 'enabled' },
       *   });
       * ```
       */
      update(body, options) {
        return this._client.post("/v1/organizations/compliance_settings?beta=true", { body, ...options });
      }
    };
    exports2.ComplianceSettings = ComplianceSettings;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/external-keys.js
var require_external_keys = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/external-keys.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ExternalKeys = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var path_1 = require_path();
    var ExternalKeys = class extends resource_1.APIResource {
      /**
       * Create an external key config owned by the caller's organization.
       *
       * @example
       * ```ts
       * const betaExternalKey =
       *   await client.beta.organization.externalKeys.create({
       *     provider_config: {
       *       kms_arn:
       *         'arn:aws:kms:us-east-1:111122223333:key/abcd1234-5678-90ab-cdef-000011112222',
       *       type: 'aws',
       *     },
       *   });
       * ```
       */
      create(body, options) {
        return this._client.post("/v1/organizations/external_keys?beta=true", { body, ...options });
      }
      /**
       * Retrieve a single external key config in the caller's organization by ID.
       *
       * @example
       * ```ts
       * const betaExternalKey =
       *   await client.beta.organization.externalKeys.retrieve(
       *     'external_key_id',
       *   );
       * ```
       */
      retrieve(externalKeyID, options) {
        return this._client.get((0, path_1.path)`/v1/organizations/external_keys/${externalKeyID}?beta=true`, options);
      }
      /**
       * Partially update an external key config. Omitted fields are left unchanged.
       *
       * `display_name` is always editable. `geo` and `provider_config` cannot be changed
       * once any workspace references this config, because previously encrypted data
       * requires the original key identity to decrypt.
       *
       * @example
       * ```ts
       * const betaExternalKey =
       *   await client.beta.organization.externalKeys.update(
       *     'external_key_id',
       *   );
       * ```
       */
      update(externalKeyID, body, options) {
        return this._client.post((0, path_1.path)`/v1/organizations/external_keys/${externalKeyID}?beta=true`, {
          body,
          ...options
        });
      }
      /**
       * List external key configs in the caller's organization.
       *
       * Results are ordered by creation time (newest first). Use the `next_page` cursor
       * from the response to fetch subsequent pages.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaExternalKey of client.beta.organization.externalKeys.list()) {
       *   // ...
       * }
       * ```
       */
      list(query = {}, options) {
        return this._client.getAPIList("/v1/organizations/external_keys?beta=true", pagination_1.PageCursor, {
          query,
          ...options
        });
      }
      /**
       * Delete an external key config.
       *
       * The request is rejected if any workspace still references this config.
       *
       * @example
       * ```ts
       * const externalKey =
       *   await client.beta.organization.externalKeys.delete(
       *     'external_key_id',
       *   );
       * ```
       */
      delete(externalKeyID, options) {
        return this._client.delete((0, path_1.path)`/v1/organizations/external_keys/${externalKeyID}?beta=true`, options);
      }
      /**
       * Validate an external key config against the customer's KMS.
       *
       * Anthropic performs an encrypt/decrypt roundtrip against the configured KMS key
       * and waits up to 30 seconds for the result. The response status is `success` if
       * the roundtrip succeeded, or `failure` with an error message if it failed or
       * timed out.
       *
       * @example
       * ```ts
       * const response =
       *   await client.beta.organization.externalKeys.validate(
       *     'external_key_id',
       *   );
       * ```
       */
      validate(externalKeyID, options) {
        return this._client.post((0, path_1.path)`/v1/organizations/external_keys/${externalKeyID}/validate?beta=true`, options);
      }
    };
    exports2.ExternalKeys = ExternalKeys;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/invites.js
var require_invites = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/invites.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Invites = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var path_1 = require_path();
    var Invites = class extends resource_1.APIResource {
      /**
       * Invite a user to join the organization by email.
       *
       * On plans that draw members from a finite pool of purchased seats, the invite
       * automatically consumes a seat from the lowest tier with availability; there is
       * no seat-tier parameter. When no seat is free the request fails with a 400 error
       * rather than purchasing a seat.
       *
       * @example
       * ```ts
       * const betaOrganizationInvite =
       *   await client.beta.organization.invites.create({
       *     email: 'user@emaildomain.com',
       *     role: 'user',
       *   });
       * ```
       */
      create(body, options) {
        return this._client.post("/v1/organizations/invites?beta=true", { body, ...options });
      }
      /**
       * Retrieve an invite by ID.
       *
       * @example
       * ```ts
       * const betaOrganizationInvite =
       *   await client.beta.organization.invites.retrieve(
       *     'invite_id',
       *   );
       * ```
       */
      retrieve(inviteID, options) {
        return this._client.get((0, path_1.path)`/v1/organizations/invites/${inviteID}?beta=true`, options);
      }
      /**
       * List the organization's invites.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaOrganizationInvite of client.beta.organization.invites.list()) {
       *   // ...
       * }
       * ```
       */
      list(query = {}, options) {
        return this._client.getAPIList("/v1/organizations/invites?beta=true", pagination_1.Page, {
          query,
          ...options
        });
      }
      /**
       * Delete a pending invite.
       *
       * @example
       * ```ts
       * const invite =
       *   await client.beta.organization.invites.delete(
       *     'invite_id',
       *   );
       * ```
       */
      delete(inviteID, options) {
        return this._client.delete((0, path_1.path)`/v1/organizations/invites/${inviteID}?beta=true`, options);
      }
    };
    exports2.Invites = Invites;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/rate-limits.js
var require_rate_limits = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/rate-limits.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RateLimits = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var RateLimits = class extends resource_1.APIResource {
      /**
       * List Messages API rate limits for your organization.
       *
       * Each entry corresponds to one rate-limit group (either a model family or an
       * API-surface category such as the Files API or Message Batches) and contains the
       * set of limiter values that apply to it.
       *
       * When `limit` is omitted, every matching entry is returned in a single page; when
       * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaOrganizationRateLimit of client.beta.organization.rateLimits.list()) {
       *   // ...
       * }
       * ```
       */
      list(query = {}, options) {
        return this._client.getAPIList("/v1/organizations/rate_limits?beta=true", pagination_1.PageCursor, { query, ...options });
      }
    };
    exports2.RateLimits = RateLimits;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/users.js
var require_users = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/users.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Users = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var path_1 = require_path();
    var Users = class extends resource_1.APIResource {
      /**
       * Retrieve a member of the organization by user ID.
       *
       * @example
       * ```ts
       * const betaOrganizationUser =
       *   await client.beta.organization.users.retrieve('user_id');
       * ```
       */
      retrieve(userID, options) {
        return this._client.get((0, path_1.path)`/v1/organizations/users/${userID}?beta=true`, options);
      }
      /**
       * Update a member's organization role.
       *
       * @example
       * ```ts
       * const betaOrganizationUser =
       *   await client.beta.organization.users.update('user_id', {
       *     role: 'user',
       *   });
       * ```
       */
      update(userID, body, options) {
        return this._client.post((0, path_1.path)`/v1/organizations/users/${userID}?beta=true`, { body, ...options });
      }
      /**
       * List the organization's members.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaOrganizationUser of client.beta.organization.users.list()) {
       *   // ...
       * }
       * ```
       */
      list(query = {}, options) {
        return this._client.getAPIList("/v1/organizations/users?beta=true", pagination_1.Page, {
          query,
          ...options
        });
      }
      /**
       * Remove a member from the organization.
       *
       * @example
       * ```ts
       * const user = await client.beta.organization.users.remove(
       *   'user_id',
       * );
       * ```
       */
      remove(userID, options) {
        return this._client.delete((0, path_1.path)`/v1/organizations/users/${userID}?beta=true`, options);
      }
    };
    exports2.Users = Users;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/issuers.js
var require_issuers = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/issuers.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Issuers = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Issuers = class extends resource_1.APIResource {
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Register an OIDC issuer that Anthropic will trust for workload identity
       * federation in your organization.
       *
       * The `jwks` field controls how the issuer's signing keys are obtained and takes
       * one of three shapes selected by `type`: `discovery` (resolve keys through OIDC
       * discovery), `explicit_url` (fetch keys from a fixed JWKS URL), or `inline`
       * (provide a static key set). When `jwks.type` is `discovery` and no
       * `discovery_base` is set, the issuer URL must be publicly reachable over HTTPS so
       * Anthropic can fetch the discovery document; for `explicit_url` and `inline`
       * modes the issuer URL is only matched as the JWT's `iss` claim and is not
       * fetched.
       *
       * @example
       * ```ts
       * const betaFederationIssuer =
       *   await client.beta.organization.federation.issuers.create({
       *     issuer_url: 'x',
       *     name: 'x',
       *   });
       * ```
       */
      create(params, options) {
        const { betas, ...body } = params;
        return this._client.post("/v1/organizations/federation_issuers?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Retrieve a federation issuer by its ID (`fdis_...`).
       *
       * @example
       * ```ts
       * const betaFederationIssuer =
       *   await client.beta.organization.federation.issuers.retrieve(
       *     'federation_issuer_id',
       *   );
       * ```
       */
      retrieve(federationIssuerID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/organizations/federation_issuers/${federationIssuerID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Partially update a federation issuer.
       *
       * Setting `jwks` replaces the full JWKS shape at once. Archived issuers cannot be
       * updated; this returns 400. Create a new issuer instead.
       *
       * Updating an issuer that backs a rule with a scope outside `workspace:developer`
       * or `workspace:inference` requires a Console session.
       *
       * @example
       * ```ts
       * const betaFederationIssuer =
       *   await client.beta.organization.federation.issuers.update(
       *     'federation_issuer_id',
       *   );
       * ```
       */
      update(federationIssuerID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/organizations/federation_issuers/${federationIssuerID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * List federation issuers in your organization.
       *
       * Archived issuers are excluded unless `include_archived=true`.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaFederationIssuer of client.beta.organization.federation.issuers.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/organizations/federation_issuers?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Archive a federation issuer.
       *
       * Idempotent; re-archiving returns the issuer with its original `archived_at`.
       * Rejected with 400 if any live (non-archived) federation rule still references
       * the issuer; archive those rules first (a rule's issuer cannot be changed), or
       * recreate them against another issuer.
       *
       * @example
       * ```ts
       * const betaFederationIssuer =
       *   await client.beta.organization.federation.issuers.archive(
       *     'federation_issuer_id',
       *   );
       * ```
       */
      archive(federationIssuerID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/organizations/federation_issuers/${federationIssuerID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
    };
    exports2.Issuers = Issuers;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/rules/workspaces.js
var require_workspaces = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/rules/workspaces.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Workspaces = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Workspaces = class extends resource_1.APIResource {
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * List workspaces where this federation rule is enabled.
       *
       * Returns all workspace enablements in a single response; the `limit` and `page`
       * parameters are accepted but have no effect, and `next_page` is always `null`.
       * Returns explicit per-workspace enablements only; for rules with
       * `applies_to_all_workspaces` or a legacy single `workspace_id`, check those
       * fields on the rule itself.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaFederationRuleWorkspace of client.beta.organization.federation.rules.workspaces.list(
       *   'federation_rule_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(federationRuleID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/organizations/federation_rules/${federationRuleID}/workspaces?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Enable a federation rule for a workspace.
       *
       * Idempotent; re-enabling returns the existing enablement. The rule and workspace
       * must both belong to your organization. Membership of the rule's target service
       * account in this workspace is not checked at enablement: token exchange into this
       * workspace is rejected unless the target is a member (it is implicitly a member
       * of the default workspace). Archived rules are rejected with 400. OAuth callers
       * may only manage rules whose `oauth_scope` is `workspace:developer` or
       * `workspace:inference`; other scopes require a Console session.
       *
       * @example
       * ```ts
       * const betaFederationRuleWorkspace =
       *   await client.beta.organization.federation.rules.workspaces.add(
       *     'federation_rule_id',
       *     { workspace_id: 'workspace_id' },
       *   );
       * ```
       */
      add(federationRuleID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/organizations/federation_rules/${federationRuleID}/workspaces?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Disable a federation rule for a workspace.
       *
       * Idempotent; succeeds even if the enablement was already removed. OAuth callers
       * may only manage rules whose `oauth_scope` is `workspace:developer` or
       * `workspace:inference`; other scopes require a Console session.
       *
       * @example
       * ```ts
       * const workspace =
       *   await client.beta.organization.federation.rules.workspaces.remove(
       *     'workspace_id',
       *     { federation_rule_id: 'federation_rule_id' },
       *   );
       * ```
       */
      remove(workspaceID, params, options) {
        const { federation_rule_id, betas } = params;
        return this._client.delete((0, path_1.path)`/v1/organizations/federation_rules/${federation_rule_id}/workspaces/${workspaceID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
    };
    exports2.Workspaces = Workspaces;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/rules/rules.js
var require_rules = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/rules/rules.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Rules = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var WorkspacesAPI = tslib_1.__importStar(require_workspaces());
    var workspaces_1 = require_workspaces();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Rules = /* @__PURE__ */ (() => {
      class Rules2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.workspaces = new WorkspacesAPI.Workspaces(this._client);
        }
        /**
         * **Requires an OAuth access token with the `org:admin` scope**, from
         * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
         * API keys are not accepted. See
         * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
         *
         * Create a federation rule owned by your organization.
         *
         * The referenced issuer and the target service account must already exist in the
         * same organization; invalid references are rejected with a 400 error. The
         * workspace reference is validated. Membership is not checked at rule creation:
         * token exchange resolves a single enabled workspace per call and is rejected
         * unless the target service account is a member of that workspace (it is
         * implicitly a member of the default workspace). Rules on well-known shared
         * issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud, Google) must
         * constrain tenant identity via an identity-bearing claim, a tenant-pinning
         * subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition referencing one
         * of those identity claims (e.g. `claims.repository_owner`). OAuth callers may
         * only manage rules whose `oauth_scope` is `workspace:developer` or
         * `workspace:inference`; other scopes require a Console session.
         *
         * @example
         * ```ts
         * const betaFederationRule =
         *   await client.beta.organization.federation.rules.create({
         *     issuer_id: 'issuer_id',
         *     match: {},
         *     name: 'x',
         *     oauth_scope: 'x',
         *     target: {
         *       service_account_id: 'svac_01SDCCSbTxrXDpWc1phhtcfK',
         *       type: 'service_account',
         *     },
         *   });
         * ```
         */
        create(params, options) {
          const { betas, ...body } = params;
          return this._client.post("/v1/organizations/federation_rules?beta=true", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * **Requires an OAuth access token with the `org:admin` scope**, from
         * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
         * API keys are not accepted. See
         * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
         *
         * Retrieve a federation rule by its ID (`fdrl_...`).
         *
         * @example
         * ```ts
         * const betaFederationRule =
         *   await client.beta.organization.federation.rules.retrieve(
         *     'federation_rule_id',
         *   );
         * ```
         */
        retrieve(federationRuleID, params = {}, options) {
          const { betas } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/organizations/federation_rules/${federationRuleID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * **Requires an OAuth access token with the `org:admin` scope**, from
         * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
         * API keys are not accepted. See
         * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
         *
         * Partially update a federation rule.
         *
         * `issuer_id` is immutable. `match` and `target` are replaced as whole objects
         * when set. Referenced service accounts and workspaces must exist in your
         * organization; invalid references are rejected with a 400 error. Archived rules
         * cannot be updated; this returns 400. Create a new rule instead. Rules on
         * well-known shared issuers (GitHub Actions, GitLab, Buildkite, Terraform Cloud,
         * Google) must constrain tenant identity via an identity-bearing claim, a
         * tenant-pinning subject prefix (such as `repo:YOUR_ORG/...`), or a CEL condition
         * referencing one of those identity claims (e.g. `claims.repository_owner`). On
         * these issuers the requirement is re-checked on every update; if an existing
         * rule's stored match does not yet constrain tenant identity, any update (even a
         * rename or description change) must also supply a conforming `match` in the same
         * request. OAuth callers may only manage rules whose `oauth_scope` is
         * `workspace:developer` or `workspace:inference`; other scopes require a Console
         * session.
         *
         * @example
         * ```ts
         * const betaFederationRule =
         *   await client.beta.organization.federation.rules.update(
         *     'federation_rule_id',
         *   );
         * ```
         */
        update(federationRuleID, params, options) {
          const { betas, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/organizations/federation_rules/${federationRuleID}?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * **Requires an OAuth access token with the `org:admin` scope**, from
         * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
         * API keys are not accepted. See
         * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
         *
         * List federation rules in your organization.
         *
         * Optionally filter by issuer with `issuer_id`. Archived rules are excluded unless
         * `include_archived=true`.
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaFederationRule of client.beta.organization.federation.rules.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
          const { betas, ...query } = params ?? {};
          return this._client.getAPIList("/v1/organizations/federation_rules?beta=true", pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * **Requires an OAuth access token with the `org:admin` scope**, from
         * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
         * API keys are not accepted. See
         * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
         *
         * Archive a federation rule.
         *
         * Token exchange through this rule stops immediately. Idempotent; re-archiving
         * returns the rule with its original `archived_at`. Archiving clears the rule's
         * workspace targeting (`workspace_id` and `workspace_ids` are emptied). Tokens
         * already minted before archive remain valid until they expire. OAuth callers may
         * only manage rules whose `oauth_scope` is `workspace:developer` or
         * `workspace:inference`; other scopes require a Console session.
         *
         * @example
         * ```ts
         * const betaFederationRule =
         *   await client.beta.organization.federation.rules.archive(
         *     'federation_rule_id',
         *   );
         * ```
         */
        archive(federationRuleID, params = {}, options) {
          const { betas } = params ?? {};
          return this._client.post((0, path_1.path)`/v1/organizations/federation_rules/${federationRuleID}/archive?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
      }
      Rules2.Workspaces = workspaces_1.Workspaces;
      return Rules2;
    })();
    exports2.Rules = Rules;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/federation.js
var require_federation = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/federation/federation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Federation = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var IssuersAPI = tslib_1.__importStar(require_issuers());
    var issuers_1 = require_issuers();
    var RulesAPI = tslib_1.__importStar(require_rules());
    var rules_1 = require_rules();
    var Federation = /* @__PURE__ */ (() => {
      class Federation2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.issuers = new IssuersAPI.Issuers(this._client);
          this.rules = new RulesAPI.Rules(this._client);
        }
      }
      Federation2.Issuers = issuers_1.Issuers;
      Federation2.Rules = rules_1.Rules;
      return Federation2;
    })();
    exports2.Federation = Federation;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/service-accounts/workspaces.js
var require_workspaces2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/service-accounts/workspaces.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Workspaces = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Workspaces = class extends resource_1.APIResource {
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * List the workspaces a service account is a member of.
       *
       * Each entry includes the service account's `workspace_role` in that workspace.
       * Use `limit` and the `next_page` cursor to paginate. When the service account has
       * no explicit default-workspace membership, the implicit (`implicit: true`)
       * membership is returned as the first entry on the first page; with `limit=1` the
       * first page may return up to 2 entries (the implicit entry plus one explicit
       * membership) so a pagination cursor can be derived. Memberships are returned only
       * while the service account is active. Without a `page` cursor, an archived
       * service account returns an empty list. A `page` cursor that does not match an
       * active membership returns a 400 invalid-request error. A cursor stops matching
       * when the membership is removed, the workspace is deleted, or the service account
       * is archived. Restart pagination from the first page to recover.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaServiceAccountWorkspaceMember of client.beta.organization.serviceAccounts.workspaces.list(
       *   'service_account_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(serviceAccountID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/organizations/service_accounts/${serviceAccountID}/workspaces?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Add a service account to a workspace with the given `workspace_role`.
       *
       * Mirror of `POST /workspaces/{workspace_id}/service_accounts`, addressed from the
       * service-account side; both create the same membership. If the service account is
       * already an explicit member of the workspace, its `workspace_role` is replaced
       * with the value supplied here. Archived workspaces return 400. Archived service
       * accounts cannot be added and are rejected.
       *
       * @example
       * ```ts
       * const betaServiceAccountWorkspaceMember =
       *   await client.beta.organization.serviceAccounts.workspaces.add(
       *     'service_account_id',
       *     {
       *       workspace_id: 'workspace_id',
       *       workspace_role: 'workspace_admin',
       *     },
       *   );
       * ```
       */
      add(serviceAccountID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/organizations/service_accounts/${serviceAccountID}/workspaces?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Remove a service account from a workspace.
       *
       * Mirror of
       * `DELETE /workspaces/{workspace_id}/service_accounts/{service_account_id}`,
       * addressed from the service-account side. Removal is idempotent (returns 200 even
       * if the membership was already removed). A DELETE against the implicit
       * default-workspace membership returns 200 but is a no-op and the membership
       * persists; deleting an explicit default-workspace row reverts to the implicit
       * `workspace_user` membership. Archived workspaces return 400.
       *
       * @example
       * ```ts
       * const workspace =
       *   await client.beta.organization.serviceAccounts.workspaces.remove(
       *     'workspace_id',
       *     { service_account_id: 'service_account_id' },
       *   );
       * ```
       */
      remove(workspaceID, params, options) {
        const { service_account_id, betas } = params;
        return this._client.delete((0, path_1.path)`/v1/organizations/service_accounts/${service_account_id}/workspaces/${workspaceID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
    };
    exports2.Workspaces = Workspaces;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/service-accounts/service-accounts.js
var require_service_accounts = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/service-accounts/service-accounts.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ServiceAccounts = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var WorkspacesAPI = tslib_1.__importStar(require_workspaces2());
    var workspaces_1 = require_workspaces2();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var ServiceAccounts = /* @__PURE__ */ (() => {
      class ServiceAccounts2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.workspaces = new WorkspacesAPI.Workspaces(this._client);
        }
        /**
         * **Requires an OAuth access token with the `org:admin` scope**, from
         * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
         * API keys are not accepted. See
         * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
         *
         * Create a service account.
         *
         * A service account is a named workload identity that federation rules target.
         * `organization_role` is `developer` (default) or `admin`; a rule may only be
         * created or retargeted to grant `org:admin` scope when the target's
         * `organization_role` is `admin`. Creating an `admin`-role service account
         * requires an interactive credential (a user OAuth token or a Console session) — a
         * workload may only create `developer`-role service accounts.
         *
         * @example
         * ```ts
         * const betaServiceAccount =
         *   await client.beta.organization.serviceAccounts.create({
         *     name: 'ci-deploy-bot',
         *   });
         * ```
         */
        create(params, options) {
          const { betas, ...body } = params;
          return this._client.post("/v1/organizations/service_accounts?beta=true", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * **Requires an OAuth access token with the `org:admin` scope**, from
         * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
         * API keys are not accepted. See
         * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
         *
         * Retrieve a service account by its ID (`svac_...`).
         *
         * @example
         * ```ts
         * const betaServiceAccount =
         *   await client.beta.organization.serviceAccounts.retrieve(
         *     'service_account_id',
         *   );
         * ```
         */
        retrieve(serviceAccountID, params = {}, options) {
          const { betas } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/organizations/service_accounts/${serviceAccountID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * **Requires an OAuth access token with the `org:admin` scope**, from
         * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
         * API keys are not accepted. See
         * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
         *
         * Update a service account.
         *
         * Only `description` and `organization_role` are mutable; `name` cannot be
         * changed. Archived service accounts cannot be updated; this returns 400. Setting
         * `organization_role` to `admin` (even when unchanged) requires an interactive
         * credential (a user OAuth token or a Console session).
         *
         * @example
         * ```ts
         * const betaServiceAccount =
         *   await client.beta.organization.serviceAccounts.update(
         *     'service_account_id',
         *   );
         * ```
         */
        update(serviceAccountID, params, options) {
          const { betas, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/organizations/service_accounts/${serviceAccountID}?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * **Requires an OAuth access token with the `org:admin` scope**, from
         * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
         * API keys are not accepted. See
         * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
         *
         * List service accounts in the caller's organization.
         *
         * Results are ordered by creation time, newest first. Use `limit` and the
         * `next_page` cursor to paginate; set `include_archived=true` to include archived
         * service accounts.
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaServiceAccount of client.beta.organization.serviceAccounts.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
          const { betas, ...query } = params ?? {};
          return this._client.getAPIList("/v1/organizations/service_accounts?beta=true", pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * **Requires an OAuth access token with the `org:admin` scope**, from
         * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
         * API keys are not accepted. See
         * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
         *
         * Archive a service account.
         *
         * Idempotent; re-archiving returns the service account with its original
         * `archived_at`. Rejected with 400 if any live (non-archived) federation rule
         * still targets this service account, same as issuer archival; archive those rules
         * first or change their target to another service account.
         *
         * @example
         * ```ts
         * const betaServiceAccount =
         *   await client.beta.organization.serviceAccounts.archive(
         *     'service_account_id',
         *   );
         * ```
         */
        archive(serviceAccountID, params = {}, options) {
          const { betas } = params ?? {};
          return this._client.post((0, path_1.path)`/v1/organizations/service_accounts/${serviceAccountID}/archive?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
      }
      ServiceAccounts2.Workspaces = workspaces_1.Workspaces;
      return ServiceAccounts2;
    })();
    exports2.ServiceAccounts = ServiceAccounts;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/members.js
var require_members = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/members.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Members = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var path_1 = require_path();
    var Members = class extends resource_1.APIResource {
      /**
       * Get Workspace Member
       *
       * @example
       * ```ts
       * const betaWorkspaceMember =
       *   await client.beta.organization.workspaces.members.retrieve(
       *     'user_id',
       *     { workspace_id: 'workspace_id' },
       *   );
       * ```
       */
      retrieve(userID, params, options) {
        const { workspace_id } = params;
        return this._client.get((0, path_1.path)`/v1/organizations/workspaces/${workspace_id}/members/${userID}?beta=true`, options);
      }
      /**
       * Update Workspace Member
       *
       * @example
       * ```ts
       * const betaWorkspaceMember =
       *   await client.beta.organization.workspaces.members.update(
       *     'user_id',
       *     {
       *       workspace_id: 'workspace_id',
       *       workspace_role: 'workspace_admin',
       *     },
       *   );
       * ```
       */
      update(userID, params, options) {
        const { workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/organizations/workspaces/${workspace_id}/members/${userID}?beta=true`, {
          body,
          ...options
        });
      }
      /**
       * List Workspace Members
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaWorkspaceMember of client.beta.organization.workspaces.members.list(
       *   'workspace_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(workspaceID, query = {}, options) {
        return this._client.getAPIList((0, path_1.path)`/v1/organizations/workspaces/${workspaceID}/members?beta=true`, pagination_1.Page, { query, ...options });
      }
      /**
       * Create Workspace Member
       *
       * @example
       * ```ts
       * const betaWorkspaceMember =
       *   await client.beta.organization.workspaces.members.add(
       *     'workspace_id',
       *     {
       *       user_id: 'user_01WCz1FkmYMm4gnmykNKUu3Q',
       *       workspace_role: 'workspace_admin',
       *     },
       *   );
       * ```
       */
      add(workspaceID, body, options) {
        return this._client.post((0, path_1.path)`/v1/organizations/workspaces/${workspaceID}/members?beta=true`, {
          body,
          ...options
        });
      }
      /**
       * Delete Workspace Member
       *
       * @example
       * ```ts
       * const member =
       *   await client.beta.organization.workspaces.members.remove(
       *     'user_id',
       *     { workspace_id: 'workspace_id' },
       *   );
       * ```
       */
      remove(userID, params, options) {
        const { workspace_id } = params;
        return this._client.delete((0, path_1.path)`/v1/organizations/workspaces/${workspace_id}/members/${userID}?beta=true`, options);
      }
    };
    exports2.Members = Members;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/rate-limits.js
var require_rate_limits2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/rate-limits.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RateLimits = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var path_1 = require_path();
    var RateLimits = class extends resource_1.APIResource {
      /**
       * List rate-limit overrides configured for a workspace.
       *
       * Returns only the groups and limiter types that have a workspace-level override.
       * Groups without overrides inherit the organization limits and are not listed; use
       * `GET /v1/organizations/rate_limits` to see those.
       *
       * When `limit` is omitted, every matching entry is returned in a single page; when
       * `limit` truncates the result, follow `next_page` to fetch the remaining entries.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaWorkspaceRateLimit of client.beta.organization.workspaces.rateLimits.list(
       *   'workspace_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(workspaceID, query = {}, options) {
        return this._client.getAPIList((0, path_1.path)`/v1/organizations/workspaces/${workspaceID}/rate_limits?beta=true`, pagination_1.PageCursor, { query, ...options });
      }
    };
    exports2.RateLimits = RateLimits;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/service-accounts.js
var require_service_accounts2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/service-accounts.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ServiceAccounts = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var ServiceAccounts = class extends resource_1.APIResource {
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Retrieve a service account's membership in a workspace.
       *
       * Returns the membership record, including the service account's `workspace_role`
       * in this workspace. Archived workspaces return 400. For the default workspace,
       * returns the implicit (`implicit: true`) membership when no explicit membership
       * exists; an explicitly added membership is returned with its assigned role. An
       * archived service account returns 404.
       *
       * @example
       * ```ts
       * const betaServiceAccountWorkspaceMember =
       *   await client.beta.organization.workspaces.serviceAccounts.retrieve(
       *     'service_account_id',
       *     { workspace_id: 'workspace_id' },
       *   );
       * ```
       */
      retrieve(serviceAccountID, params, options) {
        const { workspace_id, betas } = params;
        return this._client.get((0, path_1.path)`/v1/organizations/workspaces/${workspace_id}/service_accounts/${serviceAccountID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Change a service account's role in a workspace.
       *
       * The new `workspace_role` replaces the current one. Only explicit memberships can
       * be updated; to set a role on the implicit default-workspace membership, add the
       * service account explicitly with
       * `POST /workspaces/{workspace_id}/service_accounts`. Archived workspaces
       * return 400. Archived service accounts cannot be updated and are rejected.
       *
       * @example
       * ```ts
       * const betaServiceAccountWorkspaceMember =
       *   await client.beta.organization.workspaces.serviceAccounts.update(
       *     'service_account_id',
       *     {
       *       workspace_id: 'workspace_id',
       *       workspace_role: 'workspace_admin',
       *     },
       *   );
       * ```
       */
      update(serviceAccountID, params, options) {
        const { workspace_id, betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/organizations/workspaces/${workspace_id}/service_accounts/${serviceAccountID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * List the service accounts that are members of a workspace.
       *
       * Each entry includes the service account's `workspace_role`. Use `limit` and the
       * `next_page` cursor to paginate. Archived workspaces return 400; use
       * `GET /service_accounts/{id}/workspaces` to audit memberships of an archived
       * workspace. The implicit default-workspace membership is not included in this
       * list. Memberships of archived service accounts are omitted from the results.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaServiceAccountWorkspaceMember of client.beta.organization.workspaces.serviceAccounts.list(
       *   'workspace_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(workspaceID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/organizations/workspaces/${workspaceID}/service_accounts?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Add a service account to a workspace with the given `workspace_role`.
       *
       * The role determines what the service account can do in the workspace and which
       * workspace-scoped permissions it can be granted when authenticating through
       * federation. Every service account is already an implicit `workspace_user` member
       * of the default workspace; adding it explicitly assigns a chosen role. If the
       * service account is already an explicit member of the workspace, its
       * `workspace_role` is replaced with the value supplied here. Archived workspaces
       * return 400. Archived service accounts cannot be added and are rejected.
       *
       * @example
       * ```ts
       * const betaServiceAccountWorkspaceMember =
       *   await client.beta.organization.workspaces.serviceAccounts.add(
       *     'workspace_id',
       *     {
       *       service_account_id: 'service_account_id',
       *       workspace_role: 'workspace_admin',
       *     },
       *   );
       * ```
       */
      add(workspaceID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/organizations/workspaces/${workspaceID}/service_accounts?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * **Requires an OAuth access token with the `org:admin` scope**, from
       * `ant auth login --scope org:admin` or a workload identity federation rule; Admin
       * API keys are not accepted. See
       * [Manage WIF with the Admin API](/docs/en/manage-claude/wif-admin-api).
       *
       * Remove a service account from a workspace.
       *
       * Removal is idempotent (returns 200 even if the membership was already removed).
       * A DELETE against the implicit default-workspace membership returns 200 but is a
       * no-op and the membership persists; deleting an explicit default-workspace row
       * reverts to the implicit `workspace_user` membership. Archived workspaces
       * return 400.
       *
       * @example
       * ```ts
       * const serviceAccount =
       *   await client.beta.organization.workspaces.serviceAccounts.remove(
       *     'service_account_id',
       *     { workspace_id: 'workspace_id' },
       *   );
       * ```
       */
      remove(serviceAccountID, params, options) {
        const { workspace_id, betas } = params;
        return this._client.delete((0, path_1.path)`/v1/organizations/workspaces/${workspace_id}/service_accounts/${serviceAccountID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
    };
    exports2.ServiceAccounts = ServiceAccounts;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/workspaces.js
var require_workspaces3 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/workspaces/workspaces.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Workspaces = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var MembersAPI = tslib_1.__importStar(require_members());
    var members_1 = require_members();
    var RateLimitsAPI = tslib_1.__importStar(require_rate_limits2());
    var rate_limits_1 = require_rate_limits2();
    var ServiceAccountsAPI = tslib_1.__importStar(require_service_accounts2());
    var service_accounts_1 = require_service_accounts2();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Workspaces = /* @__PURE__ */ (() => {
      class Workspaces2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.rateLimits = new RateLimitsAPI.RateLimits(this._client);
          this.members = new MembersAPI.Members(this._client);
          this.serviceAccounts = new ServiceAccountsAPI.ServiceAccounts(this._client);
        }
        /**
         * Create Workspace
         *
         * @example
         * ```ts
         * const betaWorkspace =
         *   await client.beta.organization.workspaces.create({
         *     name: 'x',
         *   });
         * ```
         */
        create(params, options) {
          const { betas, ...body } = params;
          return this._client.post("/v1/organizations/workspaces?beta=true", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * Get Workspace
         *
         * @example
         * ```ts
         * const betaWorkspace =
         *   await client.beta.organization.workspaces.retrieve(
         *     'workspace_id',
         *   );
         * ```
         */
        retrieve(workspaceID, options) {
          return this._client.get((0, path_1.path)`/v1/organizations/workspaces/${workspaceID}?beta=true`, options);
        }
        /**
         * Update Workspace
         *
         * @example
         * ```ts
         * const betaWorkspace =
         *   await client.beta.organization.workspaces.update(
         *     'workspace_id',
         *   );
         * ```
         */
        update(workspaceID, body, options) {
          return this._client.post((0, path_1.path)`/v1/organizations/workspaces/${workspaceID}?beta=true`, {
            body,
            ...options
          });
        }
        /**
         * List Workspaces
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaWorkspace of client.beta.organization.workspaces.list()) {
         *   // ...
         * }
         * ```
         */
        list(query = {}, options) {
          return this._client.getAPIList("/v1/organizations/workspaces?beta=true", pagination_1.Page, {
            query,
            ...options
          });
        }
        /**
         * Archive Workspace
         *
         * @example
         * ```ts
         * const betaWorkspace =
         *   await client.beta.organization.workspaces.archive(
         *     'workspace_id',
         *   );
         * ```
         */
        archive(workspaceID, options) {
          return this._client.post((0, path_1.path)`/v1/organizations/workspaces/${workspaceID}/archive?beta=true`, options);
        }
      }
      Workspaces2.RateLimits = rate_limits_1.RateLimits;
      Workspaces2.Members = members_1.Members;
      Workspaces2.ServiceAccounts = service_accounts_1.ServiceAccounts;
      return Workspaces2;
    })();
    exports2.Workspaces = Workspaces;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/organization/organization.js
var require_organization = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/organization/organization.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Organization = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var APIKeysAPI = tslib_1.__importStar(require_api_keys());
    var api_keys_1 = require_api_keys();
    var ComplianceSettingsAPI = tslib_1.__importStar(require_compliance_settings());
    var compliance_settings_1 = require_compliance_settings();
    var ExternalKeysAPI = tslib_1.__importStar(require_external_keys());
    var external_keys_1 = require_external_keys();
    var InvitesAPI = tslib_1.__importStar(require_invites());
    var invites_1 = require_invites();
    var RateLimitsAPI = tslib_1.__importStar(require_rate_limits());
    var rate_limits_1 = require_rate_limits();
    var UsersAPI = tslib_1.__importStar(require_users());
    var users_1 = require_users();
    var FederationAPI = tslib_1.__importStar(require_federation());
    var federation_1 = require_federation();
    var ServiceAccountsAPI = tslib_1.__importStar(require_service_accounts());
    var service_accounts_1 = require_service_accounts();
    var WorkspacesAPI = tslib_1.__importStar(require_workspaces3());
    var workspaces_1 = require_workspaces3();
    var Organization = /* @__PURE__ */ (() => {
      class Organization2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.apiKeys = new APIKeysAPI.APIKeys(this._client);
          this.externalKeys = new ExternalKeysAPI.ExternalKeys(this._client);
          this.federation = new FederationAPI.Federation(this._client);
          this.invites = new InvitesAPI.Invites(this._client);
          this.serviceAccounts = new ServiceAccountsAPI.ServiceAccounts(this._client);
          this.users = new UsersAPI.Users(this._client);
          this.workspaces = new WorkspacesAPI.Workspaces(this._client);
          this.rateLimits = new RateLimitsAPI.RateLimits(this._client);
          this.complianceSettings = new ComplianceSettingsAPI.ComplianceSettings(this._client);
        }
        /**
         * Retrieve information about the organization associated with the authenticated
         * API key.
         *
         * @example
         * ```ts
         * const betaOrganization =
         *   await client.beta.organization.retrieve();
         * ```
         */
        retrieve(options) {
          return this._client.get("/v1/organizations/me?beta=true", options);
        }
      }
      Organization2.APIKeys = api_keys_1.APIKeys;
      Organization2.ExternalKeys = external_keys_1.ExternalKeys;
      Organization2.Federation = federation_1.Federation;
      Organization2.Invites = invites_1.Invites;
      Organization2.ServiceAccounts = service_accounts_1.ServiceAccounts;
      Organization2.Users = users_1.Users;
      Organization2.Workspaces = workspaces_1.Workspaces;
      Organization2.RateLimits = rate_limits_1.RateLimits;
      Organization2.ComplianceSettings = compliance_settings_1.ComplianceSettings;
      return Organization2;
    })();
    exports2.Organization = Organization;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/events.js
var require_events = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/sessions/events.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SessionToolRunner = exports2.Events = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var SessionToolRunner_1 = require_SessionToolRunner();
    var Events = /* @__PURE__ */ (() => {
      class Events2 extends resource_1.APIResource {
        /**
         * List Events
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.events.list(
         *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
         * )) {
         *   // ...
         * }
         * ```
         */
        list(sessionID, params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.getAPIList((0, path_1.path)`/v1/sessions/${sessionID}/events?beta=true`, pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Send Events
         *
         * @example
         * ```ts
         * const betaManagedAgentsSendSessionEvents =
         *   await client.beta.sessions.events.send(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *     {
         *       events: [
         *         {
         *           content: [
         *             {
         *               text: 'Where is my order #1234?',
         *               type: 'text',
         *             },
         *           ],
         *           type: 'user.message',
         *         },
         *       ],
         *     },
         *   );
         * ```
         */
        send(sessionID, params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/sessions/${sessionID}/events?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Stream Events
         *
         * @example
         * ```ts
         * const betaManagedAgentsStreamSessionEvents =
         *   await client.beta.sessions.events.stream(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *   );
         * ```
         */
        stream(sessionID, params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/sessions/${sessionID}/events/stream?beta=true`, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ]),
            stream: true
          });
        }
        /**
         * Attach to a session and dispatch every incoming `agent.tool_use` and
         * `agent.custom_tool_use` event to a local tool registry, sending the matching
         * result back (`user.tool_result` / `user.custom_tool_result`). The
         * sessions-side counterpart to `client.beta.messages.toolRunner`: yields one
         * entry per completed tool call so callers can observe each dispatch (and
         * `break` to abort cleanly).
         *
         * @example
         * ```ts
         * import { betaAgentToolset20260401 } from '@anthropic-ai/sdk/tools/agent-toolset/node';
         *
         * for await (const call of client.beta.sessions.events.toolRunner(work.data.id, {
         *   tools: [...betaAgentToolset20260401({ workdir }), myTool],
         * })) {
         *   console.log(`${call.name} -> ${call.isError ? 'error' : 'ok'}`);
         * }
         * ```
         */
        toolRunner(sessionID, opts) {
          return new SessionToolRunner_1.SessionToolRunner(sessionID, { ...opts, client: this._client });
        }
      }
      Events2.SessionToolRunner = SessionToolRunner_1.SessionToolRunner;
      return Events2;
    })();
    exports2.Events = Events;
    var SessionToolRunner_2 = require_SessionToolRunner();
    Object.defineProperty(exports2, "SessionToolRunner", { enumerable: true, get: function() {
      return SessionToolRunner_2.SessionToolRunner;
    } });
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/resources.js
var require_resources = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/sessions/resources.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Resources = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Resources = class extends resource_1.APIResource {
      /**
       * Get Session Resource
       *
       * @example
       * ```ts
       * const resource =
       *   await client.beta.sessions.resources.retrieve(
       *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
       *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
       *   );
       * ```
       */
      retrieve(resourceID, params, options) {
        const { session_id, betas, workspace_id } = params;
        return this._client.get((0, path_1.path)`/v1/sessions/${session_id}/resources/${resourceID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Update Session Resource
       *
       * @example
       * ```ts
       * const resource =
       *   await client.beta.sessions.resources.update(
       *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
       *     {
       *       session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7',
       *       authorization_token: 'ghp_exampletoken',
       *     },
       *   );
       * ```
       */
      update(resourceID, params, options) {
        const { session_id, betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/sessions/${session_id}/resources/${resourceID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List Session Resources
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsSessionResource of client.beta.sessions.resources.list(
       *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(sessionID, params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/sessions/${sessionID}/resources?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Delete Session Resource
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeleteSessionResource =
       *   await client.beta.sessions.resources.delete(
       *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
       *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
       *   );
       * ```
       */
      delete(resourceID, params, options) {
        const { session_id, betas, workspace_id } = params;
        return this._client.delete((0, path_1.path)`/v1/sessions/${session_id}/resources/${resourceID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Add Session Resource
       *
       * @example
       * ```ts
       * const betaManagedAgentsFileResource =
       *   await client.beta.sessions.resources.add(
       *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
       *     {
       *       file_id: 'file_011CNha8iCJcU1wXNR6q4V8w',
       *       type: 'file',
       *     },
       *   );
       * ```
       */
      add(sessionID, params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/sessions/${sessionID}/resources?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.Resources = Resources;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/threads/events.js
var require_events2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/sessions/threads/events.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Events = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Events = class extends resource_1.APIResource {
      /**
       * List Session Thread Events
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.threads.events.list(
       *   'sthr_011CZkZVWa6oIjw0rgXZpnBt',
       *   { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
       * )) {
       *   // ...
       * }
       * ```
       */
      list(threadID, params, options) {
        const { session_id, betas, workspace_id, ...query } = params;
        return this._client.getAPIList((0, path_1.path)`/v1/sessions/${session_id}/threads/${threadID}/events?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Stream Session Thread Events
       *
       * @example
       * ```ts
       * const betaManagedAgentsStreamSessionThreadEvents =
       *   await client.beta.sessions.threads.events.stream(
       *     'sthr_011CZkZVWa6oIjw0rgXZpnBt',
       *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
       *   );
       * ```
       */
      stream(threadID, params, options) {
        const { session_id, betas, workspace_id, ...query } = params;
        return this._client.get((0, path_1.path)`/v1/sessions/${session_id}/threads/${threadID}/stream?beta=true`, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ]),
          stream: true
        });
      }
    };
    exports2.Events = Events;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/threads/threads.js
var require_threads = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/sessions/threads/threads.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Threads = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var ThreadsEventsAPI = tslib_1.__importStar(require_events2());
    var events_1 = require_events2();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Threads = /* @__PURE__ */ (() => {
      class Threads2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.events = new ThreadsEventsAPI.Events(this._client);
        }
        /**
         * Get Session Thread
         *
         * @example
         * ```ts
         * const betaManagedAgentsSessionThread =
         *   await client.beta.sessions.threads.retrieve(
         *     'sthr_011CZkZVWa6oIjw0rgXZpnBt',
         *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
         *   );
         * ```
         */
        retrieve(threadID, params, options) {
          const { session_id, betas, workspace_id } = params;
          return this._client.get((0, path_1.path)`/v1/sessions/${session_id}/threads/${threadID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * List Session Threads
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaManagedAgentsSessionThread of client.beta.sessions.threads.list(
         *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
         * )) {
         *   // ...
         * }
         * ```
         */
        list(sessionID, params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.getAPIList((0, path_1.path)`/v1/sessions/${sessionID}/threads?beta=true`, pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Archive Session Thread
         *
         * @example
         * ```ts
         * const betaManagedAgentsSessionThread =
         *   await client.beta.sessions.threads.archive(
         *     'sthr_011CZkZVWa6oIjw0rgXZpnBt',
         *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
         *   );
         * ```
         */
        archive(threadID, params, options) {
          const { session_id, betas, workspace_id } = params;
          return this._client.post((0, path_1.path)`/v1/sessions/${session_id}/threads/${threadID}/archive?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
      }
      Threads2.Events = events_1.Events;
      return Threads2;
    })();
    exports2.Threads = Threads;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/sessions.js
var require_sessions = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/sessions/sessions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Sessions = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var EventsAPI = tslib_1.__importStar(require_events());
    var events_1 = require_events();
    var ResourcesAPI = tslib_1.__importStar(require_resources());
    var resources_1 = require_resources();
    var ThreadsAPI = tslib_1.__importStar(require_threads());
    var threads_1 = require_threads();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Sessions = /* @__PURE__ */ (() => {
      class Sessions2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.events = new EventsAPI.Events(this._client);
          this.resources = new ResourcesAPI.Resources(this._client);
          this.threads = new ThreadsAPI.Threads(this._client);
        }
        /**
         * Create Session
         *
         * @example
         * ```ts
         * const betaManagedAgentsSession =
         *   await client.beta.sessions.create({
         *     agent: 'agent_011CZkYpogX7uDKUyvBTophP',
         *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
         *   });
         * ```
         */
        create(params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post("/v1/sessions?beta=true", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Get Session
         *
         * @example
         * ```ts
         * const betaManagedAgentsSession =
         *   await client.beta.sessions.retrieve(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *   );
         * ```
         */
        retrieve(sessionID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/sessions/${sessionID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Update Session
         *
         * @example
         * ```ts
         * const betaManagedAgentsSession =
         *   await client.beta.sessions.update(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *   );
         * ```
         */
        update(sessionID, params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/sessions/${sessionID}?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * List Sessions
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaManagedAgentsSession of client.beta.sessions.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.getAPIList("/v1/sessions?beta=true", pagination_1.BidirectionalPageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Delete Session
         *
         * @example
         * ```ts
         * const betaManagedAgentsDeletedSession =
         *   await client.beta.sessions.delete(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *   );
         * ```
         */
        delete(sessionID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.delete((0, path_1.path)`/v1/sessions/${sessionID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Archive Session
         *
         * @example
         * ```ts
         * const betaManagedAgentsSession =
         *   await client.beta.sessions.archive(
         *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
         *   );
         * ```
         */
        archive(sessionID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.post((0, path_1.path)`/v1/sessions/${sessionID}/archive?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
      }
      Sessions2.Events = events_1.Events;
      Sessions2.Resources = resources_1.Resources;
      Sessions2.Threads = threads_1.Threads;
      return Sessions2;
    })();
    exports2.Sessions = Sessions;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/skills/versions.js
var require_versions2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/skills/versions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Versions = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var uploads_1 = require_uploads();
    var path_1 = require_path();
    var Versions = class extends resource_1.APIResource {
      /**
       * Create Skill Version
       *
       * @example
       * ```ts
       * const betaSkillVersion =
       *   await client.beta.skills.versions.create('skill_id', {
       *     files: [fs.createReadStream('path/to/file')],
       *   });
       * ```
       */
      create(skillID, params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/skills/${skillID}/versions?beta=true`, (0, uploads_1.multipartFormRequestOptions)({
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        }, this._client, false));
      }
      /**
       * Get Skill Version
       *
       * @example
       * ```ts
       * const betaSkillVersion =
       *   await client.beta.skills.versions.retrieve('version', {
       *     skill_id: 'skill_id',
       *   });
       * ```
       */
      retrieve(version, params, options) {
        const { skill_id, betas, workspace_id } = params;
        return this._client.get((0, path_1.path)`/v1/skills/${skill_id}/versions/${version}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List Skill Versions
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaSkillVersion of client.beta.skills.versions.list(
       *   'skill_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(skillID, params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/skills/${skillID}/versions?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Delete Skill Version
       *
       * @example
       * ```ts
       * const betaDeletedSkillVersion =
       *   await client.beta.skills.versions.delete('version', {
       *     skill_id: 'skill_id',
       *   });
       * ```
       */
      delete(version, params, options) {
        const { skill_id, betas, workspace_id } = params;
        return this._client.delete((0, path_1.path)`/v1/skills/${skill_id}/versions/${version}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Download a skill version's content as a zip archive.
       *
       * @example
       * ```ts
       * const response = await client.beta.skills.versions.download(
       *   'version',
       *   { skill_id: 'skill_id' },
       * );
       *
       * const content = await response.blob();
       * console.log(content);
       * ```
       */
      download(version, params, options) {
        const { skill_id, betas, workspace_id } = params;
        return this._client.get((0, path_1.path)`/v1/skills/${skill_id}/versions/${version}/content?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              Accept: "application/binary",
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ]),
          __binaryResponse: true
        });
      }
    };
    exports2.Versions = Versions;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/skills/skills.js
var require_skills2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/skills/skills.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Skills = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var VersionsAPI = tslib_1.__importStar(require_versions2());
    var versions_1 = require_versions2();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var uploads_1 = require_uploads();
    var path_1 = require_path();
    var Skills = /* @__PURE__ */ (() => {
      class Skills2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.versions = new VersionsAPI.Versions(this._client);
        }
        /**
         * Create Skill
         *
         * @example
         * ```ts
         * const betaSkill = await client.beta.skills.create({
         *   files: [fs.createReadStream('path/to/file')],
         * });
         * ```
         */
        create(params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post("/v1/skills?beta=true", (0, uploads_1.multipartFormRequestOptions)({
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          }, this._client, false));
        }
        /**
         * Get Skill
         *
         * @example
         * ```ts
         * const betaSkill = await client.beta.skills.retrieve(
         *   'skill_id',
         * );
         * ```
         */
        retrieve(skillID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/skills/${skillID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * List Skills
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaSkill of client.beta.skills.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.getAPIList("/v1/skills?beta=true", pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Delete Skill
         *
         * @example
         * ```ts
         * const betaDeletedSkill = await client.beta.skills.delete(
         *   'skill_id',
         * );
         * ```
         */
        delete(skillID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.delete((0, path_1.path)`/v1/skills/${skillID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
      }
      Skills2.Versions = versions_1.Versions;
      return Skills2;
    })();
    exports2.Skills = Skills;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/tunnels/certificates.js
var require_certificates = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/tunnels/certificates.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Certificates = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Certificates = class extends resource_1.APIResource {
      /**
       * The Tunnels API is in research preview. It requires the
       * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
       * deprecation period. It supersedes the Admin API endpoints at
       * `/v1/organizations/tunnels`, which remain available during a migration window.
       *
       * Registers a public CA certificate on a tunnel. Anthropic verifies the gateway's
       * server certificate against this CA when it terminates the inner TLS session. A
       * tunnel holds at most two non-archived certificates.
       *
       * @example
       * ```ts
       * const betaTunnelCertificate =
       *   await client.beta.tunnels.certificates.create(
       *     'tunnel_id',
       *     { ca_certificate_pem: 'ca_certificate_pem' },
       *   );
       * ```
       */
      create(tunnelID, params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/tunnels/${tunnelID}/certificates?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * The Tunnels API is in research preview. It requires the
       * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
       * deprecation period. It supersedes the Admin API endpoints at
       * `/v1/organizations/tunnels`, which remain available during a migration window.
       *
       * Fetches a tunnel certificate by ID.
       *
       * @example
       * ```ts
       * const betaTunnelCertificate =
       *   await client.beta.tunnels.certificates.retrieve(
       *     'certificate_id',
       *     { tunnel_id: 'tunnel_id' },
       *   );
       * ```
       */
      retrieve(certificateID, params, options) {
        const { tunnel_id, betas, workspace_id } = params;
        return this._client.get((0, path_1.path)`/v1/tunnels/${tunnel_id}/certificates/${certificateID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * The Tunnels API is in research preview. It requires the
       * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
       * deprecation period. It supersedes the Admin API endpoints at
       * `/v1/organizations/tunnels`, which remain available during a migration window.
       *
       * Lists the certificates registered on a tunnel. Archived certificates are
       * excluded unless include_archived is set.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaTunnelCertificate of client.beta.tunnels.certificates.list(
       *   'tunnel_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(tunnelID, params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/tunnels/${tunnelID}/certificates?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * The Tunnels API is in research preview. It requires the
       * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
       * deprecation period. It supersedes the Admin API endpoints at
       * `/v1/organizations/tunnels`, which remain available during a migration window.
       *
       * Archives a tunnel certificate, removing it from the set Anthropic trusts for the
       * tunnel. The certificate record is retained. Archiving the last non-archived
       * certificate is permitted; the tunnel rejects MCP traffic until a new certificate
       * is added.
       *
       * @example
       * ```ts
       * const betaTunnelCertificate =
       *   await client.beta.tunnels.certificates.archive(
       *     'certificate_id',
       *     { tunnel_id: 'tunnel_id' },
       *   );
       * ```
       */
      archive(certificateID, params, options) {
        const { tunnel_id, betas, workspace_id } = params;
        return this._client.post((0, path_1.path)`/v1/tunnels/${tunnel_id}/certificates/${certificateID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.Certificates = Certificates;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/tunnels/tunnels.js
var require_tunnels = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/tunnels/tunnels.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Tunnels = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var CertificatesAPI = tslib_1.__importStar(require_certificates());
    var certificates_1 = require_certificates();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Tunnels = /* @__PURE__ */ (() => {
      class Tunnels2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.certificates = new CertificatesAPI.Certificates(this._client);
        }
        /**
         * The Tunnels API is in research preview. It requires the
         * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
         * deprecation period. It supersedes the Admin API endpoints at
         * `/v1/organizations/tunnels`, which remain available during a migration window.
         *
         * Creates a tunnel. Creation allocates a fresh hostname and provisions the tunnel;
         * it is not idempotent. The new tunnel rejects MCP traffic until at least one CA
         * certificate is added.
         *
         * @example
         * ```ts
         * const betaTunnel = await client.beta.tunnels.create();
         * ```
         */
        create(params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post("/v1/tunnels?beta=true", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * The Tunnels API is in research preview. It requires the
         * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
         * deprecation period. It supersedes the Admin API endpoints at
         * `/v1/organizations/tunnels`, which remain available during a migration window.
         *
         * Fetches a tunnel by ID.
         *
         * @example
         * ```ts
         * const betaTunnel = await client.beta.tunnels.retrieve(
         *   'tunnel_id',
         * );
         * ```
         */
        retrieve(tunnelID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/tunnels/${tunnelID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * The Tunnels API is in research preview. It requires the
         * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
         * deprecation period. It supersedes the Admin API endpoints at
         * `/v1/organizations/tunnels`, which remain available during a migration window.
         *
         * Lists tunnels. Results are ordered by creation time, newest first; archived
         * tunnels are excluded unless include_archived is set.
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaTunnel of client.beta.tunnels.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.getAPIList("/v1/tunnels?beta=true", pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * The Tunnels API is in research preview. It requires the
         * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
         * deprecation period. It supersedes the Admin API endpoints at
         * `/v1/organizations/tunnels`, which remain available during a migration window.
         *
         * Archives a tunnel. Archival is irreversible: every non-archived certificate on
         * the tunnel is archived in the same operation, the hostname is retired and never
         * re-allocated, and the tunnel token is invalidated. Retrying against an
         * already-archived tunnel returns the existing record unchanged.
         *
         * @example
         * ```ts
         * const betaTunnel = await client.beta.tunnels.archive(
         *   'tunnel_id',
         * );
         * ```
         */
        archive(tunnelID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.post((0, path_1.path)`/v1/tunnels/${tunnelID}/archive?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * The Tunnels API is in research preview. It requires the
         * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
         * deprecation period. It supersedes the Admin API endpoints at
         * `/v1/organizations/tunnels`, which remain available during a migration window.
         *
         * Reveals a tunnel's connector token. The value is fetched live on each call;
         * Anthropic does not store it. Repeated calls return the same value until the
         * token is rotated. Exposed as POST so the token does not appear in intermediary
         * access logs.
         *
         * @example
         * ```ts
         * const betaTunnelToken =
         *   await client.beta.tunnels.revealToken('tunnel_id');
         * ```
         */
        revealToken(tunnelID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.post((0, path_1.path)`/v1/tunnels/${tunnelID}/reveal_token?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * The Tunnels API is in research preview. It requires the
         * `anthropic-beta: mcp-tunnels-2026-06-22` header and may change without a
         * deprecation period. It supersedes the Admin API endpoints at
         * `/v1/organizations/tunnels`, which remain available during a migration window.
         *
         * Rotates a tunnel's connector token. Rotation invalidates the current token for
         * new connections and returns a fresh value; established connections are not
         * severed. A connector restarted after rotation must use the new value.
         *
         * @example
         * ```ts
         * const betaTunnelToken =
         *   await client.beta.tunnels.rotateToken('tunnel_id');
         * ```
         */
        rotateToken(tunnelID, params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/tunnels/${tunnelID}/rotate_token?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "mcp-tunnels-2026-06-22"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
      }
      Tunnels2.Certificates = certificates_1.Certificates;
      return Tunnels2;
    })();
    exports2.Tunnels = Tunnels;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/vaults/credentials.js
var require_credentials2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/vaults/credentials.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Credentials = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Credentials = class extends resource_1.APIResource {
      /**
       * Create Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsCredential =
       *   await client.beta.vaults.credentials.create(
       *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
       *     {
       *       auth: {
       *         token: 'bearer_exampletoken',
       *         mcp_server_url:
       *           'https://example-server.modelcontextprotocol.io/sse',
       *         type: 'static_bearer',
       *       },
       *     },
       *   );
       * ```
       */
      create(vaultID, params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/vaults/${vaultID}/credentials?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Get Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsCredential =
       *   await client.beta.vaults.credentials.retrieve(
       *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
       *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
       *   );
       * ```
       */
      retrieve(credentialID, params, options) {
        const { vault_id, betas, workspace_id } = params;
        return this._client.get((0, path_1.path)`/v1/vaults/${vault_id}/credentials/${credentialID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Update Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsCredential =
       *   await client.beta.vaults.credentials.update(
       *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
       *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
       *   );
       * ```
       */
      update(credentialID, params, options) {
        const { vault_id, betas, workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/vaults/${vault_id}/credentials/${credentialID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List Credentials
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsCredential of client.beta.vaults.credentials.list(
       *   'vlt_011CZkZDLs7fYzm1hXNPeRjv',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(vaultID, params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/vaults/${vaultID}/credentials?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Delete Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeletedCredential =
       *   await client.beta.vaults.credentials.delete(
       *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
       *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
       *   );
       * ```
       */
      delete(credentialID, params, options) {
        const { vault_id, betas, workspace_id } = params;
        return this._client.delete((0, path_1.path)`/v1/vaults/${vault_id}/credentials/${credentialID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Archive Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsCredential =
       *   await client.beta.vaults.credentials.archive(
       *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
       *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
       *   );
       * ```
       */
      archive(credentialID, params, options) {
        const { vault_id, betas, workspace_id } = params;
        return this._client.post((0, path_1.path)`/v1/vaults/${vault_id}/credentials/${credentialID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Validate Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsCredentialValidation =
       *   await client.beta.vaults.credentials.mcpOAuthValidate(
       *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
       *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
       *   );
       * ```
       */
      mcpOAuthValidate(credentialID, params, options) {
        const { vault_id, betas, workspace_id } = params;
        return this._client.post((0, path_1.path)`/v1/vaults/${vault_id}/credentials/${credentialID}/mcp_oauth_validate?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.Credentials = Credentials;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/vaults/vaults.js
var require_vaults = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/vaults/vaults.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Vaults = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var CredentialsAPI = tslib_1.__importStar(require_credentials2());
    var credentials_1 = require_credentials2();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Vaults = /* @__PURE__ */ (() => {
      class Vaults2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.credentials = new CredentialsAPI.Credentials(this._client);
        }
        /**
         * Create Vault
         *
         * @example
         * ```ts
         * const betaManagedAgentsVault =
         *   await client.beta.vaults.create({
         *     display_name: 'Example vault',
         *   });
         * ```
         */
        create(params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post("/v1/vaults?beta=true", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Get Vault
         *
         * @example
         * ```ts
         * const betaManagedAgentsVault =
         *   await client.beta.vaults.retrieve(
         *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
         *   );
         * ```
         */
        retrieve(vaultID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/vaults/${vaultID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Update Vault
         *
         * @example
         * ```ts
         * const betaManagedAgentsVault =
         *   await client.beta.vaults.update(
         *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
         *   );
         * ```
         */
        update(vaultID, params, options) {
          const { betas, workspace_id, ...body } = params;
          return this._client.post((0, path_1.path)`/v1/vaults/${vaultID}?beta=true`, {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * List Vaults
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const betaManagedAgentsVault of client.beta.vaults.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
          const { betas, workspace_id, ...query } = params ?? {};
          return this._client.getAPIList("/v1/vaults?beta=true", pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Delete Vault
         *
         * @example
         * ```ts
         * const betaManagedAgentsDeletedVault =
         *   await client.beta.vaults.delete(
         *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
         *   );
         * ```
         */
        delete(vaultID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.delete((0, path_1.path)`/v1/vaults/${vaultID}?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
        /**
         * Archive Vault
         *
         * @example
         * ```ts
         * const betaManagedAgentsVault =
         *   await client.beta.vaults.archive(
         *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
         *   );
         * ```
         */
        archive(vaultID, params = {}, options) {
          const { betas, workspace_id } = params ?? {};
          return this._client.post((0, path_1.path)`/v1/vaults/${vaultID}/archive?beta=true`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
      }
      Vaults2.Credentials = credentials_1.Credentials;
      return Vaults2;
    })();
    exports2.Vaults = Vaults;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/beta.js
var require_beta = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/beta.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Beta = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var DeploymentRunsAPI = tslib_1.__importStar(require_deployment_runs());
    var deployment_runs_1 = require_deployment_runs();
    var DeploymentsAPI = tslib_1.__importStar(require_deployments());
    var deployments_1 = require_deployments();
    var DreamsAPI = tslib_1.__importStar(require_dreams());
    var dreams_1 = require_dreams();
    var FilesAPI = tslib_1.__importStar(require_files());
    var files_1 = require_files();
    var ModelsAPI = tslib_1.__importStar(require_models());
    var models_1 = require_models();
    var UserProfilesAPI = tslib_1.__importStar(require_user_profiles());
    var user_profiles_1 = require_user_profiles();
    var WebhooksAPI = tslib_1.__importStar(require_webhooks());
    var webhooks_1 = require_webhooks();
    var AgentsAPI = tslib_1.__importStar(require_agents());
    var agents_1 = require_agents();
    var EnvironmentsAPI = tslib_1.__importStar(require_environments());
    var environments_1 = require_environments();
    var MemoryStoresAPI = tslib_1.__importStar(require_memory_stores());
    var memory_stores_1 = require_memory_stores();
    var MessagesAPI = tslib_1.__importStar(require_messages());
    var messages_1 = require_messages();
    var OrganizationAPI = tslib_1.__importStar(require_organization());
    var organization_1 = require_organization();
    var SessionsAPI = tslib_1.__importStar(require_sessions());
    var sessions_1 = require_sessions();
    var SkillsAPI = tslib_1.__importStar(require_skills2());
    var skills_1 = require_skills2();
    var TunnelsAPI = tslib_1.__importStar(require_tunnels());
    var tunnels_1 = require_tunnels();
    var VaultsAPI = tslib_1.__importStar(require_vaults());
    var vaults_1 = require_vaults();
    var Beta = /* @__PURE__ */ (() => {
      class Beta2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.models = new ModelsAPI.Models(this._client);
          this.messages = new MessagesAPI.Messages(this._client);
          this.agents = new AgentsAPI.Agents(this._client);
          this.environments = new EnvironmentsAPI.Environments(this._client);
          this.sessions = new SessionsAPI.Sessions(this._client);
          this.deployments = new DeploymentsAPI.Deployments(this._client);
          this.deploymentRuns = new DeploymentRunsAPI.DeploymentRuns(this._client);
          this.vaults = new VaultsAPI.Vaults(this._client);
          this.memoryStores = new MemoryStoresAPI.MemoryStores(this._client);
          this.files = new FilesAPI.Files(this._client);
          this.skills = new SkillsAPI.Skills(this._client);
          this.webhooks = new WebhooksAPI.Webhooks(this._client);
          this.userProfiles = new UserProfilesAPI.UserProfiles(this._client);
          this.dreams = new DreamsAPI.Dreams(this._client);
          this.tunnels = new TunnelsAPI.Tunnels(this._client);
          this.organization = new OrganizationAPI.Organization(this._client);
        }
      }
      Beta2.Models = models_1.Models;
      Beta2.Messages = messages_1.Messages;
      Beta2.Agents = agents_1.Agents;
      Beta2.Environments = environments_1.Environments;
      Beta2.Sessions = sessions_1.Sessions;
      Beta2.Deployments = deployments_1.Deployments;
      Beta2.DeploymentRuns = deployment_runs_1.DeploymentRuns;
      Beta2.Vaults = vaults_1.Vaults;
      Beta2.MemoryStores = memory_stores_1.MemoryStores;
      Beta2.Files = files_1.Files;
      Beta2.Skills = skills_1.Skills;
      Beta2.Webhooks = webhooks_1.Webhooks;
      Beta2.UserProfiles = user_profiles_1.UserProfiles;
      Beta2.Dreams = dreams_1.Dreams;
      Beta2.Tunnels = tunnels_1.Tunnels;
      Beta2.Organization = organization_1.Organization;
      return Beta2;
    })();
    exports2.Beta = Beta;
  }
});

// node_modules/@anthropic-ai/sdk/resources/completions.js
var require_completions = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/completions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Completions = void 0;
    var resource_1 = require_resource();
    var headers_1 = require_headers();
    var Completions = class extends resource_1.APIResource {
      create(params, options) {
        const { betas, workspace_id, ...body } = params;
        return this._client.post("/v1/complete", {
          body,
          timeout: this._client._options.timeout ?? 6e5,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ]),
          stream: params.stream ?? false
        });
      }
    };
    exports2.Completions = Completions;
  }
});

// node_modules/@anthropic-ai/sdk/resources/files.js
var require_files2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/files.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Files = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var uploads_1 = require_uploads();
    var path_1 = require_path();
    var Files = class extends resource_1.APIResource {
      /**
       * List Files
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const fileMetadata of client.files.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { workspace_id, ...query } = params ?? {};
        return this._client.getAPIList("/v1/files", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * Delete File
       *
       * @example
       * ```ts
       * const deletedFile = await client.files.delete('file_id');
       * ```
       */
      delete(fileID, params = {}, options) {
        const { workspace_id } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/files/${fileID}`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * Download File
       *
       * @example
       * ```ts
       * const response = await client.files.download('file_id');
       *
       * const content = await response.blob();
       * console.log(content);
       * ```
       */
      download(fileID, params = {}, options) {
        const { workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/files/${fileID}/content`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              Accept: "application/binary",
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ]),
          __binaryResponse: true
        });
      }
      /**
       * Get File Metadata
       *
       * @example
       * ```ts
       * const fileMetadata = await client.files.retrieveMetadata(
       *   'file_id',
       * );
       * ```
       */
      retrieveMetadata(fileID, params = {}, options) {
        const { workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/files/${fileID}`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * Upload File
       *
       * @example
       * ```ts
       * const fileMetadata = await client.files.upload({
       *   file: fs.createReadStream('path/to/file'),
       * });
       * ```
       */
      upload(params, options) {
        const { workspace_id, ...body } = params;
        return this._client.post("/v1/files", (0, uploads_1.multipartFormRequestOptions)({
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            (0, stainless_helper_header_1.stainlessHelperHeaderFromFile)(body.file),
            options?.headers
          ])
        }, this._client));
      }
    };
    exports2.Files = Files;
  }
});

// node_modules/@anthropic-ai/sdk/lib/parser.js
var require_parser2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/parser.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.maybeParseMessage = maybeParseMessage;
    exports2.parseMessage = parseMessage;
    var error_1 = require_error();
    function getOutputFormat(params) {
      return params?.output_config?.format;
    }
    function maybeParseMessage(message, params, opts) {
      const outputFormat = getOutputFormat(params);
      if (!params || !("parse" in (outputFormat ?? {}))) {
        return {
          ...message,
          content: message.content.map((block) => {
            if (block.type === "text") {
              const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
                value: null,
                enumerable: false
              });
              return parsedBlock;
            }
            return block;
          }),
          parsed_output: null
        };
      }
      return parseMessage(message, params, opts);
    }
    function parseMessage(message, params, opts) {
      let firstParsedOutput = null;
      const content = message.content.map((block) => {
        if (block.type === "text") {
          const parsedOutput = parseOutputFormat(params, block.text);
          if (firstParsedOutput === null) {
            firstParsedOutput = parsedOutput;
          }
          const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
            value: parsedOutput,
            enumerable: false
          });
          return parsedBlock;
        }
        return block;
      });
      return {
        ...message,
        content,
        parsed_output: firstParsedOutput
      };
    }
    function parseOutputFormat(params, content) {
      const outputFormat = getOutputFormat(params);
      if (outputFormat?.type !== "json_schema") {
        return null;
      }
      try {
        if ("parse" in outputFormat) {
          return outputFormat.parse(content);
        }
        return JSON.parse(content);
      } catch (error) {
        throw new error_1.AnthropicError(`Failed to parse structured output: ${error}`);
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/MessageStream.js
var require_MessageStream = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/MessageStream.js"(exports2) {
    "use strict";
    var _MessageStream_instances;
    var _MessageStream_currentMessageSnapshot;
    var _MessageStream_params;
    var _MessageStream_connectedPromise;
    var _MessageStream_resolveConnectedPromise;
    var _MessageStream_rejectConnectedPromise;
    var _MessageStream_endPromise;
    var _MessageStream_resolveEndPromise;
    var _MessageStream_rejectEndPromise;
    var _MessageStream_listeners;
    var _MessageStream_ended;
    var _MessageStream_errored;
    var _MessageStream_aborted;
    var _MessageStream_catchingPromiseCreated;
    var _MessageStream_response;
    var _MessageStream_request_id;
    var _MessageStream_workspace_id;
    var _MessageStream_logger;
    var _MessageStream_getFinalMessage;
    var _MessageStream_getFinalText;
    var _MessageStream_handleError;
    var _MessageStream_beginRequest;
    var _MessageStream_addStreamEvent;
    var _MessageStream_endRequest;
    var _MessageStream_accumulateMessage;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MessageStream = void 0;
    var tslib_1 = require_tslib();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var errors_1 = require_errors();
    var values_1 = require_values();
    var error_1 = require_error2();
    var streaming_1 = require_streaming2();
    var parser_1 = require_parser2();
    var message_stream_utils_1 = require_message_stream_utils();
    function tracksToolInput(content) {
      return content.type === "tool_use" || content.type === "server_tool_use";
    }
    var MessageStream = /* @__PURE__ */ (() => {
      class MessageStream2 {
        constructor(params, opts) {
          _MessageStream_instances.add(this);
          this.messages = [];
          this.receivedMessages = [];
          _MessageStream_currentMessageSnapshot.set(this, void 0);
          _MessageStream_params.set(this, null);
          this.controller = new AbortController();
          _MessageStream_connectedPromise.set(this, void 0);
          _MessageStream_resolveConnectedPromise.set(this, () => {
          });
          _MessageStream_rejectConnectedPromise.set(this, () => {
          });
          _MessageStream_endPromise.set(this, void 0);
          _MessageStream_resolveEndPromise.set(this, () => {
          });
          _MessageStream_rejectEndPromise.set(this, () => {
          });
          _MessageStream_listeners.set(this, {});
          _MessageStream_ended.set(this, false);
          _MessageStream_errored.set(this, false);
          _MessageStream_aborted.set(this, false);
          _MessageStream_catchingPromiseCreated.set(this, false);
          _MessageStream_response.set(this, void 0);
          _MessageStream_request_id.set(this, void 0);
          _MessageStream_workspace_id.set(this, void 0);
          _MessageStream_logger.set(this, void 0);
          _MessageStream_handleError.set(this, (error) => {
            tslib_1.__classPrivateFieldSet(this, _MessageStream_errored, true, "f");
            if ((0, errors_1.isAbortError)(error)) {
              error = new error_1.APIUserAbortError();
            }
            if (error instanceof error_1.APIUserAbortError) {
              tslib_1.__classPrivateFieldSet(this, _MessageStream_aborted, true, "f");
              return this._emit("abort", error);
            }
            if (error instanceof error_1.AnthropicError) {
              return this._emit("error", error);
            }
            if (error instanceof Error) {
              const anthropicError = new error_1.AnthropicError(error.message);
              anthropicError.cause = error;
              return this._emit("error", anthropicError);
            }
            return this._emit("error", new error_1.AnthropicError(String(error)));
          });
          tslib_1.__classPrivateFieldSet(this, _MessageStream_connectedPromise, new Promise((resolve, reject) => {
            tslib_1.__classPrivateFieldSet(this, _MessageStream_resolveConnectedPromise, resolve, "f");
            tslib_1.__classPrivateFieldSet(this, _MessageStream_rejectConnectedPromise, reject, "f");
          }), "f");
          tslib_1.__classPrivateFieldSet(this, _MessageStream_endPromise, new Promise((resolve, reject) => {
            tslib_1.__classPrivateFieldSet(this, _MessageStream_resolveEndPromise, resolve, "f");
            tslib_1.__classPrivateFieldSet(this, _MessageStream_rejectEndPromise, reject, "f");
          }), "f");
          tslib_1.__classPrivateFieldGet(this, _MessageStream_connectedPromise, "f").catch(() => {
          });
          tslib_1.__classPrivateFieldGet(this, _MessageStream_endPromise, "f").catch(() => {
          });
          tslib_1.__classPrivateFieldSet(this, _MessageStream_params, params, "f");
          tslib_1.__classPrivateFieldSet(this, _MessageStream_logger, opts?.logger ?? console, "f");
        }
        get response() {
          return tslib_1.__classPrivateFieldGet(this, _MessageStream_response, "f");
        }
        get request_id() {
          return tslib_1.__classPrivateFieldGet(this, _MessageStream_request_id, "f");
        }
        get workspace_id() {
          return tslib_1.__classPrivateFieldGet(this, _MessageStream_workspace_id, "f");
        }
        /**
         * Returns the `MessageStream` data, the raw `Response` instance and the ID of the request,
         * returned vie the `request-id` header which is useful for debugging requests and resporting
         * issues to Anthropic.
         *
         * This is the same as the `APIPromise.withResponse()` method.
         *
         * This method will raise an error if you created the stream using `MessageStream.fromReadableStream`
         * as no `Response` is available.
         */
        async withResponse() {
          tslib_1.__classPrivateFieldSet(this, _MessageStream_catchingPromiseCreated, true, "f");
          const response = await tslib_1.__classPrivateFieldGet(this, _MessageStream_connectedPromise, "f");
          if (!response) {
            throw new Error("Could not resolve a `Response` object");
          }
          return {
            data: this,
            response,
            request_id: response.headers.get("request-id"),
            workspace_id: response.headers.get("anthropic-workspace-id")
          };
        }
        /**
         * Intended for use on the frontend, consuming a stream produced with
         * `.toReadableStream()` on the backend.
         *
         * Note that messages sent to the model do not appear in `.on('message')`
         * in this context.
         */
        static fromReadableStream(stream) {
          const runner = new MessageStream2(null);
          runner._run(() => runner._fromReadableStream(stream));
          return runner;
        }
        static createMessage(messages, params, options, { logger } = {}) {
          const runner = new MessageStream2(params, { logger });
          for (const message of params.messages) {
            runner._addMessageParam(message);
          }
          tslib_1.__classPrivateFieldSet(runner, _MessageStream_params, { ...params, stream: true }, "f");
          runner._run(() => runner._createMessage(messages, { ...params, stream: true }, { ...options, headers: { ...options?.headers, [stainless_helper_header_1.STAINLESS_HELPER_METHOD_HEADER]: "stream" } }));
          return runner;
        }
        _run(executor) {
          executor().then(() => {
            this._emitFinal();
            this._emit("end");
          }, tslib_1.__classPrivateFieldGet(this, _MessageStream_handleError, "f"));
        }
        _addMessageParam(message) {
          this.messages.push(message);
        }
        _addMessage(message, emit = true) {
          this.receivedMessages.push(message);
          if (emit) {
            this._emit("message", message);
          }
        }
        async _createMessage(messages, params, options) {
          const signal = options?.signal;
          let abortHandler;
          if (signal) {
            if (signal.aborted)
              this.controller.abort();
            abortHandler = this.controller.abort.bind(this.controller);
            signal.addEventListener("abort", abortHandler);
          }
          try {
            tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_beginRequest).call(this);
            const { response, data: stream } = await messages.create({ ...params, stream: true }, { ...options, signal: this.controller.signal }).withResponse();
            this._connected(response);
            for await (const event of stream) {
              tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_addStreamEvent).call(this, event);
            }
            if (stream.controller.signal?.aborted) {
              throw new error_1.APIUserAbortError();
            }
            tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_endRequest).call(this);
          } finally {
            if (signal && abortHandler) {
              signal.removeEventListener("abort", abortHandler);
            }
          }
        }
        _connected(response) {
          if (this.ended)
            return;
          tslib_1.__classPrivateFieldSet(this, _MessageStream_response, response, "f");
          tslib_1.__classPrivateFieldSet(this, _MessageStream_request_id, response?.headers.get("request-id"), "f");
          tslib_1.__classPrivateFieldSet(this, _MessageStream_workspace_id, response?.headers.get("anthropic-workspace-id"), "f");
          tslib_1.__classPrivateFieldGet(this, _MessageStream_resolveConnectedPromise, "f").call(this, response);
          this._emit("connect");
        }
        get ended() {
          return tslib_1.__classPrivateFieldGet(this, _MessageStream_ended, "f");
        }
        get errored() {
          return tslib_1.__classPrivateFieldGet(this, _MessageStream_errored, "f");
        }
        get aborted() {
          return tslib_1.__classPrivateFieldGet(this, _MessageStream_aborted, "f");
        }
        abort() {
          this.controller.abort();
        }
        /**
         * Adds the listener function to the end of the listeners array for the event.
         * No checks are made to see if the listener has already been added. Multiple calls passing
         * the same combination of event and listener will result in the listener being added, and
         * called, multiple times.
         * @returns this MessageStream, so that calls can be chained
         */
        on(event, listener) {
          const listeners = tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] || (tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] = []);
          listeners.push({ listener });
          return this;
        }
        /**
         * Removes the specified listener from the listener array for the event.
         * off() will remove, at most, one instance of a listener from the listener array. If any single
         * listener has been added multiple times to the listener array for the specified event, then
         * off() must be called multiple times to remove each instance.
         * @returns this MessageStream, so that calls can be chained
         */
        off(event, listener) {
          const listeners = tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event];
          if (!listeners)
            return this;
          const index = listeners.findIndex((l) => l.listener === listener);
          if (index >= 0)
            listeners.splice(index, 1);
          return this;
        }
        /**
         * Adds a one-time listener function for the event. The next time the event is triggered,
         * this listener is removed and then invoked.
         * @returns this MessageStream, so that calls can be chained
         */
        once(event, listener) {
          const listeners = tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] || (tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] = []);
          listeners.push({ listener, once: true });
          return this;
        }
        /**
         * This is similar to `.once()`, but returns a Promise that resolves the next time
         * the event is triggered, instead of calling a listener callback.
         * @returns a Promise that resolves the next time given event is triggered,
         * or rejects if an error is emitted.  (If you request the 'error' event,
         * returns a promise that resolves with the error).
         *
         * Example:
         *
         *   const message = await stream.emitted('message') // rejects if the stream errors
         */
        emitted(event) {
          return new Promise((resolve, reject) => {
            tslib_1.__classPrivateFieldSet(this, _MessageStream_catchingPromiseCreated, true, "f");
            if (event !== "error")
              this.once("error", reject);
            this.once(event, resolve);
          });
        }
        async done() {
          tslib_1.__classPrivateFieldSet(this, _MessageStream_catchingPromiseCreated, true, "f");
          await tslib_1.__classPrivateFieldGet(this, _MessageStream_endPromise, "f");
        }
        get currentMessage() {
          return tslib_1.__classPrivateFieldGet(this, _MessageStream_currentMessageSnapshot, "f");
        }
        /**
         * @returns a promise that resolves with the the final assistant Message response,
         * or rejects if an error occurred or the stream ended prematurely without producing a Message.
         * If structured outputs were used, this will be a ParsedMessage with a `parsed_output` field.
         */
        async finalMessage() {
          await this.done();
          return tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_getFinalMessage).call(this);
        }
        /**
         * @returns a promise that resolves with the the final assistant Message's text response, concatenated
         * together if there are more than one text blocks.
         * Rejects if an error occurred or the stream ended prematurely without producing a Message.
         */
        async finalText() {
          await this.done();
          return tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_getFinalText).call(this);
        }
        _emit(event, ...args) {
          if (tslib_1.__classPrivateFieldGet(this, _MessageStream_ended, "f"))
            return;
          if (event === "end") {
            tslib_1.__classPrivateFieldSet(this, _MessageStream_ended, true, "f");
            tslib_1.__classPrivateFieldGet(this, _MessageStream_resolveEndPromise, "f").call(this);
          }
          const listeners = tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event];
          if (listeners) {
            tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
            listeners.forEach(({ listener }) => listener(...args));
          }
          if (event === "abort") {
            const error = args[0];
            if (!tslib_1.__classPrivateFieldGet(this, _MessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
              Promise.reject(error);
            }
            tslib_1.__classPrivateFieldGet(this, _MessageStream_rejectConnectedPromise, "f").call(this, error);
            tslib_1.__classPrivateFieldGet(this, _MessageStream_rejectEndPromise, "f").call(this, error);
            this._emit("end");
            return;
          }
          if (event === "error") {
            const error = args[0];
            if (!tslib_1.__classPrivateFieldGet(this, _MessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
              Promise.reject(error);
            }
            tslib_1.__classPrivateFieldGet(this, _MessageStream_rejectConnectedPromise, "f").call(this, error);
            tslib_1.__classPrivateFieldGet(this, _MessageStream_rejectEndPromise, "f").call(this, error);
            this._emit("end");
          }
        }
        _emitFinal() {
          const finalMessage = this.receivedMessages.at(-1);
          if (finalMessage) {
            this._emit("finalMessage", tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_getFinalMessage).call(this));
          }
        }
        async _fromReadableStream(readableStream, options) {
          const signal = options?.signal;
          let abortHandler;
          if (signal) {
            if (signal.aborted)
              this.controller.abort();
            abortHandler = this.controller.abort.bind(this.controller);
            signal.addEventListener("abort", abortHandler);
          }
          try {
            tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_beginRequest).call(this);
            this._connected(null);
            const stream = streaming_1.Stream.fromReadableStream(readableStream, this.controller);
            for await (const event of stream) {
              tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_addStreamEvent).call(this, event);
            }
            if (stream.controller.signal?.aborted) {
              throw new error_1.APIUserAbortError();
            }
            tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_endRequest).call(this);
          } finally {
            if (signal && abortHandler) {
              signal.removeEventListener("abort", abortHandler);
            }
          }
        }
        [(_MessageStream_currentMessageSnapshot = /* @__PURE__ */ new WeakMap(), _MessageStream_params = /* @__PURE__ */ new WeakMap(), _MessageStream_connectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_resolveConnectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_rejectConnectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_endPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_resolveEndPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_rejectEndPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_listeners = /* @__PURE__ */ new WeakMap(), _MessageStream_ended = /* @__PURE__ */ new WeakMap(), _MessageStream_errored = /* @__PURE__ */ new WeakMap(), _MessageStream_aborted = /* @__PURE__ */ new WeakMap(), _MessageStream_catchingPromiseCreated = /* @__PURE__ */ new WeakMap(), _MessageStream_response = /* @__PURE__ */ new WeakMap(), _MessageStream_request_id = /* @__PURE__ */ new WeakMap(), _MessageStream_workspace_id = /* @__PURE__ */ new WeakMap(), _MessageStream_logger = /* @__PURE__ */ new WeakMap(), _MessageStream_handleError = /* @__PURE__ */ new WeakMap(), _MessageStream_instances = /* @__PURE__ */ new WeakSet(), _MessageStream_getFinalMessage = function _MessageStream_getFinalMessage2() {
          if (this.receivedMessages.length === 0) {
            throw new error_1.AnthropicError("stream ended without producing a Message with role=assistant");
          }
          return this.receivedMessages.at(-1);
        }, _MessageStream_getFinalText = function _MessageStream_getFinalText2() {
          if (this.receivedMessages.length === 0) {
            throw new error_1.AnthropicError("stream ended without producing a Message with role=assistant");
          }
          const textBlocks = this.receivedMessages.at(-1).content.filter((block) => block.type === "text").map((block) => block.text);
          if (textBlocks.length === 0) {
            throw new error_1.AnthropicError("stream ended without producing a content block with type=text");
          }
          return textBlocks.join(" ");
        }, _MessageStream_beginRequest = function _MessageStream_beginRequest2() {
          if (this.ended)
            return;
          tslib_1.__classPrivateFieldSet(this, _MessageStream_currentMessageSnapshot, void 0, "f");
        }, _MessageStream_addStreamEvent = function _MessageStream_addStreamEvent2(event) {
          if (this.ended)
            return;
          const messageSnapshot = tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_accumulateMessage).call(this, event);
          this._emit("streamEvent", event, messageSnapshot);
          switch (event.type) {
            case "content_block_delta": {
              const content = messageSnapshot.content.at(-1);
              switch (event.delta.type) {
                case "text_delta": {
                  if (content.type === "text") {
                    this._emit("text", event.delta.text, content.text || "");
                  }
                  break;
                }
                case "citations_delta": {
                  if (content.type === "text") {
                    this._emit("citation", event.delta.citation, content.citations ?? []);
                  }
                  break;
                }
                case "input_json_delta": {
                  if (tracksToolInput(content) && tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f").inputJson?.length) {
                    this._emit("inputJson", event.delta.partial_json, content.input);
                  }
                  break;
                }
                case "thinking_delta": {
                  if (content.type === "thinking") {
                    this._emit("thinking", event.delta.thinking, content.thinking);
                  }
                  break;
                }
                case "signature_delta": {
                  if (content.type === "thinking") {
                    this._emit("signature", content.signature);
                  }
                  break;
                }
                default:
                  (0, values_1.checkNever)(event.delta);
              }
              break;
            }
            case "message_stop": {
              this._addMessageParam(messageSnapshot);
              this._addMessage((0, parser_1.maybeParseMessage)(messageSnapshot, tslib_1.__classPrivateFieldGet(this, _MessageStream_params, "f"), { logger: tslib_1.__classPrivateFieldGet(this, _MessageStream_logger, "f") }), true);
              break;
            }
            case "content_block_stop": {
              this._emit("contentBlock", messageSnapshot.content.at(-1));
              break;
            }
            case "message_start": {
              tslib_1.__classPrivateFieldSet(this, _MessageStream_currentMessageSnapshot, messageSnapshot, "f");
              break;
            }
            case "content_block_start":
            case "message_delta":
              break;
          }
        }, _MessageStream_endRequest = function _MessageStream_endRequest2() {
          if (this.ended) {
            throw new error_1.AnthropicError(`stream has ended, this shouldn't happen`);
          }
          const snapshot = tslib_1.__classPrivateFieldGet(this, _MessageStream_currentMessageSnapshot, "f");
          if (!snapshot) {
            throw new error_1.AnthropicError(`request ended without sending any chunks`);
          }
          tslib_1.__classPrivateFieldSet(this, _MessageStream_currentMessageSnapshot, void 0, "f");
          return (0, parser_1.maybeParseMessage)(snapshot, tslib_1.__classPrivateFieldGet(this, _MessageStream_params, "f"), { logger: tslib_1.__classPrivateFieldGet(this, _MessageStream_logger, "f") });
        }, _MessageStream_accumulateMessage = function _MessageStream_accumulateMessage2(event) {
          let snapshot = tslib_1.__classPrivateFieldGet(this, _MessageStream_currentMessageSnapshot, "f");
          if (event.type === "message_start") {
            if (snapshot) {
              throw new error_1.AnthropicError(`Unexpected event order, got ${event.type} before receiving "message_stop"`);
            }
            return event.message;
          }
          if (!snapshot) {
            throw new error_1.AnthropicError(`Unexpected event order, got ${event.type} before "message_start"`);
          }
          switch (event.type) {
            case "message_stop":
              return snapshot;
            case "message_delta":
              snapshot.stop_reason = event.delta.stop_reason;
              snapshot.stop_sequence = event.delta.stop_sequence;
              snapshot.stop_details = event.delta.stop_details;
              snapshot.usage.output_tokens = event.usage.output_tokens;
              if (event.delta.container != null) {
                snapshot.container = event.delta.container;
              }
              if (event.usage.input_tokens != null) {
                snapshot.usage.input_tokens = event.usage.input_tokens;
              }
              if (event.usage.cache_creation_input_tokens != null) {
                snapshot.usage.cache_creation_input_tokens = event.usage.cache_creation_input_tokens;
              }
              if (event.usage.cache_read_input_tokens != null) {
                snapshot.usage.cache_read_input_tokens = event.usage.cache_read_input_tokens;
              }
              if (event.usage.server_tool_use != null) {
                snapshot.usage.server_tool_use = event.usage.server_tool_use;
              }
              if (event.usage.output_tokens_details != null) {
                snapshot.usage.output_tokens_details = event.usage.output_tokens_details;
              }
              return snapshot;
            case "content_block_start":
              snapshot.content.push({ ...event.content_block });
              return snapshot;
            case "content_block_delta": {
              const snapshotContent = snapshot.content.at(event.index);
              switch (event.delta.type) {
                case "text_delta": {
                  if (snapshotContent?.type === "text") {
                    snapshot.content[event.index] = {
                      ...snapshotContent,
                      text: (snapshotContent.text || "") + event.delta.text
                    };
                  }
                  break;
                }
                case "citations_delta": {
                  if (snapshotContent?.type === "text") {
                    snapshot.content[event.index] = {
                      ...snapshotContent,
                      citations: [...snapshotContent.citations ?? [], event.delta.citation]
                    };
                  }
                  break;
                }
                case "input_json_delta": {
                  if (snapshotContent && tracksToolInput(snapshotContent)) {
                    const jsonBuf = (snapshotContent[message_stream_utils_1.JSON_BUF_PROPERTY] || "") + event.delta.partial_json;
                    snapshot.content[event.index] = (0, message_stream_utils_1.withLazyInput)(snapshotContent, jsonBuf);
                  }
                  break;
                }
                case "thinking_delta": {
                  if (snapshotContent?.type === "thinking") {
                    snapshot.content[event.index] = {
                      ...snapshotContent,
                      thinking: snapshotContent.thinking + event.delta.thinking
                    };
                  }
                  break;
                }
                case "signature_delta": {
                  if (snapshotContent?.type === "thinking") {
                    snapshot.content[event.index] = {
                      ...snapshotContent,
                      signature: event.delta.signature
                    };
                  }
                  break;
                }
                default:
                  (0, values_1.checkNever)(event.delta);
              }
              return snapshot;
            }
            case "content_block_stop": {
              const snapshotContent = snapshot.content.at(event.index);
              if (snapshotContent && tracksToolInput(snapshotContent) && message_stream_utils_1.JSON_BUF_PROPERTY in snapshotContent) {
                Object.defineProperty(snapshotContent, "input", {
                  value: snapshotContent.input,
                  enumerable: true,
                  configurable: true,
                  writable: true
                });
              }
              return snapshot;
            }
          }
        }, Symbol.asyncIterator)]() {
          const pushQueue = [];
          const readQueue = [];
          let done = false;
          this.on("streamEvent", (event) => {
            const reader = readQueue.shift();
            if (reader) {
              reader.resolve(event);
            } else {
              pushQueue.push(event);
            }
          });
          this.on("end", () => {
            done = true;
            for (const reader of readQueue) {
              reader.resolve(void 0);
            }
            readQueue.length = 0;
          });
          this.on("abort", (err) => {
            done = true;
            for (const reader of readQueue) {
              reader.reject(err);
            }
            readQueue.length = 0;
          });
          this.on("error", (err) => {
            done = true;
            for (const reader of readQueue) {
              reader.reject(err);
            }
            readQueue.length = 0;
          });
          return {
            next: async () => {
              if (!pushQueue.length) {
                if (done) {
                  return { value: void 0, done: true };
                }
                return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
              }
              const chunk = pushQueue.shift();
              return { value: chunk, done: false };
            },
            return: async () => {
              this.abort();
              return { value: void 0, done: true };
            }
          };
        }
        toReadableStream() {
          const stream = new streaming_1.Stream(this[Symbol.asyncIterator].bind(this), this.controller);
          return stream.toReadableStream();
        }
      }
      return MessageStream2;
    })();
    exports2.MessageStream = MessageStream;
  }
});

// node_modules/@anthropic-ai/sdk/resources/messages/batches.js
var require_batches2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/messages/batches.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Batches = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var jsonl_1 = require_jsonl();
    var error_1 = require_error2();
    var path_1 = require_path();
    var Batches = class extends resource_1.APIResource {
      /**
       * Send a batch of Message creation requests.
       *
       * The Message Batches API can be used to process multiple Messages API requests at
       * once. Once a Message Batch is created, it begins processing immediately. Batches
       * can take up to 24 hours to complete.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const messageBatch = await client.messages.batches.create({
       *   requests: [
       *     {
       *       custom_id: 'my-custom-id-1',
       *       params: {
       *         max_tokens: 1024,
       *         messages: [
       *           { content: 'Hello, world', role: 'user' },
       *         ],
       *         model: 'claude-opus-5',
       *       },
       *     },
       *   ],
       * });
       * ```
       */
      create(params, options) {
        const { user_profile_id, workspace_id, ...body } = params;
        return this._client.post("/v1/messages/batches", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * This endpoint is idempotent and can be used to poll for Message Batch
       * completion. To access the results of a Message Batch, make a request to the
       * `results_url` field in the response.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const messageBatch = await client.messages.batches.retrieve(
       *   'message_batch_id',
       * );
       * ```
       */
      retrieve(messageBatchID, params = {}, options) {
        const { workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/messages/batches/${messageBatchID}`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * List all Message Batches within a Workspace. Most recently created batches are
       * returned first.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const messageBatch of client.messages.batches.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { workspace_id, ...query } = params ?? {};
        return this._client.getAPIList("/v1/messages/batches", pagination_1.Page, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * Delete a Message Batch.
       *
       * Message Batches can only be deleted once they've finished processing. If you'd
       * like to delete an in-progress batch, you must first cancel it.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const deletedMessageBatch =
       *   await client.messages.batches.delete('message_batch_id');
       * ```
       */
      delete(messageBatchID, params = {}, options) {
        const { workspace_id } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/messages/batches/${messageBatchID}`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * Batches may be canceled any time before processing ends. Once cancellation is
       * initiated, the batch enters a `canceling` state, at which time the system may
       * complete any in-progress, non-interruptible requests before finalizing
       * cancellation.
       *
       * The number of canceled requests is specified in `request_counts`. To determine
       * which requests were canceled, check the individual results within the batch.
       * Note that cancellation may not result in any canceled requests if they were
       * non-interruptible.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const messageBatch = await client.messages.batches.cancel(
       *   'message_batch_id',
       * );
       * ```
       */
      cancel(messageBatchID, params = {}, options) {
        const { workspace_id } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/messages/batches/${messageBatchID}/cancel`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * Streams the results of a Message Batch as a `.jsonl` file.
       *
       * Each line in the file is a JSON object containing the result of a single request
       * in the Message Batch. Results are not guaranteed to be in the same order as
       * requests. Use the `custom_id` field to match results to requests.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://platform.claude.com/docs/en/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const messageBatchIndividualResponse =
       *   await client.messages.batches.results('message_batch_id');
       * ```
       */
      async results(messageBatchID, params = {}, options) {
        const batch = await this.retrieve(messageBatchID, params, options);
        if (!batch.results_url) {
          throw new error_1.AnthropicError(`No batch \`results_url\`; Has it finished processing? ${batch.processing_status} - ${batch.id}`);
        }
        const { workspace_id } = params ?? {};
        return this._client.get(batch.results_url, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              Accept: "application/binary",
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ]),
          stream: true,
          __binaryResponse: true
        })._thenUnwrap((_, props) => jsonl_1.JSONLDecoder.fromResponse(props.response, props.controller));
      }
    };
    exports2.Batches = Batches;
  }
});

// node_modules/@anthropic-ai/sdk/resources/messages/messages.js
var require_messages2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/messages/messages.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Messages = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var headers_1 = require_headers();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var MessageStream_1 = require_MessageStream();
    var parser_1 = require_parser2();
    var BatchesAPI = tslib_1.__importStar(require_batches2());
    var batches_1 = require_batches2();
    var constants_1 = require_constants();
    var Messages = /* @__PURE__ */ (() => {
      class Messages2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.batches = new BatchesAPI.Batches(this._client);
        }
        create(params, options) {
          const { user_profile_id, workspace_id, ...body } = params;
          if (body.model in DEPRECATED_MODELS) {
            console.warn(`The model '${body.model}' is deprecated and will reach end-of-life on ${DEPRECATED_MODELS[body.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`);
          }
          if (MODELS_TO_WARN_WITH_THINKING_ENABLED.includes(body.model) && body.thinking && body.thinking.type === "enabled") {
            console.warn(`Using Claude with ${body.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
          }
          let timeout = options?.timeout ?? this._client._options.timeout;
          if (!body.stream && timeout == null) {
            const maxNonstreamingTokens = constants_1.MODEL_NONSTREAMING_TOKENS[body.model] ?? void 0;
            timeout = this._client.calculateNonstreamingTimeout(body.max_tokens, maxNonstreamingTokens);
          }
          const helperHeader = (0, stainless_helper_header_1.stainlessHelperHeader)(body.tools, body.messages);
          return this._client.post("/v1/messages", {
            body,
            timeout: timeout ?? 6e5,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              helperHeader,
              options?.headers
            ]),
            stream: params.stream ?? false
          });
        }
        /**
         * Send a structured list of input messages with text and/or image content, along with an expected `output_config.format` and
         * the response will be automatically parsed and available in the `parsed_output` property of the message.
         *
         * @example
         * ```ts
         * const message = await client.messages.parse({
         *   model: 'claude-sonnet-4-5-20250929',
         *   max_tokens: 1024,
         *   messages: [{ role: 'user', content: 'What is 2+2?' }],
         *   output_config: {
         *     format: zodOutputFormat(z.object({ answer: z.number() })),
         *   },
         * });
         *
         * console.log(message.parsed_output?.answer); // 4
         * ```
         */
        parse(params, options) {
          return this.create(params, options).then((message) => (0, parser_1.parseMessage)(message, params, { logger: this._client.logger ?? console }));
        }
        /**
         * Create a Message stream.
         *
         * If `output_config.format` is provided with a parseable format (like `zodOutputFormat()`),
         * the final message will include a `parsed_output` property with the parsed content.
         *
         * @example
         * ```ts
         * const stream = client.messages.stream({
         *   model: 'claude-sonnet-4-5-20250929',
         *   max_tokens: 1024,
         *   messages: [{ role: 'user', content: 'What is 2+2?' }],
         *   output_config: {
         *     format: zodOutputFormat(z.object({ answer: z.number() })),
         *   },
         * });
         *
         * const message = await stream.finalMessage();
         * console.log(message.parsed_output?.answer); // 4
         * ```
         */
        stream(body, options) {
          return MessageStream_1.MessageStream.createMessage(this, body, options, { logger: this._client.logger ?? console });
        }
        /**
         * Count the number of tokens in a Message.
         *
         * The Token Count API can be used to count the number of tokens in a Message,
         * including tools, images, and documents, without creating it.
         *
         * Learn more about token counting in our
         * [user guide](https://platform.claude.com/docs/en/build-with-claude/token-counting)
         *
         * @example
         * ```ts
         * const messageTokensCount =
         *   await client.messages.countTokens({
         *     messages: [{ content: 'Hello, world', role: 'user' }],
         *     model: 'claude-opus-5',
         *   });
         * ```
         */
        countTokens(params, options) {
          const { user_profile_id, workspace_id, ...body } = params;
          return this._client.post("/v1/messages/count_tokens", {
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              {
                ...user_profile_id != null ? { "anthropic-user-profile-id": user_profile_id } : void 0,
                ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
              },
              options?.headers
            ])
          });
        }
      }
      Messages2.Batches = batches_1.Batches;
      return Messages2;
    })();
    exports2.Messages = Messages;
    var DEPRECATED_MODELS = {};
    var MODELS_TO_WARN_WITH_THINKING_ENABLED = ["claude-mythos-preview", "claude-opus-4-6"];
  }
});

// node_modules/@anthropic-ai/sdk/resources/models.js
var require_models2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/models.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Models = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Models = class extends resource_1.APIResource {
      /**
       * Get a specific model.
       *
       * The Models API response can be used to determine information about a specific
       * model or resolve a model alias to a model ID.
       *
       * @example
       * ```ts
       * const modelInfo = await client.models.retrieve('model_id');
       * ```
       */
      retrieve(modelID, params = {}, options) {
        const { betas, workspace_id } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/models/${modelID}`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * List available models.
       *
       * The Models API response can be used to determine which models are available for
       * use in the API. More recently released models are listed first.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const modelInfo of client.models.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, workspace_id, ...query } = params ?? {};
        return this._client.getAPIList("/v1/models", pagination_1.Page, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0,
              ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0
            },
            options?.headers
          ])
        });
      }
    };
    exports2.Models = Models;
  }
});

// node_modules/@anthropic-ai/sdk/resources/skills/versions.js
var require_versions3 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/skills/versions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Versions = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var uploads_1 = require_uploads();
    var path_1 = require_path();
    var Versions = class extends resource_1.APIResource {
      /**
       * Create Skill Version
       *
       * @example
       * ```ts
       * const skillVersion = await client.skills.versions.create(
       *   'skill_id',
       *   { files: [fs.createReadStream('path/to/file')] },
       * );
       * ```
       */
      create(skillID, params, options) {
        const { workspace_id, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/skills/${skillID}/versions`, (0, uploads_1.multipartFormRequestOptions)({
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        }, this._client, false));
      }
      /**
       * Get Skill Version
       *
       * @example
       * ```ts
       * const skillVersion = await client.skills.versions.retrieve(
       *   'version',
       *   { skill_id: 'skill_id' },
       * );
       * ```
       */
      retrieve(version, params, options) {
        const { skill_id, workspace_id } = params;
        return this._client.get((0, path_1.path)`/v1/skills/${skill_id}/versions/${version}`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * List Skill Versions
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const skillVersion of client.skills.versions.list(
       *   'skill_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(skillID, params = {}, options) {
        const { workspace_id, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/skills/${skillID}/versions`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * Delete Skill Version
       *
       * @example
       * ```ts
       * const deletedSkillVersion =
       *   await client.skills.versions.delete('version', {
       *     skill_id: 'skill_id',
       *   });
       * ```
       */
      delete(version, params, options) {
        const { skill_id, workspace_id } = params;
        return this._client.delete((0, path_1.path)`/v1/skills/${skill_id}/versions/${version}`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
            options?.headers
          ])
        });
      }
    };
    exports2.Versions = Versions;
  }
});

// node_modules/@anthropic-ai/sdk/resources/skills/skills.js
var require_skills3 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/skills/skills.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Skills = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var VersionsAPI = tslib_1.__importStar(require_versions3());
    var versions_1 = require_versions3();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var uploads_1 = require_uploads();
    var path_1 = require_path();
    var Skills = /* @__PURE__ */ (() => {
      class Skills2 extends resource_1.APIResource {
        constructor() {
          super(...arguments);
          this.versions = new VersionsAPI.Versions(this._client);
        }
        /**
         * Create Skill
         *
         * @example
         * ```ts
         * const skill = await client.skills.create({
         *   files: [fs.createReadStream('path/to/file')],
         * });
         * ```
         */
        create(params, options) {
          const { workspace_id, ...body } = params;
          return this._client.post("/v1/skills", (0, uploads_1.multipartFormRequestOptions)({
            body,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
              options?.headers
            ])
          }, this._client, false));
        }
        /**
         * Get Skill
         *
         * @example
         * ```ts
         * const skill = await client.skills.retrieve('skill_id');
         * ```
         */
        retrieve(skillID, params = {}, options) {
          const { workspace_id } = params ?? {};
          return this._client.get((0, path_1.path)`/v1/skills/${skillID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * List Skills
         *
         * @example
         * ```ts
         * // Automatically fetches more pages as needed.
         * for await (const skill of client.skills.list()) {
         *   // ...
         * }
         * ```
         */
        list(params = {}, options) {
          const { workspace_id, ...query } = params ?? {};
          return this._client.getAPIList("/v1/skills", pagination_1.PageCursor, {
            query,
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
              options?.headers
            ])
          });
        }
        /**
         * Delete Skill
         *
         * @example
         * ```ts
         * const deletedSkill = await client.skills.delete('skill_id');
         * ```
         */
        delete(skillID, params = {}, options) {
          const { workspace_id } = params ?? {};
          return this._client.delete((0, path_1.path)`/v1/skills/${skillID}`, {
            ...options,
            headers: (0, headers_1.buildHeaders)([
              { ...workspace_id != null ? { "anthropic-workspace-id": workspace_id } : void 0 },
              options?.headers
            ])
          });
        }
      }
      Skills2.Versions = versions_1.Versions;
      return Skills2;
    })();
    exports2.Skills = Skills;
  }
});

// node_modules/@anthropic-ai/sdk/resources/index.js
var require_resources2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Skills = exports2.Models = exports2.Messages = exports2.Files = exports2.Completions = exports2.Beta = void 0;
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_shared(), exports2);
    var beta_1 = require_beta();
    Object.defineProperty(exports2, "Beta", { enumerable: true, get: function() {
      return beta_1.Beta;
    } });
    var completions_1 = require_completions();
    Object.defineProperty(exports2, "Completions", { enumerable: true, get: function() {
      return completions_1.Completions;
    } });
    var files_1 = require_files2();
    Object.defineProperty(exports2, "Files", { enumerable: true, get: function() {
      return files_1.Files;
    } });
    var messages_1 = require_messages2();
    Object.defineProperty(exports2, "Messages", { enumerable: true, get: function() {
      return messages_1.Messages;
    } });
    var models_1 = require_models2();
    Object.defineProperty(exports2, "Models", { enumerable: true, get: function() {
      return models_1.Models;
    } });
    var skills_1 = require_skills3();
    Object.defineProperty(exports2, "Skills", { enumerable: true, get: function() {
      return skills_1.Skills;
    } });
  }
});

// node_modules/@anthropic-ai/sdk/client.js
var require_client = __commonJS({
  "node_modules/@anthropic-ai/sdk/client.js"(exports2) {
    "use strict";
    var _BaseAnthropic_instances;
    var _a;
    var _BaseAnthropic_encoder;
    var _BaseAnthropic_baseURLOverridden;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Anthropic = exports2.BaseAnthropic = exports2.AI_PROMPT = exports2.HUMAN_PROMPT = void 0;
    var tslib_1 = require_tslib();
    var values_1 = require_values();
    var sleep_1 = require_sleep();
    var errors_1 = require_errors();
    var detect_platform_1 = require_detect_platform();
    var request_signal_1 = require_request_signal();
    var Shims = tslib_1.__importStar(require_shims());
    var Opts = tslib_1.__importStar(require_request_options());
    var query_1 = require_query();
    var version_1 = require_version();
    var Errors = tslib_1.__importStar(require_error());
    var types_1 = require_types();
    var token_cache_1 = require_token_cache();
    var credential_chain_1 = require_credential_chain();
    var middleware_1 = require_middleware();
    var Pagination = tslib_1.__importStar(require_pagination());
    var Uploads = tslib_1.__importStar(require_uploads2());
    var API = tslib_1.__importStar(require_resources2());
    var api_promise_1 = require_api_promise();
    var completions_1 = require_completions();
    var files_1 = require_files2();
    var models_1 = require_models2();
    var beta_1 = require_beta();
    var messages_1 = require_messages2();
    var skills_1 = require_skills3();
    var detect_platform_2 = require_detect_platform();
    var headers_1 = require_headers();
    var env_1 = require_env();
    var log_1 = require_log();
    var values_2 = require_values();
    exports2.HUMAN_PROMPT = "\\n\\nHuman:";
    exports2.AI_PROMPT = "\\n\\nAssistant:";
    var BaseAnthropic = /* @__PURE__ */ (() => {
      class BaseAnthropic2 {
        /**
         * The active credential provider. Default credential resolution runs once
         * at construction time. If it fails, the error is surfaced on every
         * request and the client must be reconstructed — there is no retry path.
         *
         * Clones returned by {@link withOptions} share the parent's auth state
         * (provider, token cache, pending resolution, and any resolution error)
         * unless the caller passes an explicit `apiKey`, `authToken`,
         * `credentials`, `config`, or `profile` override.
         */
        get credentials() {
          return this._authState.provider;
        }
        /**
         * API Client for interfacing with the Anthropic API.
         *
         * @param {string | null | undefined} [opts.apiKey=process.env['ANTHROPIC_API_KEY'] ?? null]
         * @param {string | null | undefined} [opts.authToken=process.env['ANTHROPIC_AUTH_TOKEN'] ?? null]
         * @param {string | null | undefined} [opts.webhookKey=process.env['ANTHROPIC_WEBHOOK_SIGNING_KEY'] ?? null]
         * @param {string} [opts.baseURL=process.env['ANTHROPIC_BASE_URL'] ?? https://api.anthropic.com] - Override the default base URL for the API.
         * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
         * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
         * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
         * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
         * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
         * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
         * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
         */
        constructor({ baseURL = (0, env_1.readEnv)("ANTHROPIC_BASE_URL"), apiKey, authToken, webhookKey = (0, env_1.readEnv)("ANTHROPIC_WEBHOOK_SIGNING_KEY") ?? null, ...opts } = {}) {
          _BaseAnthropic_instances.add(this);
          this._requestAuthFlags = /* @__PURE__ */ new WeakMap();
          _BaseAnthropic_encoder.set(this, void 0);
          if (apiKey === void 0) {
            apiKey = opts.profile != null ? null : (0, env_1.readEnv)("ANTHROPIC_API_KEY") ?? null;
          }
          if (authToken === void 0) {
            authToken = opts.profile != null ? null : (0, env_1.readEnv)("ANTHROPIC_AUTH_TOKEN") ?? null;
          }
          if (opts.profile != null && (opts.credentials != null || opts.config != null)) {
            throw new TypeError("Pass at most one of `profile`, `credentials`, or `config`.");
          }
          const options = {
            apiKey,
            authToken,
            webhookKey,
            ...opts,
            baseURL: baseURL || `https://api.anthropic.com`
          };
          if (!options.dangerouslyAllowBrowser && (0, detect_platform_2.isRunningInBrowser)()) {
            throw new Errors.AnthropicError("It looks like you're running in a browser-like environment.\n\nThis is disabled by default, as it risks exposing your secret API credentials to attackers.\nIf you understand the risks and have appropriate mitigations in place,\nyou can set the `dangerouslyAllowBrowser` option to `true`, e.g.,\n\nnew Anthropic({ apiKey, dangerouslyAllowBrowser: true });\n");
          }
          this.baseURL = options.baseURL;
          this._baseURLIsExplicit = opts.__baseURLIsExplicit ?? !!baseURL;
          this.timeout = options.timeout ?? _a.DEFAULT_TIMEOUT;
          this.logger = options.logger ?? console;
          this.logLevel = log_1.defaultLogLevel;
          this.logLevel = (0, log_1.parseLogLevel)(options.logLevel, "ClientOptions.logLevel", (0, log_1.loggerFor)(this)) ?? (0, log_1.parseLogLevel)((0, env_1.readEnv)("ANTHROPIC_LOG"), "process.env['ANTHROPIC_LOG']", (0, log_1.loggerFor)(this)) ?? log_1.defaultLogLevel;
          this.fetchOptions = options.fetchOptions;
          this.maxRetries = (0, values_1.validatePositiveInteger)("maxRetries", options.maxRetries ?? 2);
          this.fetch = options.fetch ?? Shims.getDefaultFetch();
          tslib_1.__classPrivateFieldSet(this, _BaseAnthropic_encoder, Opts.FallbackEncoder, "f");
          this.middleware = [...options.middleware ?? []];
          const customHeadersEnv = (0, env_1.readEnv)("ANTHROPIC_CUSTOM_HEADERS");
          if (customHeadersEnv) {
            const parsed = {};
            for (const line of customHeadersEnv.split("\n")) {
              const colon = line.indexOf(":");
              if (colon >= 0) {
                parsed[line.substring(0, colon).trim()] = line.substring(colon + 1).trim();
              }
            }
            options.defaultHeaders = { ...parsed, ...options.defaultHeaders };
          }
          const inherited = opts.__auth;
          delete options.__auth;
          delete options.__baseURLIsExplicit;
          this._options = options;
          this.apiKey = typeof apiKey === "string" ? apiKey : null;
          this.authToken = authToken;
          this.webhookKey = webhookKey;
          if (inherited) {
            this._authState = inherited;
            if (!this._baseURLIsExplicit && inherited.baseURL) {
              this.baseURL = inherited.baseURL;
            }
          } else {
            this._authState = { provider: null, tokenCache: null, resolution: null, error: null, extraHeaders: {} };
            if (this.apiKey == null && this.authToken == null) {
              const credentials = options.credentials ?? null;
              if (credentials) {
                this._authState.provider = credentials;
                this._authState.tokenCache = this._makeTokenCache(credentials);
              } else if (options.config != null) {
                const result = (0, credential_chain_1.resolveCredentialsFromConfig)(options.config, this._credentialResolverOptions());
                this._authState.provider = result.provider;
                this._authState.tokenCache = this._makeTokenCache(result.provider);
                this._authState.extraHeaders = result.extraHeaders;
                this._applyCredentialBaseURL(result.baseURL);
              } else if (options.profile != null) {
                this._authState.resolution = this._resolveDefaultCredentials(options.profile);
              } else if (this._shouldResolveDefaultCredentials()) {
                this._authState.resolution = this._resolveDefaultCredentials();
              }
            }
          }
        }
        /**
         * Whether to lazily resolve auth from the default credential chain when no
         * explicit auth is configured. Called once from the constructor, so
         * overrides must not depend on subclass instance state. Subclasses that
         * bring their own auth scheme return false so unrelated local credentials
         * are never resolved or allowed to supply a base URL.
         */
        _shouldResolveDefaultCredentials() {
          return true;
        }
        /**
         * Stores a profile/config-supplied base URL on the shared auth state and, if
         * the caller did not pin `baseURL` via constructor option or env, adopts it
         * as this client's outbound API host. Precedence: ctor opt > env > profile >
         * hardcoded default.
         */
        _applyCredentialBaseURL(baseURL) {
          if (!baseURL)
            return;
          const normalized = baseURL.replace(/\/+$/, "");
          this._authState.baseURL = normalized;
          if (!this._baseURLIsExplicit) {
            this.baseURL = normalized;
          }
        }
        /**
         * Options bag passed into the credential chain. `baseURL` here is only the
         * fallback host for the token-exchange POST when the config itself omits
         * `base_url`; the chain returns the config's own `base_url` (if any) on
         * {@link CredentialResult.baseURL}, which {@link _applyCredentialBaseURL}
         * then adopts for outbound API requests. The two are deliberately decoupled
         * so this fallback never round-trips into precedence.
         */
        _credentialResolverOptions() {
          return {
            baseURL: this.baseURL,
            fetch: this._credentialsFetch(),
            userAgent: this.getUserAgent(),
            onCacheWriteError: (err) => {
              (0, log_1.loggerFor)(this).debug("credential cache write failed (best-effort)", err);
            },
            onSafetyWarning: (msg) => {
              (0, log_1.loggerFor)(this).warn(msg);
            }
          };
        }
        /**
         * A `Fetch` for first-party credential token-exchange requests (OIDC
         * federation jwt-bearer grants, user-OAuth refresh grants) that routes
         * through this client's middleware chain, so middleware observes token
         * traffic like any other request. Only client-level middleware applies:
         * a minted token is shared across requests, so attributing the exchange
         * to any one request's per-request middleware would be arbitrary. For the
         * same reason, `ctx.options` is undefined for these requests.
         */
        _credentialsFetch() {
          return (0, middleware_1.wrapFetchWithMiddleware)(this.fetch, this.middleware, void 0, this);
        }
        _makeTokenCache(provider) {
          return new token_cache_1.TokenCache(provider, (err) => {
            (0, log_1.loggerFor)(this).debug("advisory token refresh failed; serving cached token", err);
          });
        }
        /**
         * Create a new client instance re-using the same options given to the
         * current client with optional overriding.
         */
        withOptions(options) {
          const overridesStructuredAuth = "credentials" in options || "config" in options || "profile" in options;
          const overridesAuth = "apiKey" in options || "authToken" in options || overridesStructuredAuth;
          const internal = {
            ...this._options,
            // Only forward baseURL when the caller (or env) explicitly chose it.
            // For a non-explicit parent, this.baseURL may have been mutated to the
            // profile-resolved host; pinning that as the clone's options.baseURL
            // would make _options on the clone misreport caller intent and would
            // leave the clone stuck on the parent's host across an auth override.
            // The clone instead receives the construction-time value via
            // ...this._options above and re-adopts the profile host through the
            // shared _authState.baseURL + __baseURLIsExplicit=false path.
            ...this._baseURLIsExplicit ? { baseURL: this.baseURL } : {},
            maxRetries: this.maxRetries,
            timeout: this.timeout,
            logger: this.logger,
            logLevel: this.logLevel,
            fetch: this.fetch,
            fetchOptions: this.fetchOptions,
            middleware: this.middleware,
            apiKey: this.apiKey,
            authToken: this.authToken,
            webhookKey: this.webhookKey,
            // credentials: this.credentials is a no-op when __auth is shared (the
            // ctor takes the inherited path and ignores options.credentials); when
            // overridesAuth is true via apiKey/authToken only, it lets the clone
            // build a fresh TokenCache around the parent's provider.
            credentials: this.credentials,
            // When the caller passes a structured-credential override, drop inherited
            // structured-credential options so only `...options` supplies them —
            // otherwise an inherited `credentials`/`config`/`profile` would trip the
            // mutual-exclusion check or precedence over the override.
            ...overridesStructuredAuth ? { credentials: void 0, config: void 0, profile: void 0 } : {},
            ...options,
            // Always set __auth so any stale value from ...this._options is
            // overwritten. undefined means "build fresh auth from these options".
            __auth: overridesAuth ? void 0 : this._authState,
            __baseURLIsExplicit: "baseURL" in options ? true : this._baseURLIsExplicit
          };
          return new this.constructor(internal);
        }
        /**
         * Lazily resolves credentials from config files or environment variables.
         * Called once from the constructor when no explicit auth is provided, or
         * when an explicit `profile` was passed (in which case a missing/unresolved
         * profile is surfaced as an error instead of falling through to "no auth").
         * The returned promise is stored and awaited on the first request.
         */
        async _resolveDefaultCredentials(profile) {
          try {
            const result = await (0, credential_chain_1.defaultCredentials)(this._credentialResolverOptions(), profile);
            if (result) {
              this._authState.provider = result.provider;
              this._authState.tokenCache = this._makeTokenCache(result.provider);
              this._authState.extraHeaders = result.extraHeaders;
              this._applyCredentialBaseURL(result.baseURL);
            } else if (profile != null) {
              throw new Errors.AnthropicError(`Profile "${profile}" could not be resolved (no <config_dir>/configs/${profile}.json found).`);
            }
          } catch (err) {
            this._authState.error = err;
          } finally {
            this._authState.resolution = null;
          }
        }
        defaultQuery() {
          return this._options.defaultQuery;
        }
        validateHeaders({ values, nulls }) {
          if (values.get("x-api-key") || values.get("authorization")) {
            return;
          }
          if (this._authState.error) {
            throw this._authState.error;
          }
          if (this._authState.tokenCache || this._authState.resolution) {
            return;
          }
          if (this.apiKey && values.get("x-api-key")) {
            return;
          }
          if (nulls.has("x-api-key")) {
            return;
          }
          if (this.authToken && values.get("authorization")) {
            return;
          }
          if (nulls.has("authorization")) {
            return;
          }
          throw new Error('Could not resolve authentication method. Expected one of apiKey, authToken, credentials, config, or profile to be set. Or for one of the "X-Api-Key" or "Authorization" headers to be explicitly omitted');
        }
        _authFlags(opts) {
          let flags = this._requestAuthFlags.get(opts);
          if (!flags) {
            flags = { usedTokenCache: false, didRefreshFor401: false };
            this._requestAuthFlags.set(opts, flags);
          }
          return flags;
        }
        async authHeaders(opts) {
          if (this._authState.resolution) {
            await this._authState.resolution;
          }
          if (this._authState.error) {
            return void 0;
          }
          if (this._authState.tokenCache && this.apiKey == null) {
            const token = await this._authState.tokenCache.getToken();
            this._authFlags(opts).usedTokenCache = true;
            return (0, headers_1.buildHeaders)([{ Authorization: `Bearer ${token}` }]);
          }
          return (0, headers_1.buildHeaders)([await this.apiKeyAuth(opts), await this.bearerAuth(opts)]);
        }
        async apiKeyAuth(opts) {
          if (this.apiKey == null) {
            return void 0;
          }
          return (0, headers_1.buildHeaders)([{ "X-Api-Key": this.apiKey }]);
        }
        async bearerAuth(opts) {
          if (this.authToken == null) {
            return void 0;
          }
          return (0, headers_1.buildHeaders)([{ Authorization: `Bearer ${this.authToken}` }]);
        }
        stringifyQuery(query) {
          return (0, query_1.stringifyQuery)(query);
        }
        getUserAgent() {
          return `Anthropic/JS ${version_1.VERSION}`;
        }
        makeStatusError(status, error, message, headers) {
          return Errors.APIError.generate(status, error, message, headers);
        }
        buildURL(path2, query, defaultBaseURL) {
          const baseURL = !tslib_1.__classPrivateFieldGet(this, _BaseAnthropic_instances, "m", _BaseAnthropic_baseURLOverridden).call(this) && defaultBaseURL || this.baseURL;
          const url = (0, values_1.isAbsoluteURL)(path2) ? new URL(path2) : new URL(baseURL + (baseURL.endsWith("/") && path2.startsWith("/") ? path2.slice(1) : path2));
          const defaultQuery = this.defaultQuery();
          const pathQuery = Object.fromEntries(url.searchParams);
          if (!(0, values_2.isEmptyObj)(defaultQuery) || !(0, values_2.isEmptyObj)(pathQuery)) {
            query = { ...pathQuery, ...defaultQuery, ...query };
          }
          if (typeof query === "object" && query && !Array.isArray(query)) {
            url.search = this.stringifyQuery(query);
          }
          return url.toString();
        }
        _calculateNonstreamingTimeout(maxTokens) {
          const defaultTimeout = 10 * 60;
          const expectedTimeout = 60 * 60 * maxTokens / 128e3;
          if (expectedTimeout > defaultTimeout) {
            throw new Errors.AnthropicError("Streaming is required for operations that may take longer than 10 minutes. See https://github.com/anthropics/anthropic-sdk-typescript#streaming-responses for more details");
          }
          return defaultTimeout * 1e3;
        }
        /**
         * Used as a callback for mutating the given `FinalRequestOptions` object.
         */
        async prepareOptions(options) {
        }
        /**
         * Used as a callback for mutating the given `RequestInit` object.
         *
         * This is useful for cases where you want to add certain headers based off of
         * the request properties, e.g. `method` or `url`.
         *
         * Runs after all middleware (including {@link backendMiddleware}),
         * immediately before each underlying fetch call, so it sees exactly what
         * goes over the wire. Middleware may replay a request by calling `next()`
         * more than once, so this hook can run multiple times per attempt:
         * overrides must be idempotent and overwrite headers from a previous
         * invocation rather than append to them.
         */
        async prepareRequest(request, { url, options }) {
          if (this._authState.tokenCache && this.apiKey == null) {
            const headers = request.headers instanceof Headers ? request.headers : new Headers(request.headers);
            for (const [k, v] of Object.entries(this._authState.extraHeaders)) {
              if (!headers.has(k))
                headers.set(k, v);
            }
            const existing = headers.get("anthropic-beta")?.split(",").map((s) => s.trim());
            if (!existing?.includes(types_1.OAUTH_API_BETA_HEADER)) {
              headers.set("anthropic-beta", [...existing ?? [], types_1.OAUTH_API_BETA_HEADER].join(","));
            }
            request.headers = headers;
          }
        }
        /**
         * Internal {@link Middleware} composed innermost in the chain — inside both
         * client-level and per-request middleware, immediately around the underlying
         * `fetch`. Subclasses for third-party backends override this to adapt the
         * canonical Anthropic-shaped request to the backend's wire shape (URL/body
         * rewriting, request signing) and to normalize the wire response back to the
         * canonical shape (e.g. AWS EventStream to SSE).
         *
         * Running inside the user's middleware means user middleware always observes
         * canonical Anthropic-shaped traffic, and the adaptation re-runs (e.g.
         * re-signs) on every `next()` invocation, covering whatever the middleware
         * mutated.
         *
         * Errors thrown here follow the middleware error policy: they propagate to
         * the caller as-is — no retries, no `APIConnectionError` wrapping — unless
         * retryable (see {@link Middleware}); throw a `RetryableError` to opt into
         * the retry path.
         */
        backendMiddleware() {
          return [];
        }
        get(path2, opts) {
          return this.methodRequest("get", path2, opts);
        }
        post(path2, opts) {
          return this.methodRequest("post", path2, opts);
        }
        patch(path2, opts) {
          return this.methodRequest("patch", path2, opts);
        }
        put(path2, opts) {
          return this.methodRequest("put", path2, opts);
        }
        delete(path2, opts) {
          return this.methodRequest("delete", path2, opts);
        }
        methodRequest(method, path2, opts) {
          return this.request(Promise.resolve(opts).then((opts2) => {
            return { method, path: path2, ...opts2 };
          }));
        }
        request(options, remainingRetries = null) {
          return new api_promise_1.APIPromise(this, this.makeRequest(options, remainingRetries, void 0));
        }
        async makeRequest(optionsInput, retriesRemaining, retryOfRequestLogID) {
          const options = await optionsInput;
          let maxRetries = (0, values_1.validatePositiveInteger)("maxRetries", options.maxRetries ?? this.maxRetries);
          if (this.isStreamBody(options.body)) {
            maxRetries = 0;
          }
          if (retriesRemaining == null) {
            retriesRemaining = maxRetries;
            this._requestAuthFlags.delete(options);
          }
          await this.prepareOptions(options);
          const { req, url, timeout } = await this.buildRequest(options, {
            retryCount: maxRetries - retriesRemaining
          });
          const requestLogID = "log_" + (Math.random() * (1 << 24) | 0).toString(16).padStart(6, "0");
          const retryLogStr = retryOfRequestLogID === void 0 ? "" : `, retryOf: ${retryOfRequestLogID}`;
          const startTime = Date.now();
          if (options.signal?.aborted) {
            throw new Errors.APIUserAbortError();
          }
          const controller = new AbortController();
          const response = await this.fetchWithTimeout(url, req, timeout, controller, options, {
            requestLogID,
            retryOfRequestLogID
          }).catch(errors_1.castToError);
          const headersTime = Date.now();
          if (response instanceof globalThis.Error) {
            (0, request_signal_1.releaseRequestSignal)(controller);
            const retryMessage = `retrying, ${retriesRemaining} attempts remaining`;
            if (options.signal?.aborted) {
              throw new Errors.APIUserAbortError();
            }
            const isTimeout = (0, errors_1.isAbortError)(response) || /timed? ?out/i.test(String(response) + ("cause" in response ? String(response.cause) : ""));
            const hasMiddleware = this.middleware.length > 0 || !!options.middleware?.length || this.backendMiddleware().length > 0;
            if (hasMiddleware && !isTimeout && !(0, middleware_1.isRetryableError)(response)) {
              (0, log_1.loggerFor)(this).info(`[${requestLogID}] middleware error (not retryable)`);
              (0, log_1.debugLogRequestDetails)((0, log_1.loggerFor)(this), `[${requestLogID}] middleware error (not retryable)`, {
                retryOfRequestLogID,
                url,
                durationMs: headersTime - startTime,
                message: response.message
              });
              throw response;
            }
            if (retriesRemaining) {
              (0, log_1.loggerFor)(this).info(`[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} - ${retryMessage}`);
              (0, log_1.debugLogRequestDetails)((0, log_1.loggerFor)(this), `[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} (${retryMessage})`, {
                retryOfRequestLogID,
                url,
                durationMs: headersTime - startTime,
                message: response.message
              });
              return this.retryRequest(options, retriesRemaining, retryOfRequestLogID ?? requestLogID);
            }
            (0, log_1.loggerFor)(this).info(`[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} - error; no more retries left`);
            (0, log_1.debugLogRequestDetails)((0, log_1.loggerFor)(this), `[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} (error; no more retries left)`, {
              retryOfRequestLogID,
              url,
              durationMs: headersTime - startTime,
              message: response.message
            });
            if (isTimeout) {
              throw new Errors.APIConnectionTimeoutError();
            }
            if (hasMiddleware && !(0, middleware_1.isFetchOriginError)(response)) {
              throw response;
            }
            throw new Errors.APIConnectionError({ cause: response });
          }
          const specialHeaders = [...response.headers.entries()].filter(([name]) => name === "request-id" || name === "anthropic-workspace-id").map(([name, value]) => ", " + name + ": " + JSON.stringify(value)).join("");
          const responseInfo = `[${requestLogID}${retryLogStr}${specialHeaders}] ${req.method} ${url} ${response.ok ? "succeeded" : "failed"} with status ${response.status} in ${headersTime - startTime}ms`;
          if (!response.ok) {
            const shouldRetry = await this.shouldRetry(response, options);
            if (retriesRemaining && shouldRetry) {
              const retryMessage2 = `retrying, ${retriesRemaining} attempts remaining`;
              await Shims.CancelReadableStream(response.body);
              (0, request_signal_1.releaseRequestSignal)(controller);
              (0, log_1.loggerFor)(this).info(`${responseInfo} - ${retryMessage2}`);
              (0, log_1.debugLogRequestDetails)((0, log_1.loggerFor)(this), `[${requestLogID}] response error (${retryMessage2})`, {
                retryOfRequestLogID,
                url: response.url,
                status: response.status,
                headers: response.headers,
                durationMs: headersTime - startTime
              });
              return this.retryRequest(options, retriesRemaining, retryOfRequestLogID ?? requestLogID, response.headers);
            }
            const retryMessage = shouldRetry ? `error; no more retries left` : `error; not retryable`;
            (0, log_1.loggerFor)(this).info(`${responseInfo} - ${retryMessage}`);
            const errText = await response.text().catch((err2) => (0, errors_1.castToError)(err2).message);
            const errJSON = (0, values_1.safeJSON)(errText);
            const errMessage = errJSON ? void 0 : errText;
            (0, log_1.debugLogRequestDetails)((0, log_1.loggerFor)(this), `[${requestLogID}] response error (${retryMessage})`, {
              retryOfRequestLogID,
              url: response.url,
              status: response.status,
              headers: response.headers,
              message: errMessage,
              durationMs: Date.now() - startTime
            });
            (0, request_signal_1.releaseRequestSignal)(controller);
            const err = this.makeStatusError(response.status, errJSON, errMessage, response.headers);
            throw err;
          }
          (0, log_1.loggerFor)(this).info(responseInfo);
          (0, log_1.debugLogRequestDetails)((0, log_1.loggerFor)(this), `[${requestLogID}] response start`, {
            retryOfRequestLogID,
            url: response.url,
            status: response.status,
            headers: response.headers,
            durationMs: headersTime - startTime
          });
          (0, request_signal_1.armAbandonmentBackstop)(response.body ?? response, controller);
          return { response, options, controller, requestLogID, retryOfRequestLogID, startTime };
        }
        getAPIList(path2, Page, opts) {
          return this.requestAPIList(Page, opts && "then" in opts ? opts.then((opts2) => ({ method: "get", path: path2, ...opts2 })) : { method: "get", path: path2, ...opts });
        }
        requestAPIList(Page, options) {
          const request = this.makeRequest(options, null, void 0);
          return new Pagination.PagePromise(this, request, Page);
        }
        async fetchWithTimeout(url, init, ms, controller, requestOptions, logCtx) {
          const { signal, method, ...options } = init || {};
          const abort = this._makeAbort(controller);
          if (signal) {
            signal.addEventListener("abort", abort, { once: true });
            (0, request_signal_1.registerRequestSignalCleanup)(controller, signal, abort);
          }
          const isReadableBody = globalThis.ReadableStream && options.body instanceof globalThis.ReadableStream || typeof options.body === "object" && options.body !== null && Symbol.asyncIterator in options.body;
          const fetchOptions = {
            signal: controller.signal,
            ...isReadableBody ? { duplex: "half" } : {},
            method: "GET",
            ...options
          };
          if (method) {
            fetchOptions.method = method.toUpperCase();
          }
          const baseFetch = this.fetch;
          const timedFetch = async (innerUrl, innerInit) => {
            const timeout = setTimeout(abort, ms);
            try {
              return await baseFetch.call(void 0, innerUrl, innerInit);
            } finally {
              clearTimeout(timeout);
            }
          };
          const innerFetch = requestOptions === void 0 ? timedFetch : (async (innerUrl, innerInit = {}) => {
            const innerUrlStr = typeof innerUrl === "string" ? innerUrl : innerUrl instanceof URL ? innerUrl.href : innerUrl.url;
            innerInit.headers = innerInit.headers instanceof Headers ? innerInit.headers : new Headers(innerInit.headers);
            await this.prepareRequest(innerInit, { url: innerUrlStr, options: requestOptions });
            if (logCtx) {
              (0, log_1.debugLogRequestDetails)((0, log_1.loggerFor)(this), `[${logCtx.requestLogID}] sending request`, {
                retryOfRequestLogID: logCtx.retryOfRequestLogID,
                method: innerInit.method,
                url: innerUrlStr,
                options: requestOptions,
                headers: innerInit.headers
              });
            }
            return timedFetch(innerUrl, innerInit);
          });
          const requestMiddleware = requestOptions?.middleware;
          const backendMiddleware = this.backendMiddleware();
          const allMiddleware = requestMiddleware?.length || backendMiddleware.length ? [...this.middleware, ...requestMiddleware ?? [], ...backendMiddleware] : this.middleware;
          return await (0, middleware_1.wrapFetchWithMiddleware)(innerFetch, allMiddleware, requestOptions, this)(url, fetchOptions);
        }
        async shouldRetry(response, options) {
          const flags = this._authFlags(options);
          if (response.status === 401 && this._authState.tokenCache && flags.usedTokenCache && !flags.didRefreshFor401) {
            flags.didRefreshFor401 = true;
            this._authState.tokenCache.invalidate();
            return true;
          }
          const shouldRetryHeader = response.headers.get("x-should-retry");
          if (shouldRetryHeader === "true")
            return true;
          if (shouldRetryHeader === "false")
            return false;
          if (response.status === 408)
            return true;
          if (response.status === 409)
            return true;
          if (response.status === 429)
            return true;
          if (response.status >= 500)
            return true;
          return false;
        }
        async retryRequest(options, retriesRemaining, requestLogID, responseHeaders) {
          let timeoutMillis;
          const retryAfterMillisHeader = responseHeaders?.get("retry-after-ms");
          if (retryAfterMillisHeader) {
            const timeoutMs = parseFloat(retryAfterMillisHeader);
            if (!Number.isNaN(timeoutMs)) {
              timeoutMillis = timeoutMs;
            }
          }
          const retryAfterHeader = responseHeaders?.get("retry-after");
          if (retryAfterHeader && !timeoutMillis) {
            const timeoutSeconds = parseFloat(retryAfterHeader);
            if (!Number.isNaN(timeoutSeconds)) {
              timeoutMillis = timeoutSeconds * 1e3;
            } else {
              timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
            }
          }
          if (timeoutMillis === void 0 || !(timeoutMillis > 0 && timeoutMillis <= 2 ** 31 - 1)) {
            const maxRetries = options.maxRetries ?? this.maxRetries;
            timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
          }
          await (0, sleep_1.sleep)(timeoutMillis, options.signal ?? void 0);
          return this.makeRequest(options, retriesRemaining - 1, requestLogID);
        }
        calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries) {
          const initialRetryDelay = 0.5;
          const maxRetryDelay = 8;
          const numRetries = maxRetries - retriesRemaining;
          const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);
          const jitter = 1 - Math.random() * 0.25;
          return sleepSeconds * jitter * 1e3;
        }
        calculateNonstreamingTimeout(maxTokens, maxNonstreamingTokens) {
          const maxTime = 60 * 60 * 1e3;
          const defaultTime = 60 * 10 * 1e3;
          const expectedTime = maxTime * maxTokens / 128e3;
          if (expectedTime > defaultTime || maxNonstreamingTokens != null && maxTokens > maxNonstreamingTokens) {
            throw new Errors.AnthropicError("Streaming is required for operations that may take longer than 10 minutes. See https://github.com/anthropics/anthropic-sdk-typescript#long-requests for more details");
          }
          return defaultTime;
        }
        async buildRequest(inputOptions, { retryCount = 0 } = {}) {
          const options = { ...inputOptions };
          const { method, path: path2, query, defaultBaseURL } = options;
          if (this._authState.resolution) {
            await this._authState.resolution;
          }
          if (!this._baseURLIsExplicit && this._authState.baseURL && this.baseURL !== this._authState.baseURL) {
            this.baseURL = this._authState.baseURL;
          }
          const url = this.buildURL(path2, query, defaultBaseURL);
          if ("timeout" in options)
            (0, values_1.validatePositiveInteger)("timeout", options.timeout);
          options.timeout = options.timeout ?? this.timeout;
          const { bodyHeaders, body } = this.buildBody({ options });
          const reqHeaders = await this.buildHeaders({ options: inputOptions, method, bodyHeaders, retryCount });
          const req = {
            method,
            headers: reqHeaders,
            ...options.signal && { signal: options.signal },
            ...globalThis.ReadableStream && body instanceof globalThis.ReadableStream && { duplex: "half" },
            ...body && { body },
            ...this.fetchOptions ?? {},
            ...options.fetchOptions ?? {}
          };
          return { req, url, timeout: options.timeout };
        }
        async buildHeaders({ options, method, bodyHeaders, retryCount }) {
          const headers = (0, headers_1.buildHeaders)([
            {
              Accept: "application/json",
              "User-Agent": this.getUserAgent(),
              "X-Stainless-Retry-Count": String(retryCount),
              ...options.timeout ? { "X-Stainless-Timeout": String(Math.trunc(options.timeout / 1e3)) } : {},
              ...(0, detect_platform_1.getPlatformHeaders)(),
              ...this._options.dangerouslyAllowBrowser ? { "anthropic-dangerous-direct-browser-access": "true" } : void 0,
              "anthropic-version": "2023-06-01"
            },
            await this.authHeaders(options),
            this._options.defaultHeaders,
            bodyHeaders,
            options.headers
          ]);
          this.validateHeaders(headers);
          return headers.values;
        }
        _makeAbort(controller) {
          return () => controller.abort();
        }
        buildBody({ options: { body, headers: rawHeaders } }) {
          if (!body) {
            return { bodyHeaders: void 0, body: void 0 };
          }
          const headers = (0, headers_1.buildHeaders)([rawHeaders]);
          if (
            // Pass raw type verbatim
            ArrayBuffer.isView(body) || body instanceof ArrayBuffer || body instanceof DataView || typeof body === "string" && // Preserve legacy string encoding behavior for now
            headers.values.has("content-type") || // `Blob` is superset of `File`
            globalThis.Blob && body instanceof globalThis.Blob || // `FormData` -> `multipart/form-data`
            body instanceof FormData || // `URLSearchParams` -> `application/x-www-form-urlencoded`
            body instanceof URLSearchParams || // Send chunked stream (each chunk has own `length`)
            globalThis.ReadableStream && body instanceof globalThis.ReadableStream
          ) {
            return { bodyHeaders: void 0, body };
          } else if (this.isStreamBody(body)) {
            return { bodyHeaders: void 0, body: Shims.ReadableStreamFrom(body) };
          } else if (typeof body === "object" && headers.values.get("content-type") === "application/x-www-form-urlencoded") {
            return {
              bodyHeaders: { "content-type": "application/x-www-form-urlencoded" },
              body: this.stringifyQuery(body)
            };
          } else {
            return tslib_1.__classPrivateFieldGet(this, _BaseAnthropic_encoder, "f").call(this, { body, headers });
          }
        }
        /**
         * Whether `body` is sent as a stream, which can be read only once:
         * a `ReadableStream`, an async iterable or an iterator.
         */
        isStreamBody(body) {
          if (globalThis.ReadableStream && body instanceof globalThis.ReadableStream) {
            return true;
          }
          return typeof body === "object" && body !== null && (Symbol.asyncIterator in body || Symbol.iterator in body && "next" in body && typeof body.next === "function");
        }
      }
      _a = BaseAnthropic2, _BaseAnthropic_encoder = /* @__PURE__ */ new WeakMap(), _BaseAnthropic_instances = /* @__PURE__ */ new WeakSet(), _BaseAnthropic_baseURLOverridden = function _BaseAnthropic_baseURLOverridden2() {
        return this.baseURL !== "https://api.anthropic.com";
      };
      BaseAnthropic2.Anthropic = _a;
      BaseAnthropic2.HUMAN_PROMPT = exports2.HUMAN_PROMPT;
      BaseAnthropic2.AI_PROMPT = exports2.AI_PROMPT;
      BaseAnthropic2.DEFAULT_TIMEOUT = 6e5;
      BaseAnthropic2.AnthropicError = Errors.AnthropicError;
      BaseAnthropic2.APIError = Errors.APIError;
      BaseAnthropic2.APIConnectionError = Errors.APIConnectionError;
      BaseAnthropic2.APIConnectionTimeoutError = Errors.APIConnectionTimeoutError;
      BaseAnthropic2.APIUserAbortError = Errors.APIUserAbortError;
      BaseAnthropic2.NotFoundError = Errors.NotFoundError;
      BaseAnthropic2.ConflictError = Errors.ConflictError;
      BaseAnthropic2.RateLimitError = Errors.RateLimitError;
      BaseAnthropic2.BadRequestError = Errors.BadRequestError;
      BaseAnthropic2.AuthenticationError = Errors.AuthenticationError;
      BaseAnthropic2.InternalServerError = Errors.InternalServerError;
      BaseAnthropic2.PermissionDeniedError = Errors.PermissionDeniedError;
      BaseAnthropic2.UnprocessableEntityError = Errors.UnprocessableEntityError;
      BaseAnthropic2.toFile = Uploads.toFile;
      return BaseAnthropic2;
    })();
    exports2.BaseAnthropic = BaseAnthropic;
    var Anthropic = /* @__PURE__ */ (() => {
      class Anthropic2 extends BaseAnthropic {
        constructor() {
          super(...arguments);
          this.completions = new API.Completions(this);
          this.messages = new API.Messages(this);
          this.models = new API.Models(this);
          this.files = new API.Files(this);
          this.skills = new API.Skills(this);
          this.beta = new API.Beta(this);
        }
      }
      Anthropic2.Completions = completions_1.Completions;
      Anthropic2.Messages = messages_1.Messages;
      Anthropic2.Models = models_1.Models;
      Anthropic2.Files = files_1.Files;
      Anthropic2.Skills = skills_1.Skills;
      Anthropic2.Beta = beta_1.Beta;
      return Anthropic2;
    })();
    exports2.Anthropic = Anthropic;
  }
});

// node_modules/@anthropic-ai/sdk/lib/middleware.js
var require_middleware2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/middleware.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BetaFallbackState = void 0;
    exports2.betaRefusalFallbackMiddleware = betaRefusalFallbackMiddleware;
    var error_1 = require_error();
    var streaming_1 = require_streaming();
    var errors_1 = require_errors();
    var headers_1 = require_headers();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var values_1 = require_values();
    var request_options_1 = require_request_options();
    Object.defineProperty(exports2, "BetaFallbackState", { enumerable: true, get: function() {
      return request_options_1.BetaFallbackState;
    } });
    var encoder = new TextEncoder();
    var DEFAULT_BETAS = ["fallback-credit-2026-07-01"];
    function stripFallbackBlocks(body) {
      const messages = body.messages.flatMap((message) => {
        if (!Array.isArray(message.content))
          return [message];
        const content = message.content.filter((block) => block.type !== "fallback");
        if (content.length === message.content.length)
          return [message];
        return content.length > 0 ? [{ ...message, content }] : [];
      });
      return { ...body, messages };
    }
    function applyFallbackPatch(body, entry) {
      const patched = { ...body };
      for (const [key, value] of Object.entries(entry)) {
        if (key === "output_config" && value != null) {
          const merged = { ...patched[key] ?? {} };
          for (const [subKey, subValue] of Object.entries(value)) {
            patchField(merged, subKey, subValue);
          }
          patchField(patched, key, Object.keys(merged).length ? merged : null);
        } else {
          patchField(patched, key, value);
        }
      }
      return patched;
    }
    function patchField(target, key, value) {
      if (value === void 0)
        return;
      if (value === null) {
        delete target[key];
      } else {
        target[key] = value;
      }
    }
    function betaRefusalFallbackMiddleware(fallbacks, options = {}) {
      let warnedMissingState = false;
      return async (request, next, ctx) => {
        const [path2, query] = (ctx.options?.path ?? "").split("?");
        if (fallbacks.length === 0 || ctx.options?.method !== "post" || path2 !== "/v1/messages" || new URLSearchParams(query).get("beta") !== "true" || typeof ctx.options.body !== "object" || ctx.options.body == null) {
          return next(request);
        }
        if (ctx.options.body.fallbacks != null) {
          throw new error_1.AnthropicError("Sending the `fallbacks:` request param is not supported when using the `betaRefusalFallbackMiddleware`. You should either remove the middleware and send `fallbacks:` with the `server-side-fallback-2026-07-01` beta header to let the API handle refusal fallbacks, or omit the `fallbacks:` param if you'd like `betaRefusalFallbackMiddleware` to handle fallbacks on the client side.");
        }
        const onError = options.onError ?? ((error) => ctx.logger.error(`anthropic-sdk: betaRefusalFallbackMiddleware: ${error.message}`));
        request = withMiddlewareHeaders(request, options.betas ?? DEFAULT_BETAS);
        const body = stripFallbackBlocks(ctx.options.body);
        const state = ctx.options.fallbackState;
        const startIndex = state?.index ?? -1;
        if (!Number.isInteger(startIndex) || startIndex < -1 || startIndex >= fallbacks.length) {
          throw new error_1.AnthropicError(`fallbackState.index ${startIndex} is out of bounds for a chain of ${fallbacks.length} fallback(s); was the state shared with a different middleware?`);
        }
        const pin = (index2) => {
          if (state) {
            state.index = index2;
          } else if (!warnedMissingState) {
            warnedMissingState = true;
            ctx.logger.warn("anthropic-sdk: betaRefusalFallbackMiddleware fell back without a `fallbackState` request option; follow-up requests will retry models that already refused. Pass a shared `{ fallbackState: new BetaFallbackState() }` to pin them to the accepted model.");
          }
        };
        const initialBody = startIndex === -1 ? body : applyFallbackPatch(body, fallbacks[startIndex]);
        const initialRequest = typeof request.body !== "string" ? request : { ...request, body: JSON.stringify(initialBody) };
        const response = await next(initialRequest);
        if (!response.ok) {
          return response;
        }
        if (ctx.options.stream === true) {
          const firstHop = startIndex + 1;
          if (firstHop >= fallbacks.length || typeof initialRequest.body !== "string") {
            return response;
          }
          return spliceFallbackStream({
            request: initialRequest,
            response,
            next,
            ctx,
            fallbacks,
            firstHop,
            onError,
            pin
          });
        }
        let index = startIndex;
        let res = response;
        let requestedModel = initialBody.model;
        const fallbackBlocks = [];
        while (index < fallbacks.length - 1) {
          const message = await ctx.parse(res);
          if (message?.type !== "message" || message.stop_reason !== "refusal") {
            break;
          }
          index += 1;
          pin(index);
          const entry = fallbacks[index];
          fallbackBlocks.push({
            type: "fallback",
            // `requestedModel` is always set for a typed body; the `??` defends
            // against an untyped body that carried no `model` field.
            from: { model: requestedModel ?? message.model },
            to: { model: entry.model },
            trigger: { type: "refusal", category: message.stop_details?.category ?? null }
          });
          requestedModel = entry.model;
          res = await next({
            ...request,
            body: JSON.stringify({
              ...applyFallbackPatch(body, entry),
              ...message.stop_details?.fallback_credit_token ? { fallback_credit_token: creditTokenParam(message.stop_details.fallback_credit_token) } : void 0
            })
          });
        }
        if (fallbackBlocks.length === 0) {
          return res;
        }
        const served = await ctx.parse(res);
        if (served?.type !== "message" || served.stop_reason === "refusal" || !Array.isArray(served.content)) {
          return res;
        }
        const headers = new Headers(res.headers);
        headers.delete("content-length");
        return new Response(JSON.stringify({ ...served, content: [...fallbackBlocks, ...served.content] }), {
          status: res.status,
          statusText: res.statusText,
          headers
        });
      };
    }
    function spliceFallbackStream(args) {
      const controller = new AbortController();
      const signal = args.request.signal;
      if (signal?.aborted) {
        controller.abort(signal.reason);
      } else {
        signal?.addEventListener("abort", makeAbort(controller, signal), { once: true });
      }
      const iter = splicedEvents(args, controller);
      const body = new ReadableStream({
        async pull(ctrl) {
          try {
            const { value, done } = await iter.next();
            if (done)
              return ctrl.close();
            ctrl.enqueue(value);
          } catch (err) {
            ctrl.error(err);
          }
        },
        async cancel() {
          controller.abort();
          await iter.return?.(void 0);
        }
      });
      return new Response(body, args.response);
    }
    async function* splicedEvents({ request, response, next, ctx, fallbacks, firstHop, onError, pin }, controller) {
      const a = yield* consumeHop({
        response,
        controller,
        indexBase: 0,
        hasNext: true,
        // the caller guarantees firstHop < fallbacks.length
        onError,
        splice: null
      });
      if (!a.refused)
        return;
      let nextIndex = a.nextIndex;
      let token = a.refused.token;
      let base = [];
      let partial = a.refused.hasPrefillClaim ? toPrefillBlocks(a.blocks) : [];
      let fromModel = a.model ?? "";
      let lastUsage = a.refused.usage;
      let refusalDetails = a.refused.stopDetails;
      let refusalInputTransformations = a.refused.inputTransformations;
      const iterations = [
        toIterationUsage("message", a.model ?? "", a.refused.usage)
      ];
      for (let hop = firstHop; hop < fallbacks.length; hop++) {
        const model = fallbacks[hop].model;
        const hasNext = hop + 1 < fallbacks.length;
        pin(hop);
        const fbIndex = nextIndex++;
        yield emit("content_block_start", {
          type: "content_block_start",
          index: fbIndex,
          content_block: {
            type: "fallback",
            from: { model: fromModel },
            to: { model },
            trigger: { type: "refusal", category: refusalDetails?.category ?? null }
          }
        });
        yield emit("content_block_stop", {
          type: "content_block_stop",
          index: fbIndex
        });
        let continuation = [...base, ...partial];
        let resB = null;
        let failure = null;
        for (let attempt = 0; attempt < 2; attempt++) {
          const reqB = buildFallbackRequest(request, { model, creditToken: token, continuation });
          reqB.signal = controller.signal;
          try {
            resB = await next(reqB);
          } catch (err) {
            if ((0, errors_1.isAbortError)(err))
              throw err;
            failure = {
              kind: "request_failed",
              message: `fallback request failed: ${err}`,
              model,
              status: null,
              detail: err
            };
            break;
          }
          if (resB.ok)
            break;
          const errBody = await ctx.parse(resB).catch(() => null);
          if (attempt === 0 && resB.status === 400 && partial.length) {
            ctx.logger.warn(`anthropic-sdk: betaRefusalFallbackMiddleware: fallback request with the partial output appended was rejected (HTTP 400: ${JSON.stringify(errBody)}); retrying without it`);
            continuation = base;
            resB = null;
            continue;
          }
          failure = {
            kind: "request_failed",
            message: `fallback request failed: HTTP ${resB.status}: ${JSON.stringify(errBody)}`,
            model,
            status: resB.status,
            detail: errBody
          };
          break;
        }
        if (failure) {
          onError(failure);
          if (hasNext)
            continue;
          const stopDetails = {
            ...refusalDetails,
            recommended_model: model
          };
          yield emit("message_delta", {
            type: "message_delta",
            context_management: null,
            delta: {
              stop_reason: "refusal",
              stop_sequence: null,
              container: null,
              stop_details: stopDetails
            },
            usage: lastUsage ?? {},
            ...refusalInputTransformations !== void 0 && {
              input_transformations: refusalInputTransformations
            }
          });
          yield emit("message_stop", { type: "message_stop" });
          return;
        }
        const b = yield* consumeHop({
          response: resB,
          controller,
          indexBase: nextIndex,
          hasNext,
          onError,
          splice: { iterations, model }
        });
        if (!b.refused)
          return;
        token = b.refused.token;
        refusalDetails = b.refused.stopDetails;
        refusalInputTransformations = b.refused.inputTransformations;
        base = continuation;
        partial = b.refused.hasPrefillClaim ? toPrefillBlocks(b.blocks) : [];
        iterations.push(toIterationUsage("message", model, b.refused.usage));
        lastUsage = b.refused.usage;
        fromModel = model;
        nextIndex = b.nextIndex;
      }
    }
    async function* consumeHop(args) {
      const { response, controller, indexBase, hasNext, onError, splice } = args;
      const tracker = new BlockTracker(indexBase);
      let model;
      let startUsage = null;
      let startInputTransformations;
      for await (const sse of streaming_1.Stream.rawEvents(response, controller)) {
        const p = (0, values_1.safeJSON)(sse.data);
        switch (p?.type) {
          case "message_start": {
            model = p.message.model;
            startUsage = p.message.usage;
            if ("input_transformations" in p.message)
              startInputTransformations = p.message.input_transformations;
            if (splice)
              continue;
            break;
          }
          case "content_block_start": {
            tracker.start(p);
            if (splice) {
              yield emit(p.type, p);
              continue;
            }
            break;
          }
          case "content_block_delta": {
            tracker.delta(p);
            if (splice) {
              yield emit(p.type, p);
              continue;
            }
            break;
          }
          case "content_block_stop": {
            tracker.stop(p);
            if (splice) {
              yield emit(p.type, p);
              continue;
            }
            break;
          }
          case "message_delta": {
            if (p.delta.stop_reason === "refusal") {
              const details = p.delta.stop_details?.type === "refusal" ? p.delta.stop_details : null;
              if (details?.fallback_credit_token && hasNext) {
                const usage = backfill(p.usage, startUsage);
                yield* tracker.closeOpenBlocks();
                return {
                  refused: {
                    token: details.fallback_credit_token,
                    hasPrefillClaim: details.fallback_has_prefill_claim === true,
                    usage,
                    stopDetails: details,
                    inputTransformations: splice ? startInputTransformations : void 0
                  },
                  model,
                  blocks: tracker.contentBlocks(),
                  nextIndex: tracker.nextIndex
                };
              }
              if (!details?.fallback_credit_token) {
                onError({
                  kind: "no_credit_token",
                  message: "refusal stop_details has no fallback_credit_token",
                  event: p
                });
              } else {
                onError({
                  kind: "chain_exhausted",
                  message: "refusal but no fallback entries remain",
                  event: p
                });
              }
            }
            if (splice) {
              const usage = backfill(p.usage, startUsage);
              usage.iterations = [
                ...splice.iterations,
                toIterationUsage("fallback_message", splice.model, usage)
              ];
              p.usage = usage;
              if (!("input_transformations" in p) && startInputTransformations !== void 0) {
                p.input_transformations = startInputTransformations;
              }
              yield emit("message_delta", p);
              continue;
            }
            break;
          }
        }
        yield passthroughSSE(sse);
      }
      return { refused: null, model, blocks: tracker.contentBlocks(), nextIndex: tracker.nextIndex };
    }
    var BlockTracker = class {
      constructor(indexBase = 0) {
        this.indexBase = indexBase;
        this.blocks = [];
        this.open = [];
        this.nextIndex = indexBase;
      }
      /** The accumulated content blocks, in start order. */
      contentBlocks() {
        return this.blocks.map((b) => b.block);
      }
      /** Track a content_block_start, shifting `event.index`. */
      start(event) {
        this.blocks.push({ index: event.index, block: { ...event.content_block } });
        event.index += this.indexBase;
        this.open.push(event.index);
        this.nextIndex = Math.max(this.nextIndex, event.index + 1);
      }
      /** Apply a content_block_delta to its accumulating block, shifting `event.index`. */
      delta(event) {
        applyDelta(this.blocks, event.index, event.delta);
        event.index += this.indexBase;
      }
      /** Track a content_block_stop, shifting `event.index`. */
      stop(event) {
        event.index += this.indexBase;
        const i = this.open.indexOf(event.index);
        if (i !== -1)
          this.open.splice(i, 1);
        this.nextIndex = Math.max(this.nextIndex, event.index + 1);
      }
      /** content_block_stop events for any blocks still open. */
      *closeOpenBlocks() {
        for (const index of this.open) {
          yield emit("content_block_stop", {
            type: "content_block_stop",
            index
          });
        }
        this.open.length = 0;
      }
    };
    function creditTokenParam(token) {
      return { token, mode: "best_effort" };
    }
    function buildFallbackRequest(orig, { model, creditToken, continuation }) {
      const body = JSON.parse(orig.body);
      body.model = model;
      body.fallback_credit_token = creditTokenParam(creditToken);
      if (continuation.length) {
        body.messages = [...body.messages, { role: "assistant", content: continuation }];
      }
      return { ...orig, headers: new Headers(orig.headers), body: JSON.stringify(body) };
    }
    function applyDelta(blocks, index, delta) {
      const block = blocks.find((x) => x.index === index)?.block;
      if (!block)
        return;
      switch (delta.type) {
        case "text_delta": {
          block.text = (block.text ?? "") + delta.text;
          break;
        }
        case "input_json_delta": {
          block._partial_json = (block._partial_json ?? "") + delta.partial_json;
          break;
        }
        case "citations_delta":
          (block.citations ?? (block.citations = [])).push(delta.citation);
          break;
        case "thinking_delta": {
          block.thinking = (block.thinking ?? "") + delta.thinking;
          break;
        }
        case "signature_delta": {
          block.signature = delta.signature;
          break;
        }
        case "compaction_delta": {
          block.content = delta.content;
          if ("encrypted_content" in delta) {
            block.encrypted_content = delta.encrypted_content;
          }
          break;
        }
        default:
          /* @__PURE__ */ ((_) => {
          })(delta);
      }
    }
    function toPrefillBlocks(responseBlocks) {
      return responseBlocks.map((b) => {
        if (typeof b?._partial_json !== "string")
          return b;
        const { _partial_json, ...block } = b;
        return { ...block, input: (0, values_1.safeJSON)(_partial_json) ?? block.input };
      });
    }
    function withMiddlewareHeaders(request, betas) {
      const headers = new Headers(request.headers);
      const existing = new Set(headers.get("anthropic-beta")?.split(",").map((s) => s.trim()));
      for (const beta of betas) {
        if (!existing.has(beta)) {
          existing.add(beta);
          headers.set("anthropic-beta", [...existing].join(","));
        }
      }
      headers.set(stainless_helper_header_1.STAINLESS_HELPER_HEADER, (0, headers_1.appendHeaderValue)(headers.get(stainless_helper_header_1.STAINLESS_HELPER_HEADER), "fallback-refusal-middleware"));
      return { ...request, headers };
    }
    function emit(event, payload) {
      const sse = { event, data: JSON.stringify(payload), raw: [] };
      return encoder.encode(serializeSSE(sse));
    }
    function passthroughSSE(sse) {
      return encoder.encode(sse.raw.length ? sse.raw.join("\n") + "\n\n" : serializeSSE(sse));
    }
    function toIterationUsage(type, model, u) {
      return {
        type,
        model,
        input_tokens: u?.input_tokens ?? 0,
        output_tokens: u?.output_tokens ?? 0,
        cache_read_input_tokens: u?.cache_read_input_tokens ?? 0,
        cache_creation_input_tokens: u?.cache_creation_input_tokens ?? 0,
        cache_creation: u?.cache_creation ?? null
      };
    }
    function backfill(primary, fallback) {
      const out = { ...fallback ?? {}, ...primary ?? {} };
      for (const k of Object.keys(out)) {
        if (out[k] == null && fallback?.[k] != null)
          out[k] = fallback[k];
      }
      return out;
    }
    function serializeSSE(sse) {
      let out = "";
      if (sse.event !== null)
        out += `event: ${sse.event}
`;
      for (const line of sse.data.split("\n"))
        out += `data: ${line}
`;
      return out + "\n";
    }
    function makeAbort(controller, signal) {
      return () => controller.abort(signal.reason);
    }
  }
});

// node_modules/@anthropic-ai/sdk/index.js
var require_sdk = __commonJS({
  "node_modules/@anthropic-ai/sdk/index.js"(exports2, module2) {
    "use strict";
    exports2 = module2.exports = function(...args) {
      return new exports2.default(...args);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.UnprocessableEntityError = exports2.PermissionDeniedError = exports2.InternalServerError = exports2.AuthenticationError = exports2.BadRequestError = exports2.RateLimitError = exports2.ConflictError = exports2.NotFoundError = exports2.RetryableError = exports2.APIUserAbortError = exports2.APIConnectionTimeoutError = exports2.APIConnectionError = exports2.APIError = exports2.AnthropicError = exports2.PagePromise = exports2.AI_PROMPT = exports2.HUMAN_PROMPT = exports2.Anthropic = exports2.BaseAnthropic = exports2.BetaFallbackState = exports2.betaRefusalFallbackMiddleware = exports2.APIPromise = exports2.toFile = exports2.default = void 0;
    var client_1 = require_client();
    Object.defineProperty(exports2, "default", { enumerable: true, get: function() {
      return client_1.Anthropic;
    } });
    var uploads_1 = require_uploads2();
    Object.defineProperty(exports2, "toFile", { enumerable: true, get: function() {
      return uploads_1.toFile;
    } });
    var api_promise_1 = require_api_promise();
    Object.defineProperty(exports2, "APIPromise", { enumerable: true, get: function() {
      return api_promise_1.APIPromise;
    } });
    var middleware_1 = require_middleware2();
    Object.defineProperty(exports2, "betaRefusalFallbackMiddleware", { enumerable: true, get: function() {
      return middleware_1.betaRefusalFallbackMiddleware;
    } });
    Object.defineProperty(exports2, "BetaFallbackState", { enumerable: true, get: function() {
      return middleware_1.BetaFallbackState;
    } });
    var client_2 = require_client();
    Object.defineProperty(exports2, "BaseAnthropic", { enumerable: true, get: function() {
      return client_2.BaseAnthropic;
    } });
    Object.defineProperty(exports2, "Anthropic", { enumerable: true, get: function() {
      return client_2.Anthropic;
    } });
    Object.defineProperty(exports2, "HUMAN_PROMPT", { enumerable: true, get: function() {
      return client_2.HUMAN_PROMPT;
    } });
    Object.defineProperty(exports2, "AI_PROMPT", { enumerable: true, get: function() {
      return client_2.AI_PROMPT;
    } });
    var pagination_1 = require_pagination();
    Object.defineProperty(exports2, "PagePromise", { enumerable: true, get: function() {
      return pagination_1.PagePromise;
    } });
    var error_1 = require_error();
    Object.defineProperty(exports2, "AnthropicError", { enumerable: true, get: function() {
      return error_1.AnthropicError;
    } });
    Object.defineProperty(exports2, "APIError", { enumerable: true, get: function() {
      return error_1.APIError;
    } });
    Object.defineProperty(exports2, "APIConnectionError", { enumerable: true, get: function() {
      return error_1.APIConnectionError;
    } });
    Object.defineProperty(exports2, "APIConnectionTimeoutError", { enumerable: true, get: function() {
      return error_1.APIConnectionTimeoutError;
    } });
    Object.defineProperty(exports2, "APIUserAbortError", { enumerable: true, get: function() {
      return error_1.APIUserAbortError;
    } });
    Object.defineProperty(exports2, "RetryableError", { enumerable: true, get: function() {
      return error_1.RetryableError;
    } });
    Object.defineProperty(exports2, "NotFoundError", { enumerable: true, get: function() {
      return error_1.NotFoundError;
    } });
    Object.defineProperty(exports2, "ConflictError", { enumerable: true, get: function() {
      return error_1.ConflictError;
    } });
    Object.defineProperty(exports2, "RateLimitError", { enumerable: true, get: function() {
      return error_1.RateLimitError;
    } });
    Object.defineProperty(exports2, "BadRequestError", { enumerable: true, get: function() {
      return error_1.BadRequestError;
    } });
    Object.defineProperty(exports2, "AuthenticationError", { enumerable: true, get: function() {
      return error_1.AuthenticationError;
    } });
    Object.defineProperty(exports2, "InternalServerError", { enumerable: true, get: function() {
      return error_1.InternalServerError;
    } });
    Object.defineProperty(exports2, "PermissionDeniedError", { enumerable: true, get: function() {
      return error_1.PermissionDeniedError;
    } });
    Object.defineProperty(exports2, "UnprocessableEntityError", { enumerable: true, get: function() {
      return error_1.UnprocessableEntityError;
    } });
  }
});

// lib/ai.js
var require_ai = __commonJS({
  "lib/ai.js"(exports2, module2) {
    var AnthropicSdk = null;
    function sdk() {
      if (!AnthropicSdk) {
        try {
          const m = require_sdk();
          AnthropicSdk = m.default || m;
        } catch {
          throw Object.assign(new Error('SDK Claude non installato: esegui "npm install" nella cartella verbale-studio.'), { status: 500 });
        }
      }
      return AnthropicSdk;
    }
    var DEFAULT_MODEL = "claude-opus-5";
    function getClient(settings) {
      const apiKey = settings.apiKey || process.env.ANTHROPIC_API_KEY;
      if (!apiKey) {
        throw Object.assign(new Error("API key Claude non configurata (Impostazioni). Puoi comunque compilare tutto a mano."), { status: 400 });
      }
      const Anthropic = sdk();
      return new Anthropic({ apiKey });
    }
    var fmtTime = (s) => {
      s = Math.max(0, Math.floor(s || 0));
      const h = Math.floor(s / 3600);
      const m = Math.floor(s % 3600 / 60);
      const sec = s % 60;
      return (h ? `${h}:${String(m).padStart(2, "0")}` : `${m}`) + `:${String(sec).padStart(2, "0")}`;
    };
    var transcriptText = (cues) => cues.map((c) => `[${fmtTime(c.start)}] ${c.speaker ? c.speaker + ": " : ""}${c.text}`).join("\n");
    async function callJson(settings, { system, user, schema, effort = "high", maxTokens = 32e3 }) {
      const client = getClient(settings);
      const base = {
        model: settings.model || DEFAULT_MODEL,
        max_tokens: maxTokens,
        thinking: { type: "adaptive" },
        output_config: { effort, format: { type: "json_schema", schema } },
        system,
        messages: [{ role: "user", content: user }]
      };
      const Anthropic = sdk();
      let message;
      try {
        message = await client.beta.messages.stream({ ...base, betas: ["server-side-fallback-2026-07-01"], fallbacks: "default" }).finalMessage();
      } catch (err) {
        if (err instanceof Anthropic.BadRequestError && /fallback/i.test(err.message)) {
          message = await client.messages.stream(base).finalMessage();
        } else {
          throw wrapError(err);
        }
      }
      if (message.stop_reason === "refusal") throw Object.assign(new Error("Richiesta rifiutata dal modello."), { status: 502 });
      if (message.stop_reason === "max_tokens") throw Object.assign(new Error("Risposta troncata: transcript troppo lungo."), { status: 502 });
      const text = message.content.filter((b) => b.type === "text").map((b) => b.text).join("");
      try {
        return JSON.parse(text);
      } catch {
        throw Object.assign(new Error("Risposta AI non valida"), { status: 502 });
      }
    }
    function wrapError(err) {
      const Anthropic = sdk();
      if (err instanceof Anthropic.AuthenticationError) return Object.assign(new Error("API key non valida."), { status: 401 });
      if (err instanceof Anthropic.RateLimitError) return Object.assign(new Error("Limite di richieste/crediti raggiunto. Riprova pi\xF9 tardi."), { status: 429 });
      if (err instanceof Anthropic.APIConnectionError) return Object.assign(new Error("Impossibile contattare Claude API (rete)."), { status: 502 });
      if (err instanceof Anthropic.APIError) return Object.assign(new Error(`Errore Claude API: ${err.message}`), { status: 502 });
      return err;
    }
    var strArr = { type: "array", items: { type: "string" } };
    var noteItem = {
      type: "object",
      properties: { text: { type: "string" }, note: { type: "string" } },
      required: ["text", "note"],
      additionalProperties: false
    };
    var actionItem = {
      type: "object",
      properties: { text: { type: "string" }, owner: { type: "string" }, deadline: { type: "string" } },
      required: ["text", "owner", "deadline"],
      additionalProperties: false
    };
    function summarySchema(template) {
      const properties = {};
      for (const sec of template.sections) {
        properties[sec.key] = sec.kind === "paragraph" ? { type: "string" } : { type: "array", items: sec.kind === "actions" ? actionItem : noteItem };
      }
      return { type: "object", properties, required: Object.keys(properties), additionalProperties: false };
    }
    var ROLE_HINT = {
      done: "attivit\xE0 concluse",
      doing: "attivit\xE0 in corso",
      next: "prossimi passi / azioni da fare",
      risk: "criticit\xE0, rischi, punti di attenzione, blocchi",
      decision: "decisioni prese o accordi",
      info: "informazioni e contesto"
    };
    async function generateSummary({ settings, project, checkpoint, previous, template }) {
      if (!template?.sections?.length) throw Object.assign(new Error("Template mancante"), { status: 400 });
      const cues = checkpoint.transcript?.cues || [];
      if (!cues.length && !checkpoint.notes) throw Object.assign(new Error("Transcript vuoto."), { status: 400 });
      const prev = previous.map((c) => `### Checkpoint ${c.date}
${JSON.stringify(c.summary)}`).join("\n\n");
      const sections = template.sections.map((s) => `- "${s.key}" (${s.title}, ${s.kind === "paragraph" ? "paragrafo di testo" : s.kind === "actions" ? "elenco con owner e deadline" : "elenco"}): ${ROLE_HINT[s.role] || ""}${s.hint ? " \u2014 " + s.hint : ""}`).join("\n");
      const system = `Sei l'assistente di una consulente che redige il riepilogo delle riunioni di progetto con il cliente ${project.name}.
Estrai dal transcript revisionato i punti per l'email di riepilogo secondo il template "${template.name}", con lo stile dell'email di esempio: italiano professionale, frasi nominali sintetiche, termini tecnici corretti.
Sezioni del template:
${sections}
Regole:
- Riporta solo ci\xF2 che \xE8 stato effettivamente detto nella riunione; non inventare attivit\xE0, owner o date.
- Usa i riepiloghi precedenti per dare continuit\xE0 (es. attivit\xE0 prima "in corso" ora concluse) e per riconoscere i nomi.
- Negli elenchi, "note" contiene un eventuale aggiornamento/esito (es. "mandato in review dal GdL ai referenti"), altrimenti stringa vuota.
- Deadline nel formato gg/mm/aaaa, owner come "ATAC", "GdL" o nome; stringa vuota se non detti. Sezioni senza contenuto: elenco vuoto o stringa vuota.`;
      const user = `## Email di esempio (stile)
${project.exampleEmail}

## Riepiloghi precedenti
${prev || "(nessuno)"}

## Glossario
${project.glossary || "-"}

## Note della consulente
${checkpoint.notes || "-"}

## Transcript della riunione del ${checkpoint.date}
${transcriptText(cues)}`;
      return callJson(settings, { system, user, schema: summarySchema(template), effort: "high" });
    }
    var PROOF_SCHEMA = {
      type: "object",
      properties: {
        corrections: {
          type: "array",
          items: {
            type: "object",
            properties: { id: { type: "string" }, text: { type: "string" } },
            required: ["id", "text"],
            additionalProperties: false
          }
        }
      },
      required: ["corrections"],
      additionalProperties: false
    };
    async function proofread({ settings, project, cues }) {
      const system = `Correggi un transcript automatico di Microsoft Teams in italiano: refusi, punteggiatura, maiuscole, nomi propri e termini tecnici (vedi glossario). Non riassumere, non cambiare il senso, non riformulare lo stile parlato oltre il necessario. Restituisci solo i blocchi che hai modificato, con il testo completo corretto.`;
      const out = [];
      for (let i = 0; i < cues.length; i += 150) {
        const chunk = cues.slice(i, i + 150);
        const user = `Glossario: ${project.glossary || "-"}

Blocchi (JSON):
${JSON.stringify(chunk.map((c) => ({ id: c.id, speaker: c.speaker, text: c.text })))}`;
        const res = await callJson(settings, { system, user, schema: PROOF_SCHEMA, effort: "low", maxTokens: 32e3 });
        const byId = new Map(chunk.map((c) => [c.id, c]));
        for (const c of res.corrections || []) if (byId.has(c.id) && byId.get(c.id).text !== c.text) out.push(c);
      }
      return out;
    }
    var FORECAST_SCHEMA = {
      type: "object",
      properties: {
        items: {
          type: "array",
          items: {
            type: "object",
            properties: {
              title: { type: "string" },
              rationale: { type: "string" },
              owner: { type: "string" },
              priority: { type: "string", enum: ["alta", "media", "bassa"] }
            },
            required: ["title", "rationale", "owner", "priority"],
            additionalProperties: false
          }
        },
        risks: strArr,
        agendaNote: { type: "string" }
      },
      required: ["items", "risks", "agendaNote"],
      additionalProperties: false
    };
    async function forecast({ settings, project, checkpoints, today }) {
      const system = `Sei un PMO del progetto ${project.name}. Dallo storico dei checkpoint prevedi i temi del prossimo checkpoint: attivit\xE0 in corso da verificare, prossimi passi da chiudere, punti di attenzione con deadline vicine o scadute, dipendenze bloccanti. Sii concreto e basato sullo storico, in italiano.`;
      const user = `Oggi: ${today}

${checkpoints.map((c) => `### ${c.date} \u2014 ${c.title}
${JSON.stringify(c.summary)}`).join("\n\n")}`;
      return callJson(settings, { system, user, schema: FORECAST_SCHEMA, effort: "medium", maxTokens: 16e3 });
    }
    module2.exports = { DEFAULT_MODEL, generateSummary, proofread, forecast };
  }
});

// lib/ollama.js
var require_ollama = __commonJS({
  "lib/ollama.js"(exports2, module2) {
    var fs2 = require("fs");
    var os = require("os");
    var path2 = require("path");
    var https = require("https");
    var { exec: exec2 } = require("child_process");
    var HOST = (process.env.OLLAMA_HOST || "http://127.0.0.1:11434").replace(/\/$/, "");
    var RECOMMENDED = [
      { name: "qwen2.5:3b", size: "1,9 GB", note: "Consigliato: veloce, buon italiano, va bene su un portatile" },
      { name: "llama3.2:3b", size: "2,0 GB", note: "Alternativa leggera" },
      { name: "gemma3:4b", size: "3,3 GB", note: "Pi\xF9 accurato, un po\u2019 pi\xF9 lento" },
      { name: "qwen2.5:7b", size: "4,7 GB", note: "Qualit\xE0 migliore, serve un PC con almeno 16 GB di RAM" }
    ];
    var jobs = { install: null, pull: null, train: null };
    async function call(pathname, body, { timeout = 12e4 } = {}) {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), timeout);
      try {
        const res = await fetch(HOST + pathname, {
          method: body ? "POST" : "GET",
          headers: body ? { "Content-Type": "application/json" } : void 0,
          body: body ? JSON.stringify(body) : void 0,
          signal: ctrl.signal
        });
        const text = await res.text();
        if (!res.ok) throw Object.assign(new Error(`Ollama: ${text.slice(0, 200) || res.status}`), { status: 502 });
        return text ? JSON.parse(text) : {};
      } catch (err) {
        if (err.status) throw err;
        throw Object.assign(new Error("Ollama non \xE8 in esecuzione. Aprilo (o installalo) dalla finestra \u201CAI locale\u201D."), { status: 503 });
      } finally {
        clearTimeout(t);
      }
    }
    async function status() {
      try {
        const [v, tags] = await Promise.all([call("/api/version", null, { timeout: 2500 }), call("/api/tags", null, { timeout: 2500 })]);
        return { running: true, version: v.version, models: (tags.models || []).map((m) => ({ name: m.name, size: m.size, modified: m.modified_at })) };
      } catch {
        return { running: false, models: [] };
      }
    }
    function download(url, dest, onProgress, redirects = 0) {
      return new Promise((resolve, reject) => {
        https.get(url, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && redirects < 5) {
            res.resume();
            return resolve(download(new URL(res.headers.location, url).toString(), dest, onProgress, redirects + 1));
          }
          if (res.statusCode !== 200) return reject(new Error(`Download fallito (${res.statusCode})`));
          const total = Number(res.headers["content-length"]) || 0;
          let done = 0;
          const out = fs2.createWriteStream(dest);
          res.on("data", (c) => {
            done += c.length;
            onProgress(done, total);
          });
          res.pipe(out);
          out.on("finish", () => out.close(resolve));
          out.on("error", reject);
        }).on("error", reject);
      });
    }
    function install() {
      if (jobs.install?.state === "running") return jobs.install;
      const job = { state: "running", message: "Avvio\u2026", completed: 0, total: 0 };
      jobs.install = job;
      (async () => {
        try {
          if (process.platform === "win32") {
            const dest = path2.join(os.tmpdir(), "OllamaSetup.exe");
            job.message = "Download di Ollama in corso\u2026";
            await download("https://ollama.com/download/OllamaSetup.exe", dest, (d, t) => {
              job.completed = d;
              job.total = t;
            });
            job.message = "Si apre l\u2019installazione di Ollama: segui la procedura e poi torna qui.";
            exec2(`start "" "${dest}"`);
            job.state = "done";
          } else if (process.platform === "darwin") {
            exec2("open https://ollama.com/download/mac");
            job.message = "Si apre la pagina di download: installa Ollama.app, aprila e torna qui.";
            job.state = "done";
          } else {
            job.message = "Su Linux esegui nel terminale: curl -fsSL https://ollama.com/install.sh | sh";
            job.state = "done";
          }
        } catch (err) {
          job.state = "error";
          job.message = err.message;
        }
      })();
      return job;
    }
    function startApp() {
      if (process.platform === "win32") {
        const exe = path2.join(process.env.LOCALAPPDATA || "", "Programs", "Ollama", "ollama app.exe");
        exec2(fs2.existsSync(exe) ? `start "" "${exe}"` : 'start "" ollama serve');
      } else if (process.platform === "darwin") exec2("open -a Ollama");
      else exec2("ollama serve");
    }
    function pull(model) {
      if (jobs.pull?.state === "running") return jobs.pull;
      const job = { state: "running", model, message: "Avvio download\u2026", completed: 0, total: 0 };
      jobs.pull = job;
      (async () => {
        try {
          const res = await fetch(HOST + "/api/pull", { method: "POST", body: JSON.stringify({ model, stream: true }) });
          if (!res.ok) throw new Error(await res.text());
          const decoder = new TextDecoder();
          let buf = "";
          for await (const chunk of res.body) {
            buf += decoder.decode(chunk, { stream: true });
            let nl;
            while ((nl = buf.indexOf("\n")) >= 0) {
              const line = buf.slice(0, nl).trim();
              buf = buf.slice(nl + 1);
              if (!line) continue;
              const ev = JSON.parse(line);
              if (ev.error) throw new Error(ev.error);
              job.message = ev.status || job.message;
              if (ev.total) {
                job.total = ev.total;
                job.completed = ev.completed || 0;
              }
            }
          }
          job.state = "done";
          job.message = `Modello ${model} pronto`;
        } catch (err) {
          job.state = "error";
          job.message = err.message.includes("fetch") ? "Ollama non \xE8 in esecuzione" : err.message;
        }
      })();
      return job;
    }
    async function removeModel(model) {
      const res = await fetch(HOST + "/api/delete", { method: "DELETE", body: JSON.stringify({ model }) }).catch(() => null);
      if (!res?.ok) throw Object.assign(new Error("Impossibile eliminare il modello"), { status: 502 });
    }
    var trainedName = (projectId) => `verbale-${String(projectId).replace(/[^a-z0-9-]/g, "")}`;
    function systemPrompt(project, author) {
      return `Sei l'assistente di ${author || "una consulente"} per i verbali delle riunioni di progetto con il cliente ${project.name}.
Scrivi in italiano professionale, conciso, con frasi nominali come nelle email di riepilogo (es. "Definizione della roadmap use case e del modello target (To-Be)").
Usa correttamente questi nomi e termini tecnici: ${project.glossary || "-"}.
Non inventare informazioni: se una frase non contiene un'attivit\xE0 o un punto utile, rispondi "-".
Rispondi solo con il testo richiesto, senza spiegazioni.`;
    }
    async function train({ project, author, base, examples }) {
      const job = { state: "running", message: "Creazione del modello personalizzato\u2026" };
      jobs.train = job;
      try {
        const messages = [];
        for (const ex of examples.slice(-40)) {
          messages.push({ role: "user", content: `Riscrivi come voce del verbale: ${ex.source}` });
          messages.push({ role: "assistant", content: ex.text });
        }
        await call("/api/create", { model: trainedName(project.id), from: base, system: systemPrompt(project, author), messages, stream: false }, { timeout: 6e5 });
        job.state = "done";
        job.message = `Modello ${trainedName(project.id)} creato con ${examples.length} esempi`;
        return { model: trainedName(project.id), examples: examples.length };
      } catch (err) {
        job.state = "error";
        job.message = err.message;
        throw err;
      }
    }
    async function task({ model, project, author, task: kind, text, glossary }) {
      const trained = model.startsWith("verbale-");
      const system = trained ? void 0 : systemPrompt(project, author);
      let prompt;
      if (kind === "rewrite") prompt = `Riscrivi come voce del verbale: ${text}`;
      else if (kind === "proofread")
        prompt = `Correggi solo refusi, punteggiatura, maiuscole e termini tecnici (${glossary || project.glossary || ""}) in questa frase trascritta automaticamente. Non riassumere e non cambiare il senso. Frase: ${text}`;
      else throw Object.assign(new Error("Compito non supportato"), { status: 400 });
      const messages = [...system ? [{ role: "system", content: system }] : [], { role: "user", content: prompt }];
      const res = await call("/api/chat", { model, messages, stream: false, options: { temperature: 0.2 } }, { timeout: 18e4 });
      return String(res.message?.content || "").trim().replace(/^["«]|["»]$/g, "");
    }
    var fmtTime = (s) => {
      s = Math.max(0, Math.floor(s || 0));
      const h = Math.floor(s / 3600);
      const m = Math.floor(s % 3600 / 60);
      return (h ? `${h}:${String(m).padStart(2, "0")}` : `${m}`) + `:${String(s % 60).padStart(2, "0")}`;
    };
    function summaryText(summary, template) {
      if (!summary) return "";
      const secs = template?.sections || Object.keys(summary).map((key) => ({ key, title: key }));
      const out = [];
      for (const sec of secs) {
        const v = summary[sec.key];
        if (Array.isArray(v) && v.length) {
          out.push(`${sec.title}:`);
          for (const it of v) {
            const extra = [it.note && `\u2192 ${it.note}`, it.owner && `owner ${it.owner}`, it.deadline && `deadline ${it.deadline}`].filter(Boolean).join(", ");
            out.push(`- ${it.text}${extra ? ` (${extra})` : ""}`);
          }
        } else if (typeof v === "string" && v.trim()) out.push(`${sec.title}: ${v.trim()}`);
      }
      return out.join("\n");
    }
    function checkpointSystemPrompt({ project, author, checkpoint: c, context = {}, template }) {
      const parts = [
        `Sei l'assistente di ${author || "una consulente"} per i verbali delle riunioni di progetto con il cliente ${project.name}.`,
        `Rispondi sempre in italiano, in modo professionale e conciso. Usa correttamente questi nomi e termini: ${project.glossary || "-"}.`,
        `Non inventare fatti, owner o date che non compaiono nel materiale fornito.`,
        `
## Riunione
${c.title} del ${String(c.date || "").split("-").reverse().join("/")}`
      ];
      if (template?.sections?.length) {
        parts.push(
          `
## Template del riepilogo "${template.name}"
` + template.sections.map((s) => `- ${s.key}: ${s.title} (${s.kind === "paragraph" ? "paragrafo" : s.kind === "actions" ? "elenco con owner e deadline" : "elenco"})`).join("\n")
        );
      }
      if (context.example && project.exampleEmail) parts.push(`
## Email di esempio (stile di riferimento)
${project.exampleEmail.slice(0, 2500)}`);
      if (context.pins && c.pins?.length) parts.push(`
## Punti chiave evidenziati durante la riunione (appunti grezzi)
${c.pins.map((p) => `- [${p.id}] ${p.speaker ? p.speaker + ": " : ""}${p.text}`).join("\n")}`);
      if (context.summary) {
        const t = summaryText(c.summary, template);
        if (t) parts.push(`
## Riepilogo attuale
${t}`);
      }
      if (context.email && c.email?.body) parts.push(`
## Email attuale
${c.email.body.slice(0, 5e3)}`);
      if (context.notes && c.notes) parts.push(`
## Note
${c.notes.slice(0, 3e3)}`);
      if (context.transcript && c.transcript?.cues?.length) {
        let t = c.transcript.cues.map((q) => `[${fmtTime(q.start)}] ${q.speaker ? q.speaker + ": " : ""}${q.text}`).join("\n");
        if (t.length > 24e3) t = t.slice(0, 24e3) + "\n(transcript troncato per lunghezza)";
        parts.push(`
## Transcript
${t}`);
      }
      return parts.join("\n");
    }
    async function chatStream({ model, messages, format, numCtx = 8192 }) {
      const send2 = (fmt) => fetch(HOST + "/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model, messages, stream: true, ...fmt ? { format: fmt } : {}, options: { temperature: 0.3, num_ctx: numCtx } })
      });
      let res;
      try {
        res = await send2(format);
        if (!res.ok && format && typeof format === "object") res = await send2("json");
      } catch {
        throw Object.assign(new Error("Ollama non \xE8 in esecuzione. Aprilo dalla finestra \u201CAI locale\u201D."), { status: 503 });
      }
      if (!res.ok) throw Object.assign(new Error(`Ollama: ${(await res.text()).slice(0, 200)}`), { status: 502 });
      return res;
    }
    module2.exports = { RECOMMENDED, jobs, status, install, startApp, pull, removeModel, train, task, trainedName, checkpointSystemPrompt, chatStream };
  }
});

// lib/backup.js
var require_backup = __commonJS({
  "lib/backup.js"(exports2, module2) {
    var fs2 = require("fs");
    var fsp2 = require("fs/promises");
    var path2 = require("path");
    var VIDEO_EXT2 = /\.(mp4|m4v|mov|webm|mkv|m4a|mp3|wav)$/i;
    var KEEP_VERSIONS = 80;
    var KEEP_DAILY = 30;
    var SNAPSHOT_EVERY_MS = 3 * 60 * 1e3;
    var cfg = null;
    var status = { lastDaily: null, lastMirror: null, lastError: null };
    function init(options) {
      cfg = options;
    }
    var stamp = (d = /* @__PURE__ */ new Date()) => {
      const p = (n) => String(n).padStart(2, "0");
      return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
    };
    async function copyTree(src, dest, { skipVideo = true, skipDirs = [] } = {}) {
      const entries = await fsp2.readdir(src, { withFileTypes: true }).catch(() => []);
      await fsp2.mkdir(dest, { recursive: true });
      for (const e of entries) {
        const s = path2.join(src, e.name);
        const d = path2.join(dest, e.name);
        if (e.isDirectory()) {
          if (!skipDirs.includes(e.name)) await copyTree(s, d, { skipVideo, skipDirs });
        } else if (!(skipVideo && VIDEO_EXT2.test(e.name)) && !e.name.endsWith(".tmp") && !e.name.endsWith(".upload")) {
          await fsp2.copyFile(s, d).catch(() => {
          });
        }
      }
    }
    async function prune(dir, keep) {
      const list = (await fsp2.readdir(dir).catch(() => [])).sort();
      for (const name of list.slice(0, Math.max(0, list.length - keep))) await fsp2.rm(path2.join(dir, name), { recursive: true, force: true });
    }
    async function snapshot(checkpointDir2, data, reason = "auto") {
      const dir = path2.join(checkpointDir2, "versioni");
      await fsp2.mkdir(dir, { recursive: true });
      if (reason === "auto") {
        const last = (await fsp2.readdir(dir).catch(() => [])).sort().pop();
        if (last) {
          const st = await fsp2.stat(path2.join(dir, last)).catch(() => null);
          if (st && Date.now() - st.mtimeMs < SNAPSHOT_EVERY_MS) return null;
        }
      }
      const name = `${stamp()}_${reason}.json`;
      await fsp2.writeFile(path2.join(dir, name), JSON.stringify(data));
      await prune(dir, KEEP_VERSIONS);
      return name;
    }
    function describe(c) {
      const items = Object.values(c.summary || {}).reduce((n, v) => n + (Array.isArray(v) ? v.length : 0), 0);
      return { cues: c.transcript?.cues?.length || 0, items, pins: c.pins?.length || 0, title: c.title, date: c.date };
    }
    async function listVersions(checkpointDir2) {
      const dir = path2.join(checkpointDir2, "versioni");
      const files = (await fsp2.readdir(dir).catch(() => [])).filter((f) => f.endsWith(".json")).sort().reverse();
      const out = [];
      for (const f of files) {
        try {
          const c = JSON.parse(await fsp2.readFile(path2.join(dir, f), "utf8"));
          const m = /^(\d{4}-\d{2}-\d{2})_(\d{2})-(\d{2})-(\d{2})_(.+)\.json$/.exec(f);
          out.push({ file: f, savedAt: m ? `${m[1]}T${m[2]}:${m[3]}:${m[4]}` : "", reason: m ? m[5] : "", ...describe(c) });
        } catch {
        }
      }
      return out;
    }
    async function readVersion(checkpointDir2, file) {
      if (!/^[\w-]+\.json$/.test(file)) throw Object.assign(new Error("Versione non valida"), { status: 400 });
      return JSON.parse(await fsp2.readFile(path2.join(checkpointDir2, "versioni", file), "utf8"));
    }
    var trashDir = () => path2.join(cfg.dataDir, "cestino");
    async function moveToTrash(srcDir, meta) {
      const id = `${stamp()}_${meta.kind}_${path2.basename(srcDir)}`;
      const dest = path2.join(trashDir(), id);
      await fsp2.mkdir(trashDir(), { recursive: true });
      try {
        await fsp2.rename(srcDir, dest);
      } catch {
        await copyTree(srcDir, dest, { skipVideo: false });
        await fsp2.rm(srcDir, { recursive: true, force: true });
      }
      await fsp2.writeFile(path2.join(dest, "cestino.json"), JSON.stringify({ ...meta, originalPath: srcDir, deletedAt: (/* @__PURE__ */ new Date()).toISOString() }, null, 2));
      return id;
    }
    async function listTrash() {
      const out = [];
      for (const id of (await fsp2.readdir(trashDir()).catch(() => [])).sort().reverse()) {
        try {
          out.push({ id, ...JSON.parse(await fsp2.readFile(path2.join(trashDir(), id, "cestino.json"), "utf8")) });
        } catch {
        }
      }
      return out;
    }
    async function restoreFromTrash(id) {
      if (!/^[\w.-]+$/.test(id)) throw Object.assign(new Error("Elemento non valido"), { status: 400 });
      const src = path2.join(trashDir(), id);
      const meta = JSON.parse(await fsp2.readFile(path2.join(src, "cestino.json"), "utf8"));
      let dest = meta.originalPath;
      if (fs2.existsSync(dest)) dest = `${dest}-ripristinato-${Date.now().toString(36)}`;
      await fsp2.mkdir(path2.dirname(dest), { recursive: true });
      await fsp2.rm(path2.join(src, "cestino.json"), { force: true });
      await fsp2.rename(src, dest);
      return { ...meta, restoredTo: dest };
    }
    async function purgeTrash(id) {
      if (!/^[\w.-]+$/.test(id)) throw Object.assign(new Error("Elemento non valido"), { status: 400 });
      await fsp2.rm(path2.join(trashDir(), id), { recursive: true, force: true });
    }
    async function dailyBackup({ force } = {}) {
      const day = stamp().slice(0, 10);
      const existing = (await fsp2.readdir(cfg.backupDir).catch(() => [])).filter((n) => n.startsWith(day));
      if (existing.length && !force) return null;
      const name = force ? stamp() : day;
      const dest = path2.join(cfg.backupDir, name);
      try {
        await copyTree(cfg.dataDir, path2.join(dest, "data"), { skipDirs: ["cestino"] });
        await fsp2.writeFile(
          path2.join(dest, "LEGGIMI.txt"),
          `\uFEFFBackup automatico di Verbale Studio.\r
Per ripristinarlo: chiudi l'app e copia la cartella "data" al posto di quella nella cartella di Verbale Studio.\r
`
        );
        await prune(cfg.backupDir, KEEP_DAILY);
        status.lastDaily = (/* @__PURE__ */ new Date()).toISOString();
        const mirror = await cfg.getMirror();
        if (mirror) {
          await copyTree(dest, path2.join(mirror, "Backup", name));
          await copyTree(cfg.archiveDir, path2.join(mirror, "Archivio"));
          await prune(path2.join(mirror, "Backup"), KEEP_DAILY);
          status.lastMirror = (/* @__PURE__ */ new Date()).toISOString();
        }
        return name;
      } catch (err) {
        status.lastError = `Backup: ${err.message}`;
        throw err;
      }
    }
    async function mirrorFolder(absFolder) {
      const mirror = await cfg.getMirror();
      if (!mirror || !absFolder) return;
      const rel = path2.relative(cfg.workDir, absFolder);
      try {
        await copyTree(absFolder, path2.join(mirror, rel));
        status.lastMirror = (/* @__PURE__ */ new Date()).toISOString();
      } catch (err) {
        status.lastError = `Copia aggiuntiva: ${err.message}`;
      }
    }
    function startScheduler() {
      const run = () => dailyBackup().catch((err) => console.error("Backup giornaliero non riuscito:", err.message));
      setTimeout(run, 5e3);
      setInterval(run, 60 * 60 * 1e3).unref();
    }
    async function lastBackups() {
      return (await fsp2.readdir(cfg.backupDir).catch(() => [])).sort().reverse().slice(0, 10);
    }
    module2.exports = { init, status, snapshot, listVersions, readVersion, describe, moveToTrash, listTrash, restoreFromTrash, purgeTrash, dailyBackup, mirrorFolder, startScheduler, lastBackups, copyTree };
  }
});

// server.js
var http = require("http");
var fs = require("fs");
var fsp = require("fs/promises");
var path = require("path");
var zlib = require("zlib");
var crypto = require("crypto");
var { exec } = require("child_process");
var ai = require_ai();
var ollama = require_ollama();
var backup = require_backup();
var sea = null;
try {
  sea = require("node:sea");
  if (!sea.isSea()) sea = null;
} catch {
  sea = null;
}
var PORT = Number(process.env.PORT) || 4310;
var APP_VERSION = "1.4.0";
var ROOT = __dirname;
var PUBLIC_DIR = path.join(ROOT, "public");
var argDir = process.argv.slice(2).find((a) => !a.startsWith("--"));
var WORK_DIR = path.resolve(argDir || process.env.VERBALE_WORK_DIR || (sea ? path.dirname(process.execPath) : ROOT));
var DATA_DIR = process.env.VERBALE_DATA_DIR || path.join(WORK_DIR, "data");
var PROJECTS_DIR = path.join(DATA_DIR, "projects");
var SETTINGS_FILE = path.join(DATA_DIR, "settings.json");
var MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
  ".json": "application/json; charset=utf-8",
  ".mp4": "video/mp4",
  ".m4v": "video/mp4",
  ".webm": "video/webm",
  ".mov": "video/quicktime",
  ".mkv": "video/x-matroska",
  ".mp3": "audio/mpeg",
  ".m4a": "audio/mp4",
  ".wav": "audio/wav"
};
var DEFAULT_EXAMPLE_EMAIL = `Ciao a tutti,

di seguito i punti discussi durante il checkpoint odierno.

\u2022 Attivit\xE0 completate:
   o Ingestion delle estrazioni dei dati dai database sorgente in formato CSV, dal livello bronze al livello silver;
   o Sviluppo del layer Gold (ETL) della Data Platform sulla base dei file ricevuti da ATAC;
   o Analisi delle modifiche al Terraform per abilitare la connettivit\xE0 ai sistemi on-premise di ATAC.

\u2022 Attivit\xE0 in corso (pianificate per questa settimana):
   o Definizione del documento di governance tramite template dedicato con identificazione di ruoli e responsabilit\xE0 per la gestione e l\u2019evoluzione della Data Platform e del relativo design; \u2192 mandato in review dal GdL ai referenti ATAC.
   o Definizione e strutturazione della libreria di Data Quality della Data Platform;
   o Definizione della roadmap use case e del modello target (To-Be);
   o Definizione e sviluppo delle dashboard a supporto dell\u2019MVP della Data Platform.

\u2022 Prossimi passi
   o Ottenimento degli accessi alle fonti dati censite;
   o Verifica degli accessi ai database sorgente su Databricks;
   o Creazione e configurazione dei job all\u2019interno della Virtual Network;

Per il secondo e terzo punto \u2192 Attualmente non \xE8 possibile effettuare il ping necessario al controllo della raggiungibilit\xE0 dei database sorgente. Il problema sembra essere riconducibile alla fase di creazione dei cluster di calcolo; \xE8 necessario verificare se si tratti di un\u2019anomalia nella configurazione di Azure Databricks oppure di una limitazione legata alla disponibilit\xE0 di risorse sui server nelle regioni North Europe/East Europe. Si rende quindi necessario pianificare uno slot con Genesio di Sabatino per analizzare i log prodotti e disponibili su Microsoft Azure, al fine di identificare la causa del problema e definire le opportune azioni correttive.

\u2022 Punti di attenzione:
   1. Pianificare, nel rispetto delle scadenze progettuali, riunioni di assessment con i vendor finalizzate alla selezione della piattaforma pi\xF9 idonea.
      (Owner- ATAC) \u2192 Deadline: 18/05/2026
   2. Consistenza delle estrazioni dati dai database sorgente in formato CSV (Dado e BITP): rilevate anomalie sui dati ricevuti, in attesa della trasmissione dei dataset corretti. \u2192 Deadline: 24/07/2026

\xC8 stato concordato che il checkpoint di oggi costituisce l\u2019ultimo incontro prima della pausa estiva e che i successivi checkpoint riprenderanno da luned\xEC 7 settembre.

In allegato trovate le slide discusse durante la riunione; come sempre, vi chiedo cortesemente di estendere la presente a chi riteniate opportuno.

A disposizione,
Grazie
Lucrezia`;
var safeId = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 80);
var slugify = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40) || "progetto";
async function readJson(file, fallback) {
  try {
    return JSON.parse(await fsp.readFile(file, "utf8"));
  } catch {
    return fallback;
  }
}
async function writeJson(file, data) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${Date.now().toString(36)}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(data, null, 2));
  for (let attempt = 0; ; attempt++) {
    try {
      await fsp.rename(tmp, file);
      return;
    } catch (err) {
      if (attempt >= 5) {
        await fsp.copyFile(tmp, file);
        await fsp.rm(tmp, { force: true });
        return;
      }
      await new Promise((r) => setTimeout(r, 60 * (attempt + 1)));
    }
  }
}
var projectDir = (pid) => path.join(PROJECTS_DIR, safeId(pid));
var projectFile = (pid) => path.join(projectDir(pid), "project.json");
var checkpointDir = (pid, cid) => path.join(projectDir(pid), "checkpoints", safeId(cid));
var checkpointFile = (pid, cid) => path.join(checkpointDir(pid, cid), "checkpoint.json");
var forecastFile = (pid) => path.join(projectDir(pid), "forecast.json");
var TEMPLATES_FILE = path.join(DATA_DIR, "templates.json");
var ARCHIVE_DIR = path.join(WORK_DIR, "Archivio");
var BACKUP_DIR = path.join(WORK_DIR, "Backup");
var RUNNING_FROM_TEMP = Boolean(sea) && /[\\/](temp|tmp)[\\/]|Temp\d+_|\.zip[\\/]/i.test(process.execPath);
var locks = /* @__PURE__ */ new Map();
function withLock(key, fn) {
  const prev = locks.get(key) || Promise.resolve();
  const next = prev.then(fn, fn);
  locks.set(key, next.catch(() => {
  }));
  return next;
}
var winSafe = (s) => String(s || "").replace(/[<>:"/\\|?*\x00-\x1f]/g, " ").replace(/\s+/g, " ").trim().replace(/[. ]+$/, "").slice(0, 80) || "Senza titolo";
var folderName = (c) => `${c.date} ${winSafe(c.title)}`;
async function ensureFolder(pid, c) {
  if (c.folder) {
    const abs = workPath(c.folder);
    if (fs.existsSync(abs)) return abs;
  }
  const project = await readJson(projectFile(pid), null);
  const base = path.join(ARCHIVE_DIR, winSafe(project?.name || pid));
  let dir = path.join(base, folderName(c));
  for (let i = 2; fs.existsSync(dir); i++) dir = path.join(base, `${folderName(c)} (${i})`);
  await fsp.mkdir(dir, { recursive: true });
  c.folder = path.relative(WORK_DIR, dir);
  return dir;
}
async function renameFolderIfNeeded(c) {
  if (!c.folder) return;
  const abs = workPath(c.folder);
  const wanted = path.join(path.dirname(abs), folderName(c));
  if (path.basename(abs).startsWith(folderName(c)) || fs.existsSync(wanted) || !fs.existsSync(abs)) return;
  try {
    await fsp.rename(abs, wanted);
  } catch {
    return;
  }
  const oldRel = c.folder;
  const newRel = path.relative(WORK_DIR, wanted);
  const fix = (rel) => rel && rel.startsWith(oldRel + path.sep) ? newRel + rel.slice(oldRel.length) : rel;
  c.folder = newRel;
  if (c.video?.external) c.video.external = fix(c.video.external);
  if (c.transcriptFile) c.transcriptFile = fix(c.transcriptFile);
}
var fmtShort = (sec) => {
  sec = Math.max(0, Math.floor(sec || 0));
  const h = Math.floor(sec / 3600);
  const m = Math.floor(sec % 3600 / 60);
  return (h ? `${h}:${String(m).padStart(2, "0")}` : `${m}`) + `:${String(sec % 60).padStart(2, "0")}`;
};
async function writeExports(pid, c) {
  const cues = c.transcript?.cues || [];
  if (!c.folder && !cues.length && !c.video) return;
  const dir = await ensureFolder(pid, c);
  const project = await readJson(projectFile(pid), null);
  const header = `${project?.name || ""} \u2014 ${c.title} \u2014 ${c.date.split("-").reverse().join("/")}`;
  if (cues.length) {
    const txt = `${header}\r
\r
` + cues.map((q) => `[${fmtShort(q.start)}] ${q.speaker ? q.speaker + ": " : ""}${q.text}`).join("\r\n") + "\r\n";
    await fsp.writeFile(path.join(dir, "Transcript revisionato.txt"), "\uFEFF" + txt);
  }
  if (c.email?.body?.trim()) {
    const txt = `Oggetto: ${c.email.subject || ""}\r
\r
${c.email.body.replace(/\r?\n/g, "\r\n")}\r
`;
    await fsp.writeFile(path.join(dir, "Email di riepilogo.txt"), "\uFEFF" + txt);
  }
  if (c.pins?.length) {
    const txt = `${header} \u2014 punti chiave\r
\r
` + c.pins.map((p) => `[${fmtShort(p.start)}] ${p.speaker ? p.speaker + ": " : ""}${p.text}${p.section ? "  (inserito nel riepilogo)" : ""}`).join("\r\n") + "\r\n";
    await fsp.writeFile(path.join(dir, "Punti chiave.txt"), "\uFEFF" + txt);
  }
  if (c.notes?.trim()) await fsp.writeFile(path.join(dir, "Note.txt"), "\uFEFF" + c.notes.replace(/\r?\n/g, "\r\n"));
  await writeJson(path.join(dir, "_dati-app", "checkpoint.json"), { ...c, projectName: project?.name || "" });
  await backup.mirrorFolder(dir);
}
function workPath(rel) {
  const abs = path.resolve(WORK_DIR, String(rel || ""));
  if (abs !== WORK_DIR && !abs.startsWith(WORK_DIR + path.sep)) throw Object.assign(new Error("Percorso non valido"), { status: 400 });
  return abs;
}
async function getSettings() {
  return readJson(SETTINGS_FILE, { apiKey: "", model: ai.DEFAULT_MODEL, author: "Lucrezia" });
}
function publicSettings(s) {
  const key = s.apiKey || process.env.ANTHROPIC_API_KEY || "";
  return {
    model: s.model || ai.DEFAULT_MODEL,
    author: s.author || "",
    ollamaModel: s.ollamaModel || "",
    mirrorDir: s.mirrorDir || "",
    copyLinkedVideos: s.copyLinkedVideos !== false,
    hasApiKey: Boolean(key),
    apiKeySource: s.apiKey ? "impostazioni" : process.env.ANTHROPIC_API_KEY ? "variabile ambiente" : null,
    apiKeyHint: key ? `\u2026${key.slice(-4)}` : ""
  };
}
async function ensureSeed() {
  await fsp.mkdir(PROJECTS_DIR, { recursive: true });
  const entries = await fsp.readdir(PROJECTS_DIR).catch(() => []);
  if (entries.length === 0) {
    await writeJson(projectFile("atac"), {
      id: "atac",
      name: "ATAC",
      description: "Data Platform \u2014 checkpoint settimanali",
      recipients: "",
      subjectTemplate: "ATAC | Checkpoint {data} \u2014 punti discussi",
      templateId: "checkpoint-settimanale",
      glossary: "ATAC, Databricks, Azure, Terraform, Virtual Network, Data Platform, bronze, silver, gold, ETL, MVP, Data Quality, GdL, Dado, BITP",
      exampleEmail: DEFAULT_EXAMPLE_EMAIL,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
}
async function listProjects() {
  const entries = await fsp.readdir(PROJECTS_DIR, { withFileTypes: true }).catch(() => []);
  const out = [];
  for (const e of entries) {
    if (!e.isDirectory()) continue;
    const p = await readJson(projectFile(e.name), null);
    if (p) out.push(p);
  }
  return out.sort((a, b) => a.name.localeCompare(b.name));
}
function checkpointSummary(c) {
  const cues = c.transcript?.cues || [];
  const s = c.summary || {};
  return {
    id: c.id,
    projectId: c.projectId,
    date: c.date,
    title: c.title,
    status: c.status,
    updatedAt: c.updatedAt,
    hasVideo: Boolean(c.video),
    cueCount: cues.length,
    reviewedCount: cues.filter((q) => q.reviewed).length,
    flaggedCount: cues.filter((q) => q.flagged).length,
    duration: cues.length ? cues[cues.length - 1].end : 0,
    itemCount: Object.values(s).reduce((n, v) => n + (Array.isArray(v) ? v.length : 0), 0),
    pinCount: (c.pins || []).length
  };
}
async function loadCheckpoints(pid) {
  const dir = path.join(projectDir(pid), "checkpoints");
  const entries = await fsp.readdir(dir, { withFileTypes: true }).catch(() => []);
  const out = [];
  for (const e of entries) {
    if (!e.isDirectory()) continue;
    const c = await readJson(path.join(dir, e.name, "checkpoint.json"), null);
    if (c) out.push(c);
  }
  return out.sort((a, b) => (b.date || "").localeCompare(a.date || "") || (b.createdAt || "").localeCompare(a.createdAt || ""));
}
function unzipEntry(buf, wanted) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
    if (buf.readUInt32LE(i) === 101010256) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) throw new Error("File DOCX non valido");
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(off) !== 33639248) break;
    const method = buf.readUInt16LE(off + 10);
    const compSize = buf.readUInt32LE(off + 20);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    const name = buf.toString("utf8", off + 46, off + 46 + nameLen);
    if (name === wanted) {
      const lNameLen = buf.readUInt16LE(localOff + 26);
      const lExtraLen = buf.readUInt16LE(localOff + 28);
      const start = localOff + 30 + lNameLen + lExtraLen;
      const data = buf.subarray(start, start + compSize);
      return method === 8 ? zlib.inflateRawSync(data) : data;
    }
    off += 46 + nameLen + extraLen + commentLen;
  }
  throw new Error(`${wanted} non trovato nel DOCX`);
}
function docxToText(buf) {
  const xml = unzipEntry(buf, "word/document.xml").toString("utf8");
  const decode = (s) => s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d))).replace(/&amp;/g, "&");
  return xml.split(/<\/w:p>/).map(
    (p) => decode(
      p.replace(/<w:tab\/>/g, "	").replace(/<w:br[^>]*\/>/g, "\n").replace(/<[^>]+>/g, "")
    )
  ).join("\n").replace(/\n{3,}/g, "\n\n").trim();
}
function send(res, status, body, headers = {}) {
  const isJson = typeof body !== "string" && !Buffer.isBuffer(body);
  res.writeHead(status, {
    "Content-Type": isJson ? "application/json; charset=utf-8" : "text/plain; charset=utf-8",
    "Cache-Control": "no-store",
    ...headers
  });
  res.end(isJson ? JSON.stringify(body) : body);
}
async function readBody(req, limit = 50 * 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw Object.assign(new Error("Payload troppo grande"), { status: 413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}
async function readJsonBody(req) {
  const buf = await readBody(req);
  if (!buf.length) return {};
  try {
    return JSON.parse(buf.toString("utf8"));
  } catch {
    throw Object.assign(new Error("JSON non valido"), { status: 400 });
  }
}
async function serveFile(req, res, file, { download } = {}) {
  let stat;
  try {
    stat = await fsp.stat(file);
  } catch {
    return send(res, 404, "Non trovato");
  }
  const type = MIME[path.extname(file).toLowerCase()] || "application/octet-stream";
  const headers = { "Content-Type": type, "Accept-Ranges": "bytes", "Cache-Control": "no-cache" };
  if (download) headers["Content-Disposition"] = `attachment; filename="${path.basename(file)}"`;
  const range = req.headers.range;
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range);
    let start = m && m[1] ? parseInt(m[1], 10) : 0;
    let end = m && m[2] ? parseInt(m[2], 10) : stat.size - 1;
    if (m && !m[1] && m[2]) {
      start = stat.size - parseInt(m[2], 10);
      end = stat.size - 1;
    }
    if (start >= stat.size || end >= stat.size || start > end) {
      res.writeHead(416, { "Content-Range": `bytes */${stat.size}` });
      return res.end();
    }
    res.writeHead(206, { ...headers, "Content-Range": `bytes ${start}-${end}/${stat.size}`, "Content-Length": end - start + 1 });
    return fs.createReadStream(file, { start, end }).pipe(res);
  }
  res.writeHead(200, { ...headers, "Content-Length": stat.size });
  if (req.method === "HEAD") return res.end();
  fs.createReadStream(file).pipe(res);
}
var routes = [];
var route = (method, pattern, handler) => {
  const keys = [];
  const re = new RegExp(
    "^" + pattern.replace(/:(\w+)/g, (_, k) => (keys.push(k), "([^/]+)")) + "/?$"
  );
  routes.push({ method, re, keys, handler });
};
route("GET", "/api/state", async (req, res) => {
  const settings = await getSettings();
  send(res, 200, { projects: await listProjects(), settings: publicSettings(settings), workDir: WORK_DIR, dataDir: DATA_DIR, packaged: Boolean(sea), version: APP_VERSION, runningFromTemp: RUNNING_FROM_TEMP });
});
route("PUT", "/api/settings", async (req, res) => {
  const body = await readJsonBody(req);
  const current = await getSettings();
  const next = { ...current };
  if (typeof body.apiKey === "string") next.apiKey = body.apiKey.trim();
  if (typeof body.model === "string" && body.model.trim()) next.model = body.model.trim();
  if (typeof body.author === "string") next.author = body.author;
  if (typeof body.ollamaModel === "string") next.ollamaModel = body.ollamaModel.trim();
  if (typeof body.copyLinkedVideos === "boolean") next.copyLinkedVideos = body.copyLinkedVideos;
  if (typeof body.mirrorDir === "string") {
    const dir = body.mirrorDir.trim().replace(/^"|"$/g, "");
    if (dir) {
      const abs = path.resolve(dir);
      if (abs === WORK_DIR || abs.startsWith(WORK_DIR + path.sep)) return send(res, 400, { error: "La copia aggiuntiva deve stare fuori dalla cartella di Verbale Studio (es. una cartella OneDrive o una chiavetta)." });
      try {
        await fsp.mkdir(abs, { recursive: true });
        await fsp.writeFile(path.join(abs, ".verbale-studio-test"), "ok");
        await fsp.rm(path.join(abs, ".verbale-studio-test"), { force: true });
      } catch {
        return send(res, 400, { error: `Impossibile scrivere nella cartella ${abs}` });
      }
      next.mirrorDir = abs;
    } else next.mirrorDir = "";
  }
  await writeJson(SETTINGS_FILE, next);
  send(res, 200, publicSettings(next));
});
route("POST", "/api/projects", async (req, res) => {
  const body = await readJsonBody(req);
  const name = String(body.name || "").trim();
  if (!name) return send(res, 400, { error: "Nome progetto obbligatorio" });
  let id = slugify(name);
  let i = 2;
  while (fs.existsSync(projectDir(id))) id = `${slugify(name)}-${i++}`;
  const project = {
    id,
    name,
    description: body.description || "",
    recipients: "",
    subjectTemplate: `${name} | Checkpoint {data} \u2014 punti discussi`,
    templateId: String(body.templateId || "checkpoint-settimanale"),
    glossary: "",
    exampleEmail: DEFAULT_EXAMPLE_EMAIL,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  await writeJson(projectFile(id), project);
  send(res, 201, project);
});
route("PUT", "/api/projects/:pid", async (req, res, { pid }) => {
  const current = await readJson(projectFile(pid), null);
  if (!current) return send(res, 404, { error: "Progetto non trovato" });
  const body = await readJsonBody(req);
  const allowed = ["name", "description", "recipients", "subjectTemplate", "glossary", "exampleEmail", "templateId"];
  for (const k of allowed) if (typeof body[k] === "string") current[k] = body[k];
  current.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  await writeJson(projectFile(pid), current);
  send(res, 200, current);
});
route("DELETE", "/api/projects/:pid", async (req, res, { pid }) => {
  const project = await readJson(projectFile(pid), null);
  if (!project) return send(res, 404, { error: "Progetto non trovato" });
  await backup.moveToTrash(projectDir(pid), { kind: "progetto", projectId: project.id, projectName: project.name, title: project.name });
  send(res, 200, { ok: true });
});
route("GET", "/api/projects/:pid/checkpoints", async (req, res, { pid }) => {
  const list = await loadCheckpoints(pid);
  send(res, 200, list.map(checkpointSummary));
});
route("GET", "/api/projects/:pid/history", async (req, res, { pid }) => {
  const list = await loadCheckpoints(pid);
  send(res, 200, {
    checkpoints: list.map((c) => ({ ...checkpointSummary(c), templateId: c.templateId || "", summary: c.summary || null })),
    forecast: await readJson(forecastFile(pid), null)
  });
});
route("POST", "/api/projects/:pid/checkpoints", async (req, res, { pid }) => {
  if (!fs.existsSync(projectFile(pid))) return send(res, 404, { error: "Progetto non trovato" });
  const body = await readJsonBody(req);
  const date = /^\d{4}-\d{2}-\d{2}$/.test(body.date || "") ? body.date : (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const id = `${date}-${crypto.randomBytes(2).toString("hex")}`;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const checkpoint = {
    id,
    projectId: safeId(pid),
    date,
    title: String(body.title || "Checkpoint"),
    templateId: String(body.templateId || ""),
    status: "bozza",
    createdAt: now,
    updatedAt: now,
    video: null,
    transcript: { sourceName: "", cues: [] },
    notes: "",
    summary: null,
    email: { subject: "", body: "", edited: false }
  };
  await writeJson(checkpointFile(pid, id), checkpoint);
  send(res, 201, checkpoint);
});
route("GET", "/api/projects/:pid/checkpoints/:cid", async (req, res, { pid, cid }) => {
  const c = await readJson(checkpointFile(pid, cid), null);
  if (!c) return send(res, 404, { error: "Checkpoint non trovato" });
  send(res, 200, c);
});
var SAVE_FIELDS = ["date", "title", "status", "templateId", "transcript", "notes", "summary", "email", "analysis", "pins", "chat"];
async function saveCheckpoint(pid, cid, body) {
  return withLock(`${pid}/${cid}`, async () => {
    const current = await readJson(checkpointFile(pid, cid), null);
    if (!current) return null;
    const before = JSON.stringify(SAVE_FIELDS.map((k) => current[k]));
    const previous = JSON.parse(JSON.stringify(current));
    for (const k of SAVE_FIELDS) if (k in body) current[k] = body[k];
    if (JSON.stringify(SAVE_FIELDS.map((k) => current[k])) !== before) {
      const replacedTranscript = previous.transcript?.cues?.length && body.transcript && body.transcript.importedAt !== previous.transcript.importedAt;
      await backup.snapshot(checkpointDir(pid, cid), previous, replacedTranscript ? "prima-del-nuovo-transcript" : "auto").catch(() => {
      });
    }
    current.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    await renameFolderIfNeeded(current);
    await writeExports(pid, current).catch((err) => console.error("Esportazione non riuscita:", err.message));
    await writeJson(checkpointFile(pid, cid), current);
    return current;
  });
}
route("PUT", "/api/projects/:pid/checkpoints/:cid", async (req, res, { pid, cid }) => {
  const result = await saveCheckpoint(pid, cid, await readJsonBody(req));
  if (!result) return send(res, 404, { error: "Checkpoint non trovato" });
  send(res, 200, { ok: true, updatedAt: result.updatedAt, folder: result.folder || "", video: result.video || null, transcriptFile: result.transcriptFile || "" });
});
route("POST", "/api/projects/:pid/checkpoints/:cid/save", async (req, res, { pid, cid }) => {
  const result = await saveCheckpoint(pid, cid, await readJsonBody(req));
  send(res, result ? 200 : 404, { ok: Boolean(result) });
});
route("GET", "/api/projects/:pid/checkpoints/:cid/versions", async (req, res, { pid, cid }) => {
  send(res, 200, await backup.listVersions(checkpointDir(pid, cid)));
});
route("POST", "/api/projects/:pid/checkpoints/:cid/versions/restore", async (req, res, { pid, cid }) => {
  const { file } = await readJsonBody(req);
  const version = await backup.readVersion(checkpointDir(pid, cid), file);
  const result = await withLock(`${pid}/${cid}`, async () => {
    const current = await readJson(checkpointFile(pid, cid), null);
    if (!current) return null;
    await backup.snapshot(checkpointDir(pid, cid), current, "prima-del-ripristino");
    for (const k of SAVE_FIELDS) if (k in version) current[k] = version[k];
    current.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    await writeExports(pid, current).catch(() => {
    });
    await writeJson(checkpointFile(pid, cid), current);
    return current;
  });
  if (!result) return send(res, 404, { error: "Checkpoint non trovato" });
  send(res, 200, result);
});
route("DELETE", "/api/projects/:pid/checkpoints/:cid", async (req, res, { pid, cid }) => {
  const dir = checkpointDir(pid, cid);
  const c = await readJson(checkpointFile(pid, cid), null);
  if (!c) return send(res, 404, { error: "Checkpoint non trovato" });
  const project = await readJson(projectFile(pid), null);
  await withLock(`${pid}/${cid}`, () => backup.moveToTrash(dir, { kind: "checkpoint", projectId: safeId(pid), projectName: project?.name || pid, checkpointId: c.id, title: c.title, date: c.date }));
  send(res, 200, { ok: true });
});
route("PUT", "/api/projects/:pid/checkpoints/:cid/video", async (req, res, { pid, cid }) => {
  const initial = await readJson(checkpointFile(pid, cid), null);
  if (!initial) return send(res, 404, { error: "Checkpoint non trovato" });
  const url = new URL(req.url, "http://x");
  const original = path.basename(url.searchParams.get("name") || "video.mp4");
  const ext = (path.extname(original).toLowerCase().match(/^\.[a-z0-9]{1,5}$/) || [".mp4"])[0];
  const dir = await withLock(`${pid}/${cid}`, async () => {
    const c = await readJson(checkpointFile(pid, cid), null);
    const d = await ensureFolder(pid, c);
    await writeJson(checkpointFile(pid, cid), c);
    return d;
  });
  const target = path.join(dir, `Registrazione${ext}`);
  const tmp = `${target}.upload`;
  await new Promise((resolve, reject) => {
    const out = fs.createWriteStream(tmp);
    req.pipe(out);
    out.on("finish", resolve);
    out.on("error", reject);
    req.on("error", reject);
  });
  const video = await withLock(`${pid}/${cid}`, async () => {
    const c = await readJson(checkpointFile(pid, cid), null);
    await removeOwnVideo(pid, cid, c, target);
    await fsp.rm(target, { force: true });
    await fsp.rename(tmp, target);
    const stat = await fsp.stat(target);
    c.video = { external: path.relative(WORK_DIR, target), copied: true, name: original, size: stat.size, uploadedAt: (/* @__PURE__ */ new Date()).toISOString() };
    c.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    await writeJson(checkpointFile(pid, cid), c);
    return c.video;
  });
  send(res, 200, video);
});
async function removeOwnVideo(pid, cid, c, keep) {
  if (c.video?.file) await fsp.rm(path.join(checkpointDir(pid, cid), path.basename(c.video.file)), { force: true });
  if (c.video?.copied && c.video.external) {
    const abs = workPath(c.video.external);
    if (abs !== keep) await fsp.rm(abs, { force: true });
  }
}
route("PUT", "/api/projects/:pid/checkpoints/:cid/transcript-file", async (req, res, { pid, cid }) => {
  const url = new URL(req.url, "http://x");
  const fromRel = url.searchParams.get("rel");
  const original = path.basename(fromRel || url.searchParams.get("name") || "transcript.vtt");
  const ext = (path.extname(original).toLowerCase().match(/^\.(vtt|srt|txt|docx)$/) || [".txt"])[0];
  const buf = fromRel ? await fsp.readFile(workPath(fromRel)) : await readBody(req);
  const rel = await withLock(`${pid}/${cid}`, async () => {
    const c = await readJson(checkpointFile(pid, cid), null);
    if (!c) return null;
    const dir = await ensureFolder(pid, c);
    if (c.transcriptFile) await fsp.rm(workPath(c.transcriptFile), { force: true });
    const target = path.join(dir, `Transcript originale${ext}`);
    await fsp.writeFile(target, buf);
    c.transcriptFile = path.relative(WORK_DIR, target);
    await writeJson(checkpointFile(pid, cid), c);
    return c.transcriptFile;
  });
  if (!rel) return send(res, 404, { error: "Checkpoint non trovato" });
  send(res, 200, { transcriptFile: rel });
});
route("DELETE", "/api/projects/:pid/checkpoints/:cid/video", async (req, res, { pid, cid }) => {
  const ok = await withLock(`${pid}/${cid}`, async () => {
    const c = await readJson(checkpointFile(pid, cid), null);
    if (!c) return false;
    await removeOwnVideo(pid, cid, c);
    c.video = null;
    await writeJson(checkpointFile(pid, cid), c);
    return true;
  });
  if (!ok) return send(res, 404, { error: "Checkpoint non trovato" });
  send(res, 200, { ok: true });
});
route("GET", "/media/:pid/:cid", async (req, res, { pid, cid }) => {
  const current = await readJson(checkpointFile(pid, cid), null);
  if (current?.video?.external) return serveFile(req, res, workPath(current.video.external));
  if (!current?.video?.file) return send(res, 404, "Nessun video");
  serveFile(req, res, path.join(checkpointDir(pid, cid), path.basename(current.video.file)));
});
route("POST", "/api/projects/:pid/checkpoints/:cid/video-link", async (req, res, { pid, cid }) => {
  const { rel } = await readJsonBody(req);
  const abs = workPath(rel);
  const stat = await fsp.stat(abs).catch(() => null);
  if (!stat?.isFile()) return send(res, 404, { error: "File non trovato nella cartella" });
  const settings = await getSettings();
  const copy = settings.copyLinkedVideos !== false;
  const video = await withLock(`${pid}/${cid}`, async () => {
    const c = await readJson(checkpointFile(pid, cid), null);
    if (!c) return null;
    const dir = await ensureFolder(pid, c);
    let target = abs;
    if (copy && !abs.startsWith(dir + path.sep)) {
      target = path.join(dir, `Registrazione${path.extname(abs).toLowerCase() || ".mp4"}`);
      const tmp = `${target}.upload`;
      await fsp.copyFile(abs, tmp);
      await removeOwnVideo(pid, cid, c, target);
      await fsp.rm(target, { force: true });
      await fsp.rename(tmp, target);
    } else await removeOwnVideo(pid, cid, c, abs);
    c.video = {
      external: path.relative(WORK_DIR, target),
      copied: target !== abs,
      source: path.relative(WORK_DIR, abs),
      name: path.basename(abs),
      size: stat.size,
      uploadedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    c.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    await writeJson(checkpointFile(pid, cid), c);
    return c.video;
  });
  if (!video) return send(res, 404, { error: "Checkpoint non trovato" });
  send(res, 200, video);
});
var VIDEO_EXT = /* @__PURE__ */ new Set([".mp4", ".m4v", ".mov", ".webm", ".mkv", ".m4a", ".mp3", ".wav"]);
var TRANSCRIPT_EXT = /* @__PURE__ */ new Set([".vtt", ".docx", ".srt", ".txt"]);
var SKIP_DIRS = /* @__PURE__ */ new Set(["node_modules", ".git", "public", "lib", "build", "packaging", "dist", "release", "Archivio", "Backup", "motore-mac", "alternativa-node", "app"]);
async function scanFolder(dir, depth, out) {
  if (out.length > 2e3) return;
  const entries = await fsp.readdir(dir, { withFileTypes: true }).catch(() => []);
  for (const e of entries) {
    if (e.name.startsWith(".") || e.name.startsWith("~$")) continue;
    const abs = path.join(dir, e.name);
    if (e.isDirectory()) {
      const isNode = /^node(-v[\d.]+-[a-z0-9-]+)?$/i.test(e.name);
      if (depth < 4 && !SKIP_DIRS.has(e.name) && !isNode && path.resolve(abs) !== path.resolve(DATA_DIR)) await scanFolder(abs, depth + 1, out);
      continue;
    }
    const ext = path.extname(e.name).toLowerCase();
    const type = VIDEO_EXT.has(ext) ? "video" : TRANSCRIPT_EXT.has(ext) ? "transcript" : null;
    if (!type || /^(readme|license|changelog|leggimi|metti qui)/i.test(e.name)) continue;
    const stat = await fsp.stat(abs).catch(() => null);
    if (!stat) continue;
    out.push({ rel: path.relative(WORK_DIR, abs), name: e.name, dir: path.relative(WORK_DIR, dir), type, size: stat.size, mtime: stat.mtime.toISOString() });
  }
}
route("GET", "/api/folder", async (req, res) => {
  const files = [];
  await scanFolder(WORK_DIR, 0, files);
  const used = /* @__PURE__ */ new Map();
  for (const p of await listProjects()) {
    for (const c of await loadCheckpoints(p.id)) {
      const mark = (rel) => rel && used.set(path.normalize(rel), { projectId: p.id, projectName: p.name, checkpointId: c.id, date: c.date, title: c.title });
      mark(c.video?.external);
      mark(c.video?.source);
      mark(c.transcript?.sourcePath);
    }
  }
  for (const f of files) f.usedBy = used.get(path.normalize(f.rel)) || null;
  files.sort((a, b) => b.mtime.localeCompare(a.mtime));
  send(res, 200, { workDir: WORK_DIR, dataDir: DATA_DIR, archiveDir: ARCHIVE_DIR, files, checkpoints: await resourceOverview() });
});
async function resourceOverview() {
  const out = [];
  const info = async (rel) => {
    if (!rel) return null;
    const st = await fsp.stat(workPath(rel)).catch(() => null);
    return st?.isFile() ? { rel: path.normalize(rel), size: st.size, mtime: st.mtime.toISOString() } : { rel: path.normalize(rel), missing: true };
  };
  const known = /^(Registrazione\.|Transcript originale\.|Transcript revisionato\.txt|Email di riepilogo\.txt|Punti chiave\.txt|Note\.txt|_dati-app)/i;
  for (const p of await listProjects()) {
    for (const c of await loadCheckpoints(p.id)) {
      const folder = c.folder && fs.existsSync(workPath(c.folder)) ? path.normalize(c.folder) : "";
      const names = folder ? await fsp.readdir(workPath(folder)).catch(() => []) : [];
      const inFolder = (name) => folder && names.includes(name) ? info(path.join(folder, name)) : null;
      const original = names.find((n) => /^Transcript originale\./i.test(n));
      const other = [];
      for (const n of names.filter((x) => !known.test(x) && !x.endsWith(".tmp") && !x.endsWith(".upload"))) other.push(await info(path.join(folder, n)));
      const videoRel = c.video?.external ? path.normalize(c.video.external) : "";
      out.push({
        projectId: p.id,
        projectName: p.name,
        id: c.id,
        date: c.date,
        title: c.title,
        status: c.status,
        folder,
        video: videoRel ? { ...await info(videoRel), inArchive: Boolean(folder && videoRel.startsWith(folder + path.sep)), source: c.video.source || "" } : null,
        transcriptOriginal: original ? await inFolder(original) : null,
        transcriptRevised: await inFolder("Transcript revisionato.txt"),
        email: await inFolder("Email di riepilogo.txt"),
        pins: await inFolder("Punti chiave.txt"),
        notes: await inFolder("Note.txt"),
        data: folder && names.includes("_dati-app") ? await info(path.join(folder, "_dati-app", "checkpoint.json")) : null,
        other: other.filter(Boolean),
        cueCount: c.transcript?.cues?.length || 0
      });
    }
  }
  return out.sort((a, b) => b.date.localeCompare(a.date));
}
route("POST", "/api/folder/open-file", async (req, res) => {
  const { rel, reveal } = await readJsonBody(req);
  const abs = workPath(rel);
  if (!fs.existsSync(abs)) return send(res, 404, { error: "File non trovato" });
  let cmd;
  if (process.platform === "win32") cmd = reveal ? `explorer /select,"${abs}"` : `start "" "${abs}"`;
  else if (process.platform === "darwin") cmd = `open ${reveal ? "-R " : ""}"${abs}"`;
  else cmd = `xdg-open "${reveal ? path.dirname(abs) : abs}"`;
  exec(cmd, () => {
  });
  send(res, 200, { ok: true });
});
route("POST", "/api/folder/read", async (req, res) => {
  const { rel } = await readJsonBody(req);
  const abs = workPath(rel);
  const buf = await fsp.readFile(abs).catch(() => null);
  if (!buf) return send(res, 404, { error: "File non trovato" });
  const text = path.extname(abs).toLowerCase() === ".docx" ? docxToText(buf) : buf.toString("utf8");
  send(res, 200, { text, name: path.basename(abs), rel: path.relative(WORK_DIR, abs) });
});
route("POST", "/api/folder/open", async (req, res) => {
  const { which, rel } = await readJsonBody(req);
  const settings = await getSettings();
  const target = which === "data" ? DATA_DIR : which === "archive" ? ARCHIVE_DIR : which === "backup" ? BACKUP_DIR : which === "mirror" && settings.mirrorDir ? settings.mirrorDir : rel ? workPath(rel) : WORK_DIR;
  await fsp.mkdir(target, { recursive: true }).catch(() => {
  });
  const cmd = process.platform === "win32" ? `explorer "${target}"` : process.platform === "darwin" ? `open "${target}"` : `xdg-open "${target}"`;
  exec(cmd, () => {
  });
  send(res, 200, { ok: true });
});
var learningFile = (pid) => path.join(projectDir(pid), "learning.json");
route("GET", "/api/projects/:pid/learning", async (req, res, { pid }) => {
  send(res, 200, await readJson(learningFile(pid), null));
});
route("PUT", "/api/projects/:pid/learning", async (req, res, { pid }) => {
  if (!fs.existsSync(projectFile(pid))) return send(res, 404, { error: "Progetto non trovato" });
  await writeJson(learningFile(pid), await readJsonBody(req));
  send(res, 200, { ok: true });
});
async function trainingExamples(pid) {
  const out = [];
  for (const c of await loadCheckpoints(pid)) {
    for (const v of Object.values(c.summary || {})) {
      if (!Array.isArray(v)) continue;
      for (const it of v) if (it?.ref?.source && it.text && it.ref.source.trim() !== it.text.trim()) out.push({ source: it.ref.source, text: it.text });
    }
  }
  return out;
}
route("GET", "/api/ollama/status", async (req, res) => {
  const url = new URL(req.url, "http://x");
  const pid = url.searchParams.get("projectId");
  const st = await ollama.status();
  send(res, 200, {
    ...st,
    recommended: ollama.RECOMMENDED,
    jobs: ollama.jobs,
    platform: process.platform,
    trainedModel: pid ? ollama.trainedName(pid) : null,
    trainingExamples: pid ? (await trainingExamples(pid)).length : 0
  });
});
route("POST", "/api/ollama/install", async (req, res) => send(res, 200, ollama.install()));
route("POST", "/api/ollama/start", async (req, res) => {
  ollama.startApp();
  send(res, 200, { ok: true });
});
route("POST", "/api/ollama/pull", async (req, res) => {
  const { model } = await readJsonBody(req);
  if (!/^[\w.:/-]{2,80}$/.test(model || "")) return send(res, 400, { error: "Nome modello non valido" });
  send(res, 200, ollama.pull(model));
});
route("POST", "/api/ollama/delete", async (req, res) => {
  const { model } = await readJsonBody(req);
  await ollama.removeModel(model);
  send(res, 200, { ok: true });
});
route("POST", "/api/ollama/train", async (req, res) => {
  const { projectId, base } = await readJsonBody(req);
  const project = await readJson(projectFile(projectId), null);
  if (!project) return send(res, 404, { error: "Progetto non trovato" });
  const settings = await getSettings();
  const result = await ollama.train({ project, author: settings.author, base: base || settings.ollamaModel || "qwen2.5:3b", examples: await trainingExamples(projectId) });
  send(res, 200, result);
});
route("POST", "/api/ollama/task", async (req, res) => {
  const body = await readJsonBody(req);
  const project = await readJson(projectFile(body.projectId), null);
  if (!project) return send(res, 404, { error: "Progetto non trovato" });
  const settings = await getSettings();
  const model = body.model || settings.ollamaModel;
  if (!model) return send(res, 400, { error: "Scegli un modello nella finestra \u201CAI locale\u201D." });
  const text = await ollama.task({ model, project, author: settings.author, task: body.task, text: String(body.text || "").slice(0, 4e3) });
  send(res, 200, { text });
});
route("GET", "/api/trash", async (req, res) => send(res, 200, await backup.listTrash()));
route("POST", "/api/trash/restore", async (req, res) => {
  const { id } = await readJsonBody(req);
  send(res, 200, await backup.restoreFromTrash(id));
});
route("DELETE", "/api/trash/:id", async (req, res, { id }) => {
  await backup.purgeTrash(decodeURIComponent(id));
  send(res, 200, { ok: true });
});
route("GET", "/api/backup/status", async (req, res) => {
  const settings = await getSettings();
  send(res, 200, { backupDir: BACKUP_DIR, archiveDir: ARCHIVE_DIR, mirrorDir: settings.mirrorDir || "", ...backup.status, backups: await backup.lastBackups() });
});
route("POST", "/api/backup/now", async (req, res) => {
  const name = await backup.dailyBackup({ force: true });
  send(res, 200, { name });
});
var PRESETS_FILE = path.join(DATA_DIR, "presets.json");
route("GET", "/api/presets", async (req, res) => send(res, 200, await readJson(PRESETS_FILE, [])));
route("PUT", "/api/presets", async (req, res) => {
  const body = await readJsonBody(req);
  if (!Array.isArray(body)) return send(res, 400, { error: "Formato non valido" });
  await writeJson(PRESETS_FILE, body);
  send(res, 200, { ok: true });
});
route("POST", "/api/ollama/chat", async (req, res) => {
  const body = await readJsonBody(req);
  const project = await readJson(projectFile(body.projectId), null);
  const c = await readJson(checkpointFile(body.projectId, body.checkpointId), null);
  if (!project || !c) return send(res, 404, { error: "Checkpoint non trovato" });
  const settings = await getSettings();
  const model = settings.ollamaModel;
  if (!model) return send(res, 400, { error: "Scegli un modello nella finestra \u201CAI locale\u201D." });
  const system = ollama.checkpointSystemPrompt({ project, author: settings.author, checkpoint: c, context: body.context || {}, template: body.template });
  const history = (Array.isArray(body.messages) ? body.messages : []).slice(-12).map((m) => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content || "").slice(0, 12e3) }));
  let upstream;
  try {
    upstream = await ollama.chatStream({ model, messages: [{ role: "system", content: system }, ...history], format: body.format, numCtx: body.context?.transcript ? 16384 : 8192 });
  } catch (err) {
    return send(res, err.status || 503, { error: err.message });
  }
  res.writeHead(200, { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-store" });
  try {
    for await (const chunk of upstream.body) res.write(chunk);
  } catch {
  }
  res.end();
});
route("GET", "/api/templates", async (req, res) => {
  send(res, 200, await readJson(TEMPLATES_FILE, []));
});
route("PUT", "/api/templates", async (req, res) => {
  const body = await readJsonBody(req);
  if (!Array.isArray(body)) return send(res, 400, { error: "Formato non valido" });
  await writeJson(TEMPLATES_FILE, body);
  send(res, 200, { ok: true });
});
route("POST", "/api/docx-text", async (req, res) => {
  const buf = await readBody(req);
  try {
    send(res, 200, { text: docxToText(buf) });
  } catch (err) {
    send(res, 400, { error: err.message });
  }
});
async function aiContext(pid, cid) {
  const project = await readJson(projectFile(pid), null);
  if (!project) throw Object.assign(new Error("Progetto non trovato"), { status: 404 });
  const all = await loadCheckpoints(pid);
  const settings = await getSettings();
  const current = cid ? all.find((c) => c.id === safeId(cid)) : null;
  if (cid && !current) throw Object.assign(new Error("Checkpoint non trovato"), { status: 404 });
  return { project, all, settings, current };
}
route("POST", "/api/ai/summary", async (req, res) => {
  const body = await readJsonBody(req);
  const { project, all, settings, current } = await aiContext(body.projectId, body.checkpointId);
  const previous = all.filter((c) => c.id !== current.id && (c.date || "") <= (current.date || "") && c.summary).slice(0, 4);
  const summary = await ai.generateSummary({ settings, project, checkpoint: current, previous, template: body.template });
  send(res, 200, { summary });
});
route("POST", "/api/ai/proofread", async (req, res) => {
  const body = await readJsonBody(req);
  const { project, settings, current } = await aiContext(body.projectId, body.checkpointId);
  const cues = Array.isArray(body.cues) && body.cues.length ? body.cues : current.transcript?.cues || [];
  const corrections = await ai.proofread({ settings, project, cues });
  send(res, 200, { corrections });
});
route("POST", "/api/ai/forecast", async (req, res) => {
  const body = await readJsonBody(req);
  const { project, all, settings } = await aiContext(body.projectId);
  const withSummary = all.filter((c) => c.summary).slice(0, 8);
  if (!withSummary.length) return send(res, 400, { error: "Serve almeno un checkpoint con il riepilogo compilato." });
  const result = await ai.forecast({ settings, project, checkpoints: withSummary, today: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) });
  const forecast = { ...result, generatedAt: (/* @__PURE__ */ new Date()).toISOString(), basedOn: withSummary.map((c) => c.id), source: "ai" };
  await writeJson(forecastFile(body.projectId), forecast);
  send(res, 200, forecast);
});
route("PUT", "/api/projects/:pid/forecast", async (req, res, { pid }) => {
  const body = await readJsonBody(req);
  await writeJson(forecastFile(pid), { ...body, savedAt: (/* @__PURE__ */ new Date()).toISOString() });
  send(res, 200, { ok: true });
});
async function handle(req, res) {
  const url = new URL(req.url, "http://localhost");
  const pathname = decodeURIComponent(url.pathname);
  for (const r of routes) {
    if (r.method !== req.method && !(r.method === "GET" && req.method === "HEAD")) continue;
    const m = r.re.exec(pathname);
    if (!m) continue;
    const params = Object.fromEntries(r.keys.map((k, i) => [k, m[i + 1]]));
    return r.handler(req, res, params);
  }
  if (pathname.startsWith("/api/")) return send(res, 404, { error: "Endpoint non trovato" });
  if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, "Metodo non consentito");
  const rel = pathname === "/" ? "/index.html" : pathname;
  if (sea) {
    let asset;
    try {
      asset = sea.getAsset("public" + rel.replace(/\\/g, "/"));
    } catch {
      return send(res, 404, "Non trovato");
    }
    res.writeHead(200, { "Content-Type": MIME[path.extname(rel).toLowerCase()] || "application/octet-stream", "Cache-Control": "no-cache" });
    return res.end(Buffer.from(asset));
  }
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR)) return send(res, 403, "Vietato");
  return serveFile(req, res, file);
}
function openBrowser(url) {
  const cmd = process.platform === "win32" ? `start "" "${url}"` : process.platform === "darwin" ? `open ${url}` : `xdg-open ${url}`;
  exec(cmd, () => {
  });
}
function existingInstance(port) {
  return new Promise((resolve) => {
    const req = http.get({ host: "127.0.0.1", port, path: "/api/state", timeout: 1500 }, (res) => {
      let body = "";
      res.on("data", (c) => body += c);
      res.on("end", () => {
        try {
          resolve(JSON.parse(body).workDir === WORK_DIR);
        } catch {
          resolve(false);
        }
      });
    });
    req.on("error", () => resolve(false));
    req.on("timeout", () => (req.destroy(), resolve(false)));
  });
}
async function main() {
  await ensureSeed();
  backup.init({ dataDir: DATA_DIR, workDir: WORK_DIR, archiveDir: ARCHIVE_DIR, backupDir: BACKUP_DIR, getMirror: async () => (await getSettings()).mirrorDir || "" });
  backup.startScheduler();
  const shouldOpen = process.argv.includes("--open") || sea && !process.argv.includes("--no-open");
  const server = http.createServer((req, res) => {
    handle(req, res).catch((err) => {
      const status = err.status || 500;
      if (status >= 500) console.error(err);
      if (!res.headersSent) send(res, status, { error: err.message || "Errore interno" });
      else res.end();
    });
  });
  server.requestTimeout = 0;
  for (let port = PORT; port < PORT + 10; port++) {
    const ok = await new Promise((resolve) => {
      server.once("error", () => resolve(false));
      server.listen(port, "127.0.0.1", () => resolve(true));
    });
    if (ok) {
      const url = `http://localhost:${port}`;
      console.log(`
  Verbale Studio ${APP_VERSION} attivo su ${url}`);
      console.log(`  Cartella di lavoro: ${WORK_DIR}`);
      console.log(`  Archivio:           ${DATA_DIR}`);
      if (RUNNING_FROM_TEMP) {
        console.log(`
  ATTENZIONE: l'app \xE8 stata aperta dall'interno dello zip.`);
        console.log(`  Chiudi questa finestra, estrai lo zip (tasto destro \u2192 Estrai tutto) e avvia VerbaleStudio.exe dalla cartella estratta.`);
      }
      console.log(`
  Per chiudere l'app chiudi questa finestra.
`);
      if (shouldOpen) openBrowser(url);
      return;
    }
    if (await existingInstance(port)) {
      console.log(`Verbale Studio \xE8 gi\xE0 aperto su http://localhost:${port}`);
      if (shouldOpen) openBrowser(`http://localhost:${port}`);
      setTimeout(() => process.exit(0), 500);
      return;
    }
  }
  console.error("Nessuna porta libera tra " + PORT + " e " + (PORT + 9));
  process.exit(1);
}
if (sea || require.main === module) main();
module.exports = { docxToText, unzipEntry };
